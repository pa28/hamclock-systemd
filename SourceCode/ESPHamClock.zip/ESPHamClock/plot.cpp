/* handle each plotting area.
 */


#include "HamClock.h"

#define BORDER_COLOR    GRAY
#define TICKLEN         2                       // length of plot tickmarks, pixels
#define TGAP            10                      // top gap for title
#define BGAP            15                      // bottom gap for x labels
#define LGAP            21                      // left gap for y labels
#define FONTW           6                       // font width with gap
#define FONTH           8                       // font height


// plot organization.
// each PlotPane is in one of PlotChoice state at any given time, all different.

SBox plot_b[PANE_N] = {
    {235, 0, PLOTBOX_W, PLOTBOX_H},
    {405, 0, PLOTBOX_W, PLOTBOX_H},
    {575, 0, PLOTBOX_W, PLOTBOX_H},
};
PlotChoice plot_ch[PANE_N];
bool plot_rotating[PANE_N];
time_t next_rotation[PANE_N];
const char *plot_names[PLOT_CH_N] = {

    // N.B. must be in same order as PLOT_CH_* 
    // N.B. take care that names will fit in menu built by askPaneChoice()
    // N.B. names should not include blanks, but _ are changed to blanks for prettier printing

    "VOACAP",           // PLOT_CH_BC,
    "DE_Wx",            // PLOT_CH_DEWX,
    "DX_Cluster",       // PLOT_CH_DXCLUSTER,
    "DX_Wx",            // PLOT_CH_DXWX,
    "Solar_Flux",       // PLOT_CH_FLUX,
    "Planetary_K",      // PLOT_CH_KP,
    "Moon",             // PLOT_CH_MOON,
    "Space_Wx",         // PLOT_CH_NOAASWX,
    "Sunspot_N",        // PLOT_CH_SSN,
    "X-Ray",            // PLOT_CH_XRAY,
    "Gimbal",           // PLOT_CH_GIMBAL,
    "ENV_Temp",         // PLOT_CH_TEMPERATURE,
    "ENV_Press",        // PLOT_CH_PRESSURE,
    "ENV_Humid",        // PLOT_CH_HUMIDITY,
    "ENV_DewPt",        // PLOT_CH_DEWPOINT,
    "SDO_Comp",         // PLOT_CH_SDO_1,
    "SDO_6173A",        // PLOT_CH_SDO_2,
    "SDO_Magneto",      // PLOT_CH_SDO_3,
    "SDO_193A",         // PLOT_CH_SDO_4,
    "Solar_Wind",       // PLOT_CH_SOLWIND,
};




static int tickmarks (float min, float max, int numdiv, float ticks[]);

/* plot the given data within the given box.
 * if y_min == y_max: auto scale min and max from data
 * if y_min < y_max:  force min to y_min and max to y_max
 * if y_min > y_max:  force min to y_min but auto scale max from data
 * return whether had anything to plot.
 * N.B. if both labels are NULL, use same labels and limits as previous call as an "overlay"
 */
bool plotXY (const SBox &box, float x[], float y[], int nxy, const char *xlabel, const char *ylabel,
uint16_t color, float y_min, float y_max, float label_value)
{
        char buf[32];
        sprintf (buf, "%.*f", label_value >= 1000 ? 0 : 1, label_value);
        return (plotXYstr (box, x, y, nxy, xlabel, ylabel, color, y_min, y_max, buf));
}

/* same as plotXY but label is a string
 * N.B. special y axis labeling hack when ylabel contains the string "Ray"
 * N.B. special plot format hack when ylabel contains "Kp"
 */
bool plotXYstr (const SBox &box, float x[], float y[], int nxy, const char *xlabel, const char *ylabel,
uint16_t color, float y_min, float y_max, char *label_str)
{
    resetWatchdog();

    // no labels implies overlay previous plot
    bool overlay = xlabel == NULL && ylabel == NULL;

    // persistent scale info in case of subsequent overlay
    #define MAXTICKS     10
    static float xticks[MAXTICKS+2], yticks[MAXTICKS+2];
    static uint8_t nxt, nyt;
    static float minx, maxx;
    static float miny, maxy;
    static float dx, dy;

    char buf[32];

    // set font and color
    selectFontStyle (BOLD_FONT, FAST_FONT);
    tft.setTextColor(color);

    // report if no data
    if (nxy < 1 || !x || !y) {
        plotMessage (box, color, "No data");
        return (false);
    }

    // find new limits unless this is an overlay
    if (!overlay) {

        // find data extrema
        minx = x[0]; maxx = x[0];
        miny = y[0]; maxy = y[0];
        for (int i = 1; i < nxy; i++) {
            if (x[i] > maxx) maxx = x[i];
            if (x[i] < minx) minx = x[i];
            if (y[i] > maxy) maxy = y[i];
            if (y[i] < miny) miny = y[i];
        }
        minx = floor(minx);
        maxx = ceil(maxx);
        if (maxx < minx + 1)
            maxx = minx + 1;

        if (y_min < y_max) {
            // force miny and maxy to the given y range
            miny = y_min;
            maxy = y_max;
        } else {
            if (y_min == y_max) {
                // auto scale both miny and maxy
                miny = floor(miny);
            } else {
                // force miny, still autoscale maxy
                miny = y_min;
            }
            // autoscale maxy
            maxy = ceil(maxy);
            if (maxy < miny + 1)
                maxy = miny + 1;
        }

        // find tickmarks
        nxt = tickmarks (minx, maxx, MAXTICKS, xticks);
        nyt = tickmarks (miny, maxy, MAXTICKS, yticks);

        // handy ends
        minx = xticks[0];
        maxx = xticks[nxt-1];
        miny = yticks[0];
        maxy = yticks[nyt-1];
        dx = maxx-minx;
        dy = maxy-miny;

        // erase -- don't use prepPlotBox because we prefer no border on these plots
        tft.fillRect (box.x, box.y, box.w, box.h, RA8875_BLACK);

        // y labels and tickmarks just to the left of the plot
        if (strstr (ylabel, "Ray")) {
            // mark exponents and customary X ray levels
            uint16_t tx = box.x+LGAP;
            uint16_t steph = (box.h-BGAP-TGAP)/nyt;
            for (int i = 0; i < nyt; i++) {
                uint16_t ty = (uint16_t)(box.y + TGAP + (box.h-BGAP-TGAP)*(1 - (yticks[i]-miny)/dy) + 0.5F);
                tft.drawLine (tx-TICKLEN, ty, tx, ty, color);
                tft.setCursor (tx-FONTW-1, ty-steph+(steph-FONTH)/2-1);
                switch ((int)yticks[i]) {
                case -9: tft.setCursor (tx-TICKLEN-2*FONTW-1, ty-FONTH/2); tft.print(-9); break;
                case -8: tft.print ('A'); break;
                case -7: tft.print ('B'); break;
                case -6: tft.print ('C'); break;
                case -5: tft.print ('M'); break;
                case -4: tft.print ('X'); break;
                case -2: tft.setCursor (tx-TICKLEN-2*FONTW-1, ty-FONTH/2); tft.print(-2); break;
                }
            }
        } else {
            uint16_t tx = box.x+LGAP-TICKLEN;
            for (int i = 0; i < nyt; i++) {
                uint16_t ty = (uint16_t)(box.y + TGAP + (box.h-BGAP-TGAP)*(1 - (yticks[i]-miny)/dy) + 0.5F);
                tft.drawLine (tx, ty, tx+TICKLEN, ty, color);
                // label first, last and whenever whole number changes
                if (i == 0 || i == nyt-1 || (int)yticks[i-1] != (int)yticks[i]) {
                    sprintf (buf, "%d", (int)yticks[i]);
                    tft.setCursor (tx - getTextWidth(buf) - 1, ty - FONTH/2);
                    tft.print (buf);
                }
            }
        }

        // y label is title over plot
        uint8_t tl = getTextWidth(ylabel);
        tft.setCursor (box.x+LGAP+(box.w-LGAP-tl)/2, box.y+(TGAP-FONTH)/2);
        tft.print (ylabel);

        // x labels and tickmarks just below plot
        uint16_t txty = box.y+box.h-FONTH-2;
        tft.setCursor (box.x+LGAP, txty);
        tft.print (minx,0);
        sprintf (buf, "%c%d", maxx > 0 ? '+' : ' ', (int)maxx);
        tft.setCursor (box.x+box.w-getTextWidth(buf)-1, txty);
        tft.print (buf);
        for (int i = 0; i < nxt; i++) {
            uint16_t tx = (uint16_t)(box.x+LGAP + (box.w-LGAP-1)*(xticks[i]-minx)/dx + 0.5F);
            tft.drawLine (tx, box.y+box.h-BGAP, tx, box.y+box.h-BGAP+TICKLEN, color);
        }

        // always label 0 if within larger range
        if (minx < 0 && maxx > 0) {
            uint16_t zx = (uint16_t)(box.x+LGAP + (box.w-LGAP)*(0-minx)/dx + 0.5F);
            tft.setCursor (zx-FONTW/2, txty);
            tft.print (0);
        }

        // x label is centered about the plot across the bottom
        tft.setCursor (box.x + LGAP + (box.w-LGAP-getTextWidth (xlabel))/2, box.y+box.h-FONTH-2);
        tft.print (xlabel);

    }

    // check for special kp plot. N.B. ylabel is NULL if this is an overlay plot
    bool kp_plot = ylabel && strstr (ylabel, "Kp") != NULL;

    uint16_t last_px = 0, last_py = 0;
    resetWatchdog();
    for (int i = 0; i < nxy; i++) {
        // Serial.printf ("kp %2d: %g %g\n", i, x[i], y[i]);
        if (kp_plot) {
            // plot Kp values vertical bars colored depending on strength
            uint16_t w = (box.w-LGAP-2)/nxy;
            uint16_t h = y[i]*(box.h-BGAP-TGAP)/maxy;
            uint16_t px = (uint16_t)(box.x+LGAP+1 + (box.w-LGAP-2-w)*(x[i]-minx)/dx);
            uint16_t py = (uint16_t)(box.y + TGAP + 1 + (box.h-BGAP-TGAP)*(1 - (y[i]-miny)/dy));
            uint16_t co = y[i] < 4 ? RA8875_GREEN : y[i] == 4 ? RA8875_YELLOW : RA8875_RED;
            if (h > 0)
                tft.fillRect (px, py, w, h, co);
        } else {
            // other plots are connect-the-dots
            uint16_t px = (uint16_t)(box.x+LGAP+1 + (box.w-LGAP-2)*(x[i]-minx)/dx);   // stay inside border
            uint16_t py = (uint16_t)(box.y + TGAP + (box.h-BGAP-TGAP)*(1 - (y[i]-miny)/dy));
            if (i > 0 && (last_px != px || last_py != py))
                tft.drawLine (last_px, last_py, px, py, color);            // avoid bug with 0-length lines
            else if (nxy == 1)
                tft.drawLine (box.x+LGAP, py, box.x+box.w-1, py, color);   // one value clear across
            last_px = px;
            last_py = py;
        }
    }

    // draw plot border
    tft.drawRect (box.x+LGAP, box.y+TGAP, box.w-LGAP, box.h-BGAP-TGAP+1, BORDER_COLOR);

    if (!overlay) {

        // overlay large center value on top in gray
        tft.setTextColor(BRGRAY);
        selectFontStyle (BOLD_FONT, LARGE_FONT);
        uint16_t lw, lh;
        getTextBounds (label_str, &lw, &lh);
        uint16_t text_x = box.x+LGAP+(box.w-LGAP-lw)/2;
        uint16_t text_y = box.y+TGAP+(box.h-TGAP-BGAP)/25+lh;
        tft.setCursor (text_x, text_y);
        tft.print (label_str);
    }

    // printFreeHeap (F("plotXYstr"));

    // ok
    return (true);
}

/* shorten str IN PLACE as needed to be less that maxw pixels wide.
 * return final width in pixels.
 */
uint16_t maxStringW (char *str, uint16_t maxw)
{
    uint8_t strl = strlen (str);
    uint16_t bw = 0;

    while (strl > 0 && (bw = getTextWidth(str)) >= maxw)
        str[--strl] = '\0';

    return (bw);
}

/* print weather info in the given box
 */
void plotWX (const SBox &box, uint16_t color, const WXInfo &wi)
{
    resetWatchdog();

    // prep
    prepPlotBox (box);

    const uint8_t indent = FONTW+1;     // allow for attribution down right side
    uint16_t dy = box.h/3;
    uint16_t ddy = box.h/5;
    float f;
    char buf[32];
    uint16_t w;

    // large temperature with degree symbol and units
    tft.setTextColor(color);
    selectFontStyle (BOLD_FONT, LARGE_FONT);
    f = useMetricUnits() ? wi.temperature_c : 9*wi.temperature_c/5+32;
    sprintf (buf, "%.0f %c", f, useMetricUnits() ? 'C' : 'F');
    w = maxStringW (buf, box.w-indent);
    tft.setCursor (box.x+(box.w-indent-w)/2, box.y+dy);
    tft.print(buf);
    uint16_t bw, bh;
    getTextBounds (buf+strlen(buf)-2, &bw, &bh);
    selectFontStyle (BOLD_FONT, SMALL_FONT);
    tft.setCursor (tft.getCursorX()-bw, tft.getCursorY()-2*bh/3);
    tft.print('o');
    dy += ddy;


    // remaining info smaller
    selectFontStyle (LIGHT_FONT, SMALL_FONT);

    // humidity
    sprintf (buf, "%.0f%% RH", wi.humidity_percent);
    w = maxStringW (buf, box.w-indent);
    tft.setCursor (box.x+(box.w-indent-w)/2, box.y+dy);
    tft.print (buf);
    dy += ddy;

    // wind
    f = (useMetricUnits() ? 3.6 : 2.237) * wi.wind_speed_mps; // kph or mph
    sprintf (buf, "%s @ %.0f %s", wi.wind_dir_name, f, useMetricUnits() ? "kph" : "mph");
    w = maxStringW (buf, box.w-indent);
    if (buf[strlen(buf)-1] != 'h') {
        // try shorter string in case of huge speed
        sprintf (buf, "%s @ %.0f%s", wi.wind_dir_name, f, useMetricUnits() ? "k/h" : "m/h");
        w = maxStringW (buf, box.w-indent);
    }
    tft.setCursor (box.x+(box.w-indent-w)/2, box.y+dy);
    tft.print (buf);
    dy += ddy;

    // nominal conditions
    strcpy (buf, wi.conditions);
    w = maxStringW (buf, box.w-indent);
    tft.setCursor (box.x+(box.w-indent-w)/2, box.y+dy);
    tft.print(buf);

    // attribution very small down the right side
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    uint8_t ylen = strlen(wi.attribution);
    uint16_t ly0 = box.y + (box.h - ylen*FONTH)/2;
    for (uint8_t i = 0; i < ylen; i++) {
        tft.setCursor (box.x+box.w-indent, ly0+i*FONTH);
        tft.print (wi.attribution[i]);
    }

    // printFreeHeap (F("plotWX"));
}

/* this function handles the actual drawing of the Band Conditions pane. It can be called in two quite
 * different ways:
 * 1. when called by updateBandConditions(), we are given a table containing relative propagation values
 *    for each band and a summary line to be drawn across the bottom.
 * 2. we can also be called just to update the visual appearance of one of the band indicators as indicated
 *    by the table and summary line are NULL. In this case we only draw the band indicators showing
 *    prop_map according to busy and the others normal.
 * N.B. coordinate the layout geometry with checkBCTouch()
 */
void plotBandConditions (const SBox &box, int busy, float rel_tbl[PROP_MAP_N], char *cfg_str)
{
    // handy conversion of rel to text color
    #define RELCOL(r)       ((r) < 0.33 ? RA8875_RED : ((r) < 0.66 ? RA8875_YELLOW : RA8875_GREEN))

    // prep layout
    uint16_t ty = box.y + 27;           // BOTTOM of title; match DX Cluster title
    uint16_t cy = box.y+box.h-10;       // TOP of config string; beware comma descender
    uint16_t br_gap = box.w/5;
    uint16_t col1_x = box.x + 10;
    uint16_t col2_x = box.x + 5*box.w/9;
    uint16_t row_h = (cy-2-ty)/(PROP_MAP_N/2);

    // start over of we have a new table
    if (rel_tbl && cfg_str) {

        // prep
        prepPlotBox (box);

        // center title across the top
        selectFontStyle (LIGHT_FONT, SMALL_FONT);
        tft.setTextColor(RA8875_WHITE);
        const char *title = "VOACAP DE-DX";
        uint16_t bw = getTextWidth (title);
        tft.setCursor (box.x+(box.w-bw)/2, ty);
        tft.print ((char*)title);

        // center the config across the bottom
        selectFontStyle (LIGHT_FONT, FAST_FONT);
        tft.setTextColor(GRAY);
        bw = maxStringW (cfg_str, box.w);
        tft.setCursor (box.x+(box.w-bw)/2, cy);
        tft.print ((char*)cfg_str);

        // draw each rel_tab entry, 4 rows between ty and cy
        selectFontStyle (LIGHT_FONT, SMALL_FONT);
        for (int i = 0; i < PROP_MAP_N; i++) {
            uint16_t row_x = (i < PROP_MAP_N/2) ? col1_x : col2_x;
            uint16_t row_y = ty + row_h + (i%(PROP_MAP_N/2))*row_h;              // this is bottom of string

            char buf[10];
            tft.setTextColor(RELCOL(rel_tbl[i]));
            tft.setCursor (row_x + br_gap, row_y);
            snprintf (buf, sizeof(buf), "%2.0f", 99*rel_tbl[i]); // 100 doesn't fit
            tft.print (buf);
            if (i == PROP_MAP_80M)
                tft.print("%");
        }

    } 

    // always draw each band number
    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    for (int i = 0; i < PROP_MAP_N; i++) {
        uint16_t row_x = (i < PROP_MAP_N/2) ? col1_x : col2_x;
        uint16_t row_y = ty + row_h + (i%(PROP_MAP_N/2))*row_h;

        // background square then number
        if (i == prop_map) {
            // show highlighted as per busy
            uint16_t rect_col = busy > 0 ? RA8875_YELLOW : (busy < 0 ? RA8875_RED : GRAY);
            tft.fillRect (row_x-1, row_y-row_h+4, box.w/6, row_h-2, rect_col);
            tft.setTextColor(RA8875_BLACK);
        } else {
            // show plain
            tft.fillRect (row_x-1, row_y-row_h+4, box.w/6, row_h-2, RA8875_BLACK);
            tft.setTextColor(BRGRAY);
        }
        tft.setCursor (row_x, row_y);
        tft.print (propMap2Band((PropMapSetting)i));
    }

    printFreeHeap (F("plotBandConditions"));
}

/* print the NOAA RSG Space Weather Scales in the given box.
 */
void plotNOAASWx (const SBox &box, const NOAASpaceWx &noaaspw)
{
    resetWatchdog();

    // prep
    prepPlotBox (box);

    // title
    tft.setTextColor(RA8875_YELLOW);
    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    uint16_t h = box.h/5-2;                             // text row height
    char *title = (char *) "NOAA SpaceWx";
    uint16_t bw = getTextWidth (title);
    tft.setCursor (box.x+(box.w-bw)/2, box.y+h);
    tft.print (title);

    // print each line
    for (int i = 0; i < N_NOAASW_C; i++) {

        uint16_t w = box.w/7-1;
        h += box.h/4;
        tft.setCursor (box.x+w+(i==2?-2:0), box.y+h);   // tweak G to better center
        tft.setTextColor(GRAY);
        tft.print (noaaspw.cat[i]);

        w += box.w/10;
        for (int j = 0; j < N_NOAASW_V; j++) {
            int val = noaaspw.val[i][j];
            w += box.w/7;
            tft.setCursor (box.x+w, box.y+h);
            tft.setTextColor(val == 0 ? RA8875_GREEN : (val <= 3 ? RA8875_YELLOW : RA8875_RED));
            tft.print (val);
        }
    }
}


/* print a message in a (plot?) box, take care not to go outside
 */
void plotMessage (const SBox &box, uint16_t color, const char *message)
{
    // log
    Serial.printf (_FX("PlotMsg: %s\n"), message);

    // prep font
    selectFontStyle (BOLD_FONT, FAST_FONT);
    tft.setTextColor(color);

    // prep box
    prepPlotBox (box);

    // make a copy so we can use destructive maxStringW
    char *msg_cpy = strdup (message);
    size_t msg_len = strlen (message);
    uint16_t msg_printed = 0;
    uint16_t y = box.y + box.h/4;

    // show up to at least a few lines
    resetWatchdog();
    for (int n_lines = 0; n_lines < 5 && msg_printed < msg_len; n_lines++) {

        // draw one line
        uint16_t msgw = maxStringW (msg_cpy, box.w-2);
        tft.setCursor (box.x+(box.w-msgw)/2, y);                // horizontally centered
        tft.print(msg_cpy);

        // advance
        msg_printed += strlen (msg_cpy);
        strcpy (msg_cpy, message + msg_printed);
        y += 2*FONTH;
    }

    // done
    free (msg_cpy);
}

/* prep a box for plotting
 */
void prepPlotBox (const SBox &box)
{
    // erase all
    tft.fillRect (box.x, box.y, box.w, box.h, RA8875_BLACK);

    // not bottom so it appears to connect with map top
    uint16_t rx = box.x+box.w-1;
    uint16_t by = box.y+box.h-1;
    tft.drawLine (box.x, box.y, box.x, by, BORDER_COLOR);               // left
    tft.drawLine (box.x, box.y, rx, box.y, BORDER_COLOR);               // top
    tft.drawLine (rx, box.y, rx, by, BORDER_COLOR);                     // right
}

/* given min and max and an approximate number of divisions desired,
 * fill in ticks[] with nicely spaced values and return how many.
 * N.B. return value, and hence number of entries to ticks[], might be as
 *   much as 2 more than numdiv.
 */
static int tickmarks (float min, float max, int numdiv, float ticks[])
{
    static int factor[] = { 1, 2, 5 };
    #define NFACTOR    NARRAY(factor)
    float minscale;
    float delta;
    float lo;
    float v;
    int n;

    minscale = fabs(max - min);

    if (minscale == 0) {
        /* null range: return ticks in range min-1 .. min+1 */
        for (n = 0; n < numdiv; n++)
            ticks[n] = min - 1.0 + n*2.0/numdiv;
        return (numdiv);
    }

    delta = minscale/numdiv;
    for (n=0; n < (int)NFACTOR; n++) {
        float scale;
        float x = delta/factor[n];
        if ((scale = (powf(10.0F, ceilf(log10f(x)))*factor[n])) < minscale)
            minscale = scale;
    }
    delta = minscale;

    lo = floor(min/delta);
    for (n = 0; (v = delta*(lo+n)) < max+delta; )
        ticks[n++] = v;

    return (n);
}

/* return whether the given choice is currently physically available on this platform.
 * N.B. does not consider whether in use by multiple panes -- for that use findPaneForChoice()
 */
static bool plotChoiceIsAvailable (PlotChoice ch)
{
    switch (ch) {

    case PLOT_CH_DXCLUSTER:     return (useDXCluster());
    case PLOT_CH_GIMBAL:        return (haveGimbal());
    case PLOT_CH_TEMPERATURE:   return (getNBMEConnected() > 0);
    case PLOT_CH_PRESSURE:      return (getNBMEConnected() > 0);
    case PLOT_CH_HUMIDITY:      return (getNBMEConnected() > 0);
    case PLOT_CH_DEWPOINT:      return (getNBMEConnected() > 0);

    case PLOT_CH_BC:            // fallthru
    case PLOT_CH_DEWX:          // fallthru
    case PLOT_CH_DXWX:          // fallthru
    case PLOT_CH_FLUX:          // fallthru
    case PLOT_CH_KP:            // fallthru
    case PLOT_CH_MOON:          // fallthru
    case PLOT_CH_NOAASWX:       // fallthru
    case PLOT_CH_SSN:           // fallthru
    case PLOT_CH_XRAY:          // fallthru
    case PLOT_CH_SDO_1:         // fallthru
    case PLOT_CH_SDO_2:         // fallthru
    case PLOT_CH_SDO_3:         // fallthru
    case PLOT_CH_SDO_4:         // fallthru
    case PLOT_CH_SOLWIND:       // fallthru
        break;

    default:
        fatalError (_FX("Bug! plotChoiceIsAvailable() bad choice %d"), (int)ch);
        return (false);
    }

    return (true);
}

/* qsort-style function to compare pointers to two PlotChoice by their string names
 */
static int pcqsf (const void *p1, const void *p2)
{
    return (strcmp (plot_names[*(PlotChoice*)p1], plot_names[*(PlotChoice*)p2]));
}


/* draw a list of suitable plot choices in and for the given pane and allow user to choose one.
 * always return a selection even if its the current selection again, never PLOT_CH_NONE.
 */
static PlotChoice askPaneChoice (PlotPane pp)
{
    resetWatchdog();
    Serial.printf (_FX("Pane %d: from %s ...\n"), (int)pp+1, plot_names[plot_ch[pp]]);

    // collect choices to show
    PlotChoice menu_ch[PLOT_CH_N];                      // room for max, n_menu are actually used
    int n_menu = 0;
    for (int i = 0; i < PLOT_CH_N; i++) {

        // skip if choice is already set elsewhere or unavailable
        PlotChoice ch = (PlotChoice) i;
        if (findPaneForChoice (ch) != PANE_NONE || !plotChoiceIsAvailable(ch))
            continue;

        // record choice
        menu_ch[n_menu++] = ch;
    }

    // sort by name
    qsort (menu_ch, n_menu, sizeof(PlotChoice), pcqsf);

    // divide into two columns
    int n_rows = (n_menu+1)/2;

    // set up table geometry
    const SBox &box = plot_b[pp];                       // pane box we are within
    #define V_MAR   3                                   // top and bottom margin
    #define H_MAR   5                                   // left and right margin
    #define LINE_H  14                                  // text row height
    SBox m_b;                                           // overall menu box
    m_b.x = box.x;
    m_b.y = box.y+2;
    m_b.w = box.w;
    m_b.h = (n_rows+1)*LINE_H + 2*V_MAR;                // +1 for cancel

    // prep menu box
    tft.fillRect (m_b.x, m_b.y, m_b.w, m_b.h, RA8875_BLACK);
    tft.drawRect (m_b.x, m_b.y, m_b.w, m_b.h, RA8875_WHITE);
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    tft.setTextColor (RA8875_WHITE);
    uint16_t x = m_b.x + H_MAR;
    uint16_t y = m_b.y + V_MAR;


    // show each suitable choice and record where it is shown in its own box
    SBox item_b[n_menu];                                // box for each choice
    for (int i = 0; i < n_menu; i++) {

        // show name
        const char *pname = plot_names[menu_ch[i]];
        int pname_l = strlen(pname);
        char no__copy[pname_l+1];
        strncpySubChar (no__copy, pname, ' ', '_', pname_l);
        tft.setCursor (x, y);
        tft.print (no__copy);

        // record where for touch
        item_b[i].x = x;
        item_b[i].y = y - 2;
        item_b[i].w = m_b.w/2;
        item_b[i].h = LINE_H;

        // advance, wrap to next column when full
        y += LINE_H;
        if (i == (n_rows-1)) {
            x = m_b.x + m_b.w/2;
            y = m_b.y + V_MAR;
        }
    }

    // add rotation control, depending on current state
    SBox rotate_b;
    const char *rstr = plot_rotating[pp] ? "Rotate off" : "Auto rotate";
    uint16_t rw = getTextWidth (rstr);
    rotate_b.x = m_b.x+H_MAR;
    rotate_b.y = m_b.y + m_b.h - LINE_H;
    rotate_b.w = rw + 4;
    rotate_b.h = 10;
    tft.drawRect (rotate_b.x, rotate_b.y, rotate_b.w, rotate_b.h, RA8875_WHITE);
    tft.setCursor (rotate_b.x+2, rotate_b.y+1);
    tft.print(rstr);

    // add cancel button
    const char cstr[] = "Cancel";
    uint16_t cw = getTextWidth (cstr);
    SBox cancel_b;
    cancel_b.x = m_b.x+m_b.w-cw-H_MAR-4;
    cancel_b.y = m_b.y + m_b.h - LINE_H;
    cancel_b.w = cw + 4;
    cancel_b.h = 10;
    tft.drawRect (cancel_b.x, cancel_b.y, cancel_b.w, cancel_b.h, RA8875_WHITE);
    tft.setCursor (cancel_b.x+2, cancel_b.y+1);
    tft.print(cstr);

    // wait for tap inside the menu or bale if tap outside or time out
    uint32_t t0 = millis();
    for(;;) {

        SCoord s;
        if (readCalTouch(s) != TT_NONE) {

            // process tap

            if (!inBox(s,m_b) || inBox (s, cancel_b)) {
                // tap cancel or outside menu: no change
                break;

            } else if (inBox (s, rotate_b)) {
                // tap rotate button: toggle
                PlotChoice ch = plot_ch[pp];
                if (plot_rotating[pp]) {
                    // turn off, stay with current choice
                    plot_rotating[pp] = false;
                    savePlotOps();
                    Serial.printf (_FX("Pane %d: ... to not rotating\n"), (int)pp+1);
                } else {
                    // start rotating with a new choice
                    plot_rotating[pp] = true;
                    savePlotOps();
                    ch = getNextRotationChoice(pp);
                    Serial.printf (_FX("Pane %d: ... to rotating at %s\n"), (int)pp+1, plot_names[ch]);
                }
                return (ch);

            } else {
                // tap some other button?
                for (int i = 0; i < n_menu; i++) {
                    if (inBox (s, item_b[i])) {
                        // set desired choice, stop rotating
                        PlotChoice ch = menu_ch[i];
                        plot_rotating[pp] = false;
                        savePlotOps();
                        Serial.printf (_FX("Pane %d: ... to %s\n"), (int)pp+1, plot_names[ch]);
                        return (ch);
                    }
                }
            }
        }

        if (millis() - t0 > MENU_TO) {
            // timeout same as tap outside the box, ie, no change
            break;
        }

        // spin
        updateClocks(false);
        wdDelay(200);
    }

    // discard any extra taps
    drainTouch();

    // did not tap a choice so return the same current choice
    Serial.printf (_FX("Pane %d: ... still %srotating from %s\n"), (int)pp+1,
                        plot_rotating[pp] ? "" : "not ", plot_names[plot_ch[pp]]);
    return (plot_ch[pp]);
}

/* return which pane is set to ch or PANE_NONE if none
 */
PlotPane findPaneForChoice (PlotChoice ch)
{
    for (int i = PANE_1; i < PANE_N; i++) {
        if (plot_ch[i] == ch) {
            return ((PlotPane)i);
        }
    }
    return (PANE_NONE);
}

/* select the next rotation plot choice for the given pane.
 * N.B. we only choose from a select subset
 */
PlotChoice getNextRotationChoice (PlotPane pp)
{
    // search starting after current selection
    for (int i = 1; i < PLOT_CH_N; i++) {
        PlotChoice ch = (PlotChoice) ((int)(plot_ch[pp] + i) % PLOT_CH_N);
        if (ch == PLOT_CH_DXCLUSTER || ch == PLOT_CH_GIMBAL)    // skip these
            continue;
        if (plotChoiceIsAvailable(ch) && findPaneForChoice(ch) == PANE_NONE)
            return (ch);
    }

    fatalError (_FX("Bug! getNextRotationChoice() none for pane %d"), (int)pp+1);
    return (plot_ch[pp]);
}

/* save the given plot choice to NV
 */
void savePlotChoiceNV (PlotPane new_pp, PlotChoice new_ch)
{
    uint8_t ch = (uint8_t) new_ch;

    switch (new_pp) {
    case PANE_1:
        NVWriteUInt8 (NV_PLOT_1, ch);
        break;
    case PANE_2:
        NVWriteUInt8 (NV_PLOT_2, ch);
        break;
    case PANE_3:
        NVWriteUInt8 (NV_PLOT_3, ch);
        break;
    default:
        fatalError (_FX("Bug! savePlotChoiceNV() bad plot pane %d"), (int)new_pp);
        break;
    }
}

/* retrieve the plot choice for the given pane from NV, if set
 */
bool getPlotChoiceNV (PlotPane new_pp, PlotChoice *new_ch)
{
    bool ok = false;
    uint8_t ch;

    switch (new_pp) {
    case PANE_1:
        ok = NVReadUInt8 (NV_PLOT_1, &ch);
        break;
    case PANE_2:
        ok = NVReadUInt8 (NV_PLOT_2, &ch);
        break;
    case PANE_3:
        ok = NVReadUInt8 (NV_PLOT_3, &ch);
        break;
    default:
        fatalError (_FX("Bug! getPlotChoiceNV() bad plot pane %d"), (int)new_pp);
        return (false);
    }

    // beware just bonkers
    if (ch >= PLOT_CH_N)
        return (false);

    if (ok)
        *new_ch = (PlotChoice)ch;
    return (ok);
}

/* check for touch in the given pane, return whether ours.
 */
bool checkPlotTouch (const SCoord &s, PlotPane pp)
{
    // out fast if not ours
    SBox &box = plot_b[pp];
    if (!inBox (s, box))
        return (false);

    // check a few choices that have their own active areas
    switch (plot_ch[pp]) {
    case PLOT_CH_DXCLUSTER:
        if (checkDXTouch (s, box))
            return (true);
        break;
    case PLOT_CH_BC:
        if (checkBCTouch (s, box))
            return (true);
        break;
    case PLOT_CH_GIMBAL:
        if (checkGimbalTouch (s, box))
            return (true);
        break;
    default:
        break;
    }

    // require top 20% or so to be consistent 
    if (s.y > box.y + box.h/5)
        return (false);

    // draw menu with choices for this pane
    PlotChoice ch = askPaneChoice(pp);

    // always engage even if same to erase menu
    if (!setPlotChoice (pp, ch)) {
        fatalError (_FX("Bug! checkPlotTouch bad choice %d pane %d"), (int)ch, (int)pp);
        // never returns
    }

    // did our best
    return (true);
}

/* called once to init plot info from NV and insure legal and consistent values
 */
void initPlotPanes()
{
    const PlotChoice ch_defaults[PANE_N] = {PLOT_CH_SSN, PLOT_CH_XRAY, PLOT_CH_SDO_1};

    // retreive each pane choice, set defaults if new or now inappropriate
    for (int i = 0; i < PANE_N; i++) {
        PlotPane pp = (PlotPane)i;
        if (!getPlotChoiceNV (pp, &plot_ch[pp]) || !plotChoiceIsAvailable (plot_ch[pp])) {
            plot_ch[pp] = ch_defaults[i];
        }
    }

    // insure no two are the same
    for (int i = 0; i < PANE_N; i++) {
        for (int j = i+1; j < PANE_N; j++) {
            if (plot_ch[i] == plot_ch[j]) {
                for (int k = 0; k < PLOT_CH_N; k++) {
                    PlotChoice new_ch = (PlotChoice)k;
                    if (plotChoiceIsAvailable(new_ch) && findPaneForChoice(new_ch) == PANE_NONE) {
                        Serial.printf (_FX("Reassigning dup pane %d from %s to %s\n"), j+1,
                                        plot_names[plot_ch[j]], plot_names[new_ch]);
                        plot_ch[j] = new_ch;
                        break;
                    }
                }
            }
        }
    }

    // init state from nv
    uint16_t plotops = 0;
    if (!NVReadUInt16 (NV_PLOTOPS, &plotops))
        NVWriteUInt16 (NV_PLOTOPS, plotops);
    for (int i = 0; i < PANE_N; i++) {
        plot_rotating[i] = (plotops & PLOT_OPS_ROT(i)) != 0;
    }

    // log and save
    Serial.println (F("Plots:"));
    for (int i = 0; i < PANE_N; i++) {
        Serial.printf (_FX("    Pane %2d %s\n"), i+1, plot_names[plot_ch[i]]);
        savePlotChoiceNV ((PlotPane)i, plot_ch[i]);
    }
}

/* called to update NV_PLOTOPS from plot_rotating[]
 */
void savePlotOps()
{
    uint16_t plotops = 0;
    for (int i = 0; i < PANE_N; i++) {
        plotops |= (plot_rotating[i] ? PLOT_OPS_ROT(i) : 0);
    }
    NVWriteUInt16 (NV_PLOTOPS, plotops);
}
