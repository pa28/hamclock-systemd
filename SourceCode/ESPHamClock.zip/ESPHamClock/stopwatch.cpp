/* implement a simple stopwatch with lap timer, countdown timer and a pair of Big Clocks.
 */


#include "HamClock.h"



// LED purpose
typedef enum {
    LED_OFF,
    LED_OK,
    LED_SOON,
    LED_EXPIRED
} LEDPurpose;


/* only RPi can control LEDs and start switch for countdown control
 */
#if defined (_IS_RPI)

static void setLEDPurpose (LEDPurpose c_code)
{
    // ignore if not supposed to use GPIO
    if (!GPIOOk())
        return;

    // one-time log of first GPIO usage
    static bool logged;
    if (!logged) {
        Serial.println (F("SW: Prep countdown GPIO"));
        logged = true;
    }

    RPiGPIO& gpio = RPiGPIO::getRPiGPIO();

    gpio.setAsOutput (SW_RED_GPIO);
    gpio.setAsOutput (SW_GRN_GPIO);

    switch (c_code) {
    case LED_OFF:
        gpio.setHi (SW_RED_GPIO);
        gpio.setHi (SW_GRN_GPIO);
        break;
    case LED_OK:
        gpio.setHi (SW_RED_GPIO);
        gpio.setLo (SW_GRN_GPIO);
        break;
    case LED_SOON:
        gpio.setHi (SW_RED_GPIO);
        gpio.setLo (SW_GRN_GPIO);
        break;
    case LED_EXPIRED:
        gpio.setLo (SW_RED_GPIO);
        gpio.setHi (SW_GRN_GPIO);
        break;
    }
}

static bool isCountdownButtonTrue()
{
    // ignore if not supposed to use GPIO
    if (!GPIOOk())
        return (false);

    RPiGPIO& gpio = RPiGPIO::getRPiGPIO();
    gpio.setAsInput (SW_RUN_GPIO);
    return (gpio.isReady() && !gpio.readPin(SW_RUN_GPIO));
}

#else // !_IS_RPI

// dummies
static void setLEDPurpose (LEDPurpose c_code) { (void)c_code; }
static bool isCountdownButtonTrue() { return (false); }

#endif // _IS_RPI



// set from setup or setSWState(), ms
uint32_t countdown_period;

// current state
bool sw_isup;                                   // normal stopwatch is up
bool sw_bcisup;                                 // either Big Clock is up
bool sw_wantdbc;                                // want Digital Big Clock, as opposed to analog
static SW_State sw_state;


// stopwatch params
#define SW_NDIG         9               	// number of display digits
#define SW_BG           RA8875_BLACK    	// bg color
#define SW_X0           105             	// x coord of left-most digit
#define SW_GAP          30              	// gap between digits
#define SW_Y0           150             	// upper left Y of all digits
#define SW_W            40              	// digit width
#define SW_H            100             	// digit heigth
#define SW_FLT          20                      // line thickness as fraction of SW_W
#define SW_PUNCR        3               	// punctuation radius
#define SW_BAX          240             	// control button A x
#define SW_BBX          440             	// control button B x
#define SW_EXITX        670             	// exit button x
#define SW_EXITY        420             	// exit button y
#define SW_BCX          10              	// big-clock button x
#define SW_BCY          SW_EXITY             	// big-clock button y
#define SW_BY           350             	// control button y
#define SW_BW           120             	// button width
#define SW_BH           40              	// button height
#define SW_CX           SW_BAX          	// color scale x
#define SW_CY           SW_EXITY        	// color scale y
#define SW_CW           (SW_BBX+SW_BW-SW_CX)    // color scale width
#define SW_CH           SW_BH              	// color scale height
#define SW_HSV_S        200                     // color scale HSV saturation, 0..255
#define SW_HSV_V        255                     // color scale HSV value, 0..255
#define SW_CD_X         300                     // countdown button x
#define SW_CD_Y         75                      // countdown button y
#define SW_CD_W         200                     // countdown button width
#define SWCD_WARNING    60000                   // icon warning color time, ms
#define SW_BCDATEBIT    1                       // NV_SWFLAGS bit mask for showing bigclock date
#define SW_BCWXBIT      2                       // NV_SWFLAGS bit mask for showing bigclock weather
#define SW_WDBCBIT      4                       // NV_SWFLAGS bit mask for whether big clock is digital

// big analog clock params
#define BAC_X0          400                     // x center
#define BAC_Y0          240                     // y center
#define BAC_MNR         210                     // minute hand radius
#define BAC_SCR         180                     // second hand radius
#define BAC_HRR         130                     // hour hand radius
#define BAC_FR          232                     // face radius
#define BAC_BEZR        238                     // bezel radius
#define BAC_HTR         12                      // hour tick radius
#define BAC_MTR         5                       // minute tick radius
#define BAC_DOTR        2                       // center dot radius
#define BAC_HRTH        deg2rad(10.0F)          // hour hand thickness half-angle, rads
#define BAC_MNTH        (BAC_HRTH*BAC_HRR/BAC_MNR) // minute hand thickness half-angle, rads
#define BAC_HTTH        deg2rad(0.6F)           // hour tick half-angle as seen from center, rads
#define BAC_FCOL        sw_col                  // face color
#define BAC_HRCOL       sw_col                  // hour hand color
#define BAC_MNCOL       sw_col                  // minute hand color
#define BAC_SCCOL       GRAY                    // second hand color
#define BAC_BKCOL       RA8875_BLUE             // Back button color
#define BAC_BEZCOL      GRAY                    // bezel color
#define BAC_BADX        2                       // x coord of bad time message
#define BAC_BADY        400                     // y coord of bad time message
#define BAC_DATEX       2                       // date box X -- just to anchor text
#define BAC_DATEY       2                       // date box Y -- just to anchor text
#define BAC_DATEW       200                     // date box width -- used just for tapping
#define BAC_DATEH       200                     // date box height -- used just for tapping
#define BAC_WXX         (800-PLOTBOX_W-1)       // weather box X
#define BAC_WXY         5                       // weather box Y
#define BAC_WXW         PLOTBOX_W               // weather box width
#define BAC_WXH         PLOTBOX_H               // weather box height
#define BAC_WXGDT       (30L*60*1000)           // weather update period when good, millis
#define BAC_WXFDT       (6*1000)                // weather update period when fail, millis

// big digital clock params
#define BDC_W           100                     // digit width
#define BDC_H           (2*BDC_W)               // digit height
#define BDC_X0          (400-3*BDC_W)           // left x
#define BDC_Y0          (BAC_WXY+BAC_WXH+20)    // top y
#define BDC_ST          5                       // segment thickness as fraction of BDC_W
#define BDC_GAP         (BDC_W/2)               // gap between adjacent digits
#define BDC_CR          (BDC_W/BDC_ST/2)        // colon radius
#define BDC_BADX        350                     // x coord of bad time message
#define BDC_BADY        50                      // y coord of bad time message
#if BDC_X0+BDC_W+BDC_GAP+BDC_W+2*BDC_GAP+BDC_W+BDC_GAP+BDC_W+BDC_GAP > 800
#error Big Digital Clock digits too wide
#endif
#if BDC_Y0+BDC_H > 480
#error Big Digital Clock digits too tall
#endif

// button labels
static char cd_lbl[] = "Count down";
static char lap_lbl[] = "Lap";
static char reset_lbl[] = "Reset";
static char resume_lbl[] = "Resume";
static char run_lbl[] = "Run";
static char stop_lbl[] = "Stop";
static char exit_lbl[] = "Exit";
static char bigclock_lbl[] = "Big Clock";

// current stopwatch digits
static uint8_t swdigits[SW_NDIG];

// millis() at start or since stop, when counting down start_t is when begun
static uint32_t start_t, stop_dt;

// stopwatch controls
static SBox countdown_b = {SW_CD_X, SW_CD_Y, SW_CD_W, SW_BH};
static SBox A_b = {SW_BAX, SW_BY, SW_BW, SW_BH};
static SBox B_b = {SW_BBX, SW_BY, SW_BW, SW_BH};
static SBox exit_b = {SW_EXITX, SW_EXITY, SW_BW, SW_BH};
static SBox bigclock_b = {SW_BCX, SW_BCY, SW_BW, SW_BH};
static SBox color_b = {SW_CX, SW_CY, SW_CW, SW_CH};
static uint8_t sw_hue;                          // hue 0..255
static uint16_t sw_col;                         // color pixel

// controls for big clock
static SBox bcdate_b = {BAC_DATEX, BAC_DATEY, BAC_DATEW, BAC_DATEH};
static SBox bcwx_b = {BAC_WXX, BAC_WXY, BAC_WXW, BAC_WXH};
static bool bcdate_on, bcwx_on;
static uint32_t bc_prev_wx;                     // big clock shared time of prev drawn wx, millis
static uint32_t bc_wxdt = BAC_WXGDT;            // big clock shared weather update interval, millis


/* log our state to main server, if ok with user
 */
static void logSWState()
{
    if (logUsageOk()) {
        char ver[50];
        (void) newVersionIsAvailable (ver, sizeof(ver));
    }
}

/* save persistent state
 */
static void saveSWNV()
{
    uint16_t s = 0;
    if (bcdate_on)
        s |= SW_BCDATEBIT;
    if (bcwx_on)
        s |= SW_BCWXBIT;
    if (sw_wantdbc)
        s |= SW_WDBCBIT;
    NVWriteUInt16 (NV_SWFLAGS, s);
}

/* retrieve persistent state
 */
void getSWNV()
{
    uint16_t s;
    if (!NVReadUInt16 (NV_SWFLAGS, &s))
        s = SW_BCDATEBIT | SW_BCWXBIT;
    bcdate_on = (s & SW_BCDATEBIT) == SW_BCDATEBIT;
    bcwx_on = (s & SW_BCWXBIT) == SW_BCWXBIT;
    sw_wantdbc = (s & SW_WDBCBIT) == SW_WDBCBIT;
}

/* return ms countdown time remaining, if any
 */
static uint32_t getCountdownLeft()
{
    if (sw_state == SWS_COUNTDOWN) {
        uint32_t since_start = millis() - start_t;
        if (since_start < countdown_period)
            return (countdown_period - since_start);
    }
    return (0);
}

/* decide visuals depending on current state:
 *   main_color is the count down text on the Main page (only used if showing Main page and counting down)
 *   led_purpose is the LED state to display
 *   button_state is the Stopwatch Count down button normal or reverse (only used if showing SW page)
 * return whether any changed from previous call.
 */
static bool getVisuals (uint16_t *main_color, LEDPurpose *led_purpose, bool *button_state)
{   
    static uint16_t prev_mc;
    static LEDPurpose prev_lp;
    static bool prev_bs;
    
    // decide current state
    uint16_t mc;
    LEDPurpose lp;
    bool bs;
    if (sw_state == SWS_COUNTDOWN) {
        uint32_t ms_left = getCountdownLeft();
        if (ms_left >= SWCD_WARNING) {
            // plenty of time
            mc = RA8875_GREEN;
            lp = LED_OK;
            bs = true;
        } else { 
            bool flash_state = (millis()%500) < 250;            // flip at 2 Hz
            if (ms_left > 0) {
                // timeout soon
                mc = RGB565(255,212,112);                       // real YELLOW looks too pale
                lp = flash_state ? LED_SOON : LED_OFF;
                bs = flash_state;
            } else {
                // timed out
                mc = flash_state ? RA8875_RED : RA8875_BLACK;
                lp = flash_state ? LED_EXPIRED : LED_OFF;
                bs = flash_state;
            }
        }
    } else {
        // count down not running
        mc = RA8875_GREEN;
        lp = LED_OFF;
        bs = false;
    }

    // pass back
    *main_color = mc;
    *led_purpose = lp;
    *button_state = bs;
    
    // check if any changed 
    bool new_vis = mc != prev_mc || lp != prev_lp || bs != prev_bs; 

    // persist
    prev_mc = mc; 
    prev_lp = lp; 
    prev_bs = bs; 
    
    // whether any changed
    return (new_vis);
}



/* set sw_col from sw_hue
 */
static void setSWColor()
{
    uint8_t r, g, b;
    hsvtorgb (&r, &g, &b, sw_hue, SW_HSV_S, SW_HSV_V);
    sw_col = RGB565 (r, g, b);
}

/* draw the color control box
 */
static void drawColorScale()
{
    // erase to remove tick marks
    tft.fillRect (color_b.x, color_b.y, color_b.w, color_b.h, RA8875_BLACK);

    // rainbow
    for (uint16_t dx = 0; dx < color_b.w; dx++) {
        uint8_t r, g, b;
        uint8_t h = 255*dx/color_b.w;
        hsvtorgb (&r, &g, &b, h, SW_HSV_S, SW_HSV_V);
        uint16_t c = RGB565 (r, g, b);
        // tft.drawLine (color_b.x + dx, color_b.y, color_b.x + dx, color_b.y + color_b.h, c);
        tft.drawPixel (color_b.x + dx, color_b.y + color_b.h/2, c);
    }

    // mark it
    uint16_t hue_x = color_b.x + sw_hue*color_b.w/255;
    tft.drawLine (hue_x, color_b.y+3*color_b.h/8, hue_x, color_b.y+5*color_b.h/8, RA8875_WHITE);
}

/* draw the given digit in the given bounding box with lines the given fractional thickness of box width.
 */
static void drawDigit (const SBox &b, int digit, int frac_thick)
{
    uint16_t lt = b.w/frac_thick;
    uint16_t l2 = b.w/(2*frac_thick);

    // erase 
    tft.fillRect (b.x, b.y, b.w, b.h, SW_BG);

    // draw digit -- replace with drawRect to check boundaries
    switch (digit) {
    case 0:
        tft.fillRect (b.x, b.y, b.w, lt, sw_col);
        tft.fillRect (b.x, b.y+lt, lt, b.h-2*lt, sw_col);
        tft.fillRect (b.x, b.y+b.h-lt, b.w, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y+lt, lt, b.h-2*lt, sw_col);
        break;
    case 1:
        tft.fillRect (b.x+b.w/2-l2, b.y, lt, b.h, sw_col);      // center column
        break;
    case 2:
        tft.fillRect (b.x, b.y, b.w, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y+lt, lt, b.h/2-lt-l2, sw_col);
        tft.fillRect (b.x, b.y+b.h/2-l2, b.w, lt, sw_col);
        tft.fillRect (b.x, b.y+b.h/2+l2, lt, b.h/2-lt-l2, sw_col);
        tft.fillRect (b.x, b.y+b.h-lt, b.w, lt, sw_col);
        break;
    case 3:
        tft.fillRect (b.x, b.y, b.w, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y+lt, lt, b.h-2*lt, sw_col);
        tft.fillRect (b.x, b.y+b.h/2-l2, b.w-lt, lt, sw_col);
        tft.fillRect (b.x, b.y+b.h-lt, b.w, lt, sw_col);
        break;
    case 4:
        tft.fillRect (b.x, b.y, lt, b.h/2+l2, sw_col);
        tft.fillRect (b.x+lt, b.y+b.h/2-l2, b.w-2*lt, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y, lt, b.h, sw_col);
        break;
    case 5:
        tft.fillRect (b.x, b.y, b.w, lt, sw_col);
        tft.fillRect (b.x, b.y+lt, lt, b.h/2-lt-l2, sw_col);
        tft.fillRect (b.x, b.y+b.h/2-l2, b.w, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y+b.h/2+l2, lt, b.h/2-lt-l2, sw_col);
        tft.fillRect (b.x, b.y+b.h-lt, b.w, lt, sw_col);
        break;
    case 6:
        tft.fillRect (b.x, b.y, lt, b.h, sw_col);
        tft.fillRect (b.x+lt, b.y, b.w-lt, lt, sw_col);
        tft.fillRect (b.x+lt, b.y+b.h/2-l2, b.w-lt, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y+b.h/2+l2, lt, b.h/2-l2-lt, sw_col);
        tft.fillRect (b.x+lt, b.y+b.h-lt, b.w-lt, lt, sw_col);
        break;
    case 7:
        tft.fillRect (b.x, b.y, b.w, lt, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y+lt, lt, b.h-lt, sw_col);
        break;
    case 8:
        tft.fillRect (b.x, b.y, lt, b.h, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y, lt, b.h, sw_col);
        tft.fillRect (b.x+lt, b.y, b.w-2*lt, lt, sw_col);
        tft.fillRect (b.x+lt, b.y+b.h/2-l2, b.w-2*lt, lt, sw_col);
        tft.fillRect (b.x+lt, b.y+b.h-lt, b.w-2*lt, lt, sw_col);
        break;
    case 9:
        tft.fillRect (b.x, b.y, lt, b.h/2+l2, sw_col);
        tft.fillRect (b.x+b.w-lt, b.y, lt, b.h, sw_col);
        tft.fillRect (b.x+lt, b.y, b.w-2*lt, lt, sw_col);
        tft.fillRect (b.x+lt, b.y+b.h/2-l2, b.w-2*lt, lt, sw_col);
        break;
    default:
        Serial.printf (_FX("Bug! drawDigit %d\n"), digit);
        break;
    }
}


/* draw the given stopwatch digit in the given position 0 .. SW_NDIG-1.
 * use swdigits[] to avoid erasing/redrawing the same digit again.
 */
static void drawSWDigit (uint8_t position, uint8_t digit)
{
    // check for no change
    if (swdigits[position] == digit)
        return;
    swdigits[position] = digit;

    // bounding box
    SBox b;
    b.x = SW_X0 + (SW_W+SW_GAP)*position;
    b.y = SW_Y0;
    b.w = SW_W;
    b.h = SW_H;

    // draw
    drawDigit (b, digit, SW_FLT);
}

/* display the given time value in millis()
 */
static void drawSWTime(uint32_t t)
{
    t %= (100UL*60UL*60UL*1000UL);                        // msec in SW_NDIG digits

    uint8_t tenhr = t / (10UL*3600UL*1000UL);
    t -= tenhr * (10UL*3600UL*1000UL);
    drawSWDigit (0, tenhr);

    uint8_t onehr = t / (3600UL*1000UL);
    t -= onehr * (3600UL*1000UL);
    drawSWDigit (1, onehr);

    uint8_t tenmn = t / (600UL*1000UL);
    t -= tenmn * (600UL*1000UL);
    drawSWDigit (2, tenmn);

    uint8_t onemn = t / (60UL*1000UL);
    t -= onemn * (60UL*1000UL);
    drawSWDigit (3, onemn);

    uint8_t tensec = t / (10UL*1000UL);
    t -= tensec * (10UL*1000UL);
    drawSWDigit (4, tensec);

    uint8_t onesec = t / (1UL*1000UL);
    t -= onesec * (1UL*1000UL);
    drawSWDigit (5, onesec);

    uint8_t tenthsec = t / (100UL);
    t -= tenthsec * (100UL);
    drawSWDigit (6, tenthsec);

    uint8_t hundsec = t / (10UL);
    t -= hundsec * (10UL);
    drawSWDigit (7, hundsec);

    uint8_t thousec = t / (1UL);
    drawSWDigit (8, thousec);

    // immediate
    tft.drawPR();

}


/* draw remaining count down time and manage the state of the count down button and LED.
 * N.B. we assume sw_state == SWS_COUNTDOWN
 */
static void drawCountdownTime()
{
    // always draw remaining time left
    uint32_t ms_left = getCountdownLeft();
    drawSWTime(ms_left);

    // update state if any change
    uint16_t main_color;
    LEDPurpose led_purpose;
    bool button_state;
    if (getVisuals (&main_color, &led_purpose, &button_state)) {
        drawStringInBox (cd_lbl, countdown_b, button_state, sw_col);
        setLEDPurpose (led_purpose);
    }
}


/* draw time and buttons given current state, or main page icon if not showing sw page.
 */
static void drawSWState()
{
    if (sw_isup) {

        switch (sw_state) {
        case SWS_RESET:
            drawSWTime(0);
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (run_lbl, A_b, false, sw_col);
            drawStringInBox (reset_lbl, B_b, false, sw_col);
            break;
        case SWS_RUN:
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (stop_lbl, A_b, false, sw_col);
            drawStringInBox (lap_lbl, B_b, false, sw_col);
            break;
        case SWS_STOP:
            drawSWTime(stop_dt);        // show stopped time
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (run_lbl, A_b, false, sw_col);
            drawStringInBox (reset_lbl, B_b, false, sw_col);
            break;
        case SWS_LAP:
            drawSWTime(stop_dt);        // show lap hold time
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (reset_lbl, A_b, false, sw_col);
            drawStringInBox (resume_lbl, B_b, false, sw_col);
            break;
        case SWS_COUNTDOWN:
            drawCountdownTime();
            drawStringInBox (cd_lbl, countdown_b, true, sw_col);
            drawStringInBox (reset_lbl, A_b, false, sw_col);
            drawStringInBox (reset_lbl, B_b, false, sw_col);
            break;
        }

    } else {

        drawMainPageStopwatch(true);
    }
}



/* draw either BigClock state awareness message as needed
 */
static void drawBCAwareness (bool force)
{
    // whether time was ok last iteration
    static bool time_was_ok;

    // current state
    bool clock_ok = clockTimeOk();
    bool ut_zero = utcOffset() == 0;
    bool time_ok_now = clock_ok && ut_zero;

    // update if force or new state
    if (force || !time_ok_now || time_ok_now != time_was_ok) {

        // location depends on which big clock
        uint16_t x = sw_wantdbc ? BDC_BADX : BAC_BADX;
        uint16_t y = sw_wantdbc ? BDC_BADY : BAC_BADY;

        if (time_ok_now) {
            // erase
            tft.fillRect (x, y, 200, 40, RA8875_BLACK);
        } else {
            selectFontStyle (BOLD_FONT, SMALL_FONT);
            tft.setCursor (x, y+27);
            tft.setTextColor (RA8875_RED);
            if (!clock_ok)
                tft.print ("Unknown accuracy");
            else
                tft.print ("Time is offset");
        }

        // persist
        time_was_ok = time_ok_now;
    }
}


/* refresh date in bcdate_b
 * N.B. we never erase because Wednesday overlays clock
 */
static void drawBCDate (int hr, int dy, int wd, int mo)
{
    selectFontStyle (BOLD_FONT, LARGE_FONT);
    tft.setTextColor (BAC_FCOL);
    tft.setCursor (bcdate_b.x, bcdate_b.y + 50);
    tft.print (dayStr(wd));

    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    tft.setCursor (bcdate_b.x, bcdate_b.y + 90);
    if (useMetricUnits())
        tft.printf (_FX("%d %s"), dy, monthStr(mo));
    else
        tft.printf (_FX("%s %d"), monthStr(mo), dy);

    if (!sw_wantdbc) {
        // AM PM not needed for 24 hour digital clock
        tft.setCursor (bcdate_b.x, bcdate_b.y + 125);
        tft.print (hr < 12 ? "AM" : "PM");
    }

    // tft.drawRect (bcdate_b.x, bcdate_b.y, bcdate_b.w, bcdate_b.h, RA8875_WHITE);
}

/* refresh DE weather in bcwx_b, return whether successful
 */
static bool drawBCWx(void)
{
    WXInfo wi;
    char ynot[100];
    bool ok = getCurrentWX (de_ll, true, &wi, ynot);
    if (ok)
        plotWX (bcwx_b, BAC_FCOL, wi);
    else
        plotMessage (bcwx_b, RA8875_RED, ynot);

    // undo border
    tft.drawRect (bcwx_b.x, bcwx_b.y, bcwx_b.w, bcwx_b.h, RA8875_BLACK);

    return (ok);
}

/* draw the given big digital clock digit in the given position 0 .. 3
 */
static void drawBDCDigit (uint8_t position, uint8_t digit)
{
    // bounding box
    SBox b;
    b.x = BDC_X0 + (BDC_W+BDC_GAP)*position + (position >= 2)*BDC_GAP;
    b.y = BDC_Y0;
    b.w = BDC_W;
    b.h = BDC_H;

    // draw
    drawDigit (b, digit, BDC_ST);
}

/* draw the digital Big Clock 
 */
static void drawDigitalBigClock (bool all)
{

    // persist to allow checking for change
    static time_t prev_t0;                              // previous report time
    static uint8_t prev_mnten, prev_mnmn;               // previous mo tens and unit
    static uint8_t prev_hr, prev_mo, prev_dy;           // previous drawn date info

    // get local time now, including any user offset
    time_t t0 = nowWO() + de_tz.tz_secs;

    // done if same second unless all
    if (!all && t0 == prev_t0)
        return;

    // crack open
    uint8_t hr = hour(t0);
    uint8_t mn = minute(t0);
    int dy = day(t0);
    int mo = month(t0);
    uint8_t mnmn = mn%10;

    // initial erase or new day
    if (all || (bcdate_on && (dy != prev_dy || mo != prev_mo))) {
        eraseScreen();
        all = true;     // insure everything gets redrawn
        // date
        if (bcdate_on) {
            drawBCDate (hr, dy, weekday(t0), mo);
            prev_dy = dy;
            prev_mo = mo;
        }
    }

    // toggle punctuation every second
    if (all || t0 != prev_t0) {
        uint16_t x = BDC_X0 + BDC_W + BDC_GAP + BDC_W + BDC_GAP;
        uint16_t color = all || (t0&1) ? sw_col : SW_BG;
        tft.fillCircle (x, BDC_Y0 + BDC_H/3,   BDC_CR, color);
        tft.fillCircle (x, BDC_Y0 + 2*BDC_H/3, BDC_CR, color);
        prev_t0 = t0;
    }

    // update minutes every minute
    if (all || mnmn != prev_mnmn) {

        // minute for sure
        drawBDCDigit (3, mnmn);
        prev_mnmn = mnmn;

        // and tens of minutes too if changed
        uint8_t mnten = mn/10;
        if (all || mnten != prev_mnten) {
            drawBDCDigit (2, mnten);
            prev_mnten = mnten;
        }
    }

    // update hour every hour
    if (all || hr != prev_hr) {
        drawBDCDigit (0, hr/10);
        drawBDCDigit (1, hr%10);
        prev_hr = hr;
    }

    // update awareness
    drawBCAwareness (all);

    // update weather if desired and all or new
    if (bcwx_on && (timesUp(&bc_prev_wx, bc_wxdt) || all))
        bc_wxdt = drawBCWx() ? BAC_WXGDT : BAC_WXFDT;

    // immediate
    tft.drawPR();
}


/* draw analog Big Clock
 */
static void drawAnalogBigClock (bool all)
{
    // points 1 and 2 are the fat positions part way out, point 3 is the far tip, "point" 0 is the center

    // persistent time measures
    static time_t prev_t0;                              // detect change of secs
    static uint8_t prev_mo, prev_dy;                    // previously drawn date info

    // previous hand positions for motion detection and exact erasing
    static int16_t prev_hrdx1, prev_hrdx2, prev_hrdx3, prev_hrdy1, prev_hrdy2, prev_hrdy3;
    static int16_t prev_mndx1, prev_mndx2, prev_mndx3, prev_mndy1, prev_mndy2, prev_mndy3;
    static int16_t prev_scdx3, prev_scdy3;

    // get local time now, including any user offset
    time_t t0 = nowWO() + de_tz.tz_secs;

    // wait for second to change unless all
    if (!all && t0 == prev_t0)
        return;
    prev_t0 = t0;

    // crack open
    int hr = hour(t0);
    int mn = minute(t0);
    int sc = second(t0);
    int dy = day(t0);
    int mo = month(t0);

    // refresh if desired or new date (since we never erase the date)
    if (all || (bcdate_on && (dy != prev_dy || mo != prev_mo))) {

        // fresh face
        eraseScreen();

        // face perimeter
      #if defined (_IS_ESP8266)
        // avoids bright flash of circle filling but doesn't fill at higher display sizes
        for (uint16_t r = BAC_FR+1; r <= BAC_BEZR; r++)
            tft.drawCircle (BAC_X0, BAC_Y0, r, BAC_BEZCOL);
      #else
        tft.fillCircle (BAC_X0, BAC_Y0, BAC_BEZR, BAC_BEZCOL);
        tft.fillCircle (BAC_X0, BAC_Y0, BAC_FR, RA8875_BLACK);
      #endif
        tft.drawCircle (BAC_X0, BAC_Y0, BAC_FR, BAC_FCOL);

        // hour points
        for (int i = 0; i < 12; i++) {
            float a = deg2rad(360.0F*i/12.0F);
            uint16_t x0 = roundf(BAC_X0 + (BAC_FR-BAC_HTR) * cosf(a));
            uint16_t y0 = roundf(BAC_Y0 + (BAC_FR-BAC_HTR) * sinf(a));
            uint16_t x1 = roundf(BAC_X0 + BAC_FR * cosf(a-BAC_HTTH));
            uint16_t y1 = roundf(BAC_Y0 + BAC_FR * sinf(a-BAC_HTTH));
            uint16_t x2 = roundf(BAC_X0 + BAC_FR * cosf(a+BAC_HTTH));
            uint16_t y2 = roundf(BAC_Y0 + BAC_FR * sinf(a+BAC_HTTH));
            tft.drawLine (x0, y0, x1, y1, 1, BAC_FCOL);
            tft.drawLine (x0, y0, x2, y2, 1, BAC_FCOL);
        }

        // minute ticks
        for (int i = 0; i < 60; i++) {
            if ((i % 5) == 0)
                continue;                               // don't overdraw hour marks
            float a = deg2rad(360.0F*i/60.0F);
            uint16_t x0 = roundf(BAC_X0 + BAC_FR * cosf(a));
            uint16_t y0 = roundf(BAC_Y0 + BAC_FR * sinf(a));
            uint16_t x1 = roundf(BAC_X0 + (BAC_FR-BAC_MTR) * cosf(a));
            uint16_t y1 = roundf(BAC_Y0 + (BAC_FR-BAC_MTR) * sinf(a));
            tft.drawLine (x0, y0, x1, y1, 1, BAC_FCOL);
        }

        // init all locations bogus but inside face and not 0
        prev_hrdx1 = prev_hrdy1 = 10;
        prev_mndx1 = prev_mndy1 = 10;
        prev_hrdx2 = prev_hrdy2 = 20;
        prev_mndx2 = prev_mndy2 = 20;
        prev_hrdx3 = prev_hrdy3 = 30;
        prev_mndx3 = prev_mndy3 = 30;
        prev_scdx3 = prev_scdy3 = 30;

        // date
        if (bcdate_on) {
            drawBCDate (hr, dy, weekday(t0), mo);
            prev_dy = dy;
            prev_mo = mo;
        }
    }

    // find central angle and far tip location of each hand
    float hr_angle = deg2rad(30*(3-(((hr+24)%12) + mn/60.0F)));
    float mn_angle = deg2rad(6*(15-(mn+sc/60.0F)));
    float sc_angle = deg2rad(6*(15-sc));
    int16_t hrdx3 = roundf(BAC_HRR * cosf(hr_angle));
    int16_t hrdy3 = roundf(BAC_HRR * sinf(hr_angle));
    int16_t mndx3 = roundf(BAC_MNR * cosf(mn_angle));
    int16_t mndy3 = roundf(BAC_MNR * sinf(mn_angle));
    int16_t scdx3 = roundf(BAC_SCR * cosf(sc_angle));
    int16_t scdy3 = roundf(BAC_SCR * sinf(sc_angle));

    // erase and update hand position if far tip moved
    bool hr_moved = hrdx3 != prev_hrdx3 || hrdy3 != prev_hrdy3;
    bool mn_moved = mndx3 != prev_mndx3 || mndy3 != prev_mndy3;
    bool sc_moved = scdx3 != prev_scdx3 || scdy3 != prev_scdy3;
    if (hr_moved) {
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_hrdx1, BAC_Y0-prev_hrdy1, 1, RA8875_BLACK);
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_hrdx2, BAC_Y0-prev_hrdy2, 1, RA8875_BLACK);
        tft.drawLine (BAC_X0+prev_hrdx1,BAC_Y0-prev_hrdy1,BAC_X0+prev_hrdx3,BAC_Y0-prev_hrdy3,1,RA8875_BLACK);
        tft.drawLine (BAC_X0+prev_hrdx2,BAC_Y0-prev_hrdy2,BAC_X0+prev_hrdx3,BAC_Y0-prev_hrdy3,1,RA8875_BLACK);
        prev_hrdx1 = roundf(BAC_HRR/3.0F * cosf(hr_angle-BAC_HRTH));
        prev_hrdy1 = roundf(BAC_HRR/3.0F * sinf(hr_angle-BAC_HRTH));
        prev_hrdx2 = roundf(BAC_HRR/3.0F * cosf(hr_angle+BAC_HRTH));
        prev_hrdy2 = roundf(BAC_HRR/3.0F * sinf(hr_angle+BAC_HRTH));
        prev_hrdx3 = hrdx3;
        prev_hrdy3 = hrdy3;
    }
    if (mn_moved) {
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_mndx1, BAC_Y0-prev_mndy1, 1, RA8875_BLACK);
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_mndx2, BAC_Y0-prev_mndy2, 1, RA8875_BLACK);
        tft.drawLine (BAC_X0+prev_mndx1,BAC_Y0-prev_mndy1,BAC_X0+prev_mndx3,BAC_Y0-prev_mndy3,1,RA8875_BLACK);
        tft.drawLine (BAC_X0+prev_mndx2,BAC_Y0-prev_mndy2,BAC_X0+prev_mndx3,BAC_Y0-prev_mndy3,1,RA8875_BLACK);
        prev_mndx1 = roundf(BAC_MNR/3.0F * cosf(mn_angle-BAC_MNTH));
        prev_mndy1 = roundf(BAC_MNR/3.0F * sinf(mn_angle-BAC_MNTH));
        prev_mndx2 = roundf(BAC_MNR/3.0F * cosf(mn_angle+BAC_MNTH));
        prev_mndy2 = roundf(BAC_MNR/3.0F * sinf(mn_angle+BAC_MNTH));
        prev_mndx3 = mndx3;
        prev_mndy3 = mndy3;
    }
    if (sc_moved) {
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_scdx3, BAC_Y0-prev_scdy3, 1, RA8875_BLACK);
        prev_scdx3 = scdx3;
        prev_scdy3 = scdy3;
    }

    // draw hand if moved or likely clobbered by another hand erasure
    float hr_sc_angle = fabs(hr_angle - sc_angle);
    float hr_mn_angle = fabs(hr_angle - mn_angle);
    float mn_sc_angle = fabs(mn_angle - sc_angle);
    bool hrsc_hit = hr_sc_angle < 2*BAC_HRTH || hr_sc_angle > 2*M_PIF - 2*BAC_HRTH;    // fudge fat bottom
    bool hrmn_hit = hr_mn_angle < 2*BAC_HRTH || hr_mn_angle > 2*M_PIF - 2*BAC_HRTH;
    bool mnsc_hit = mn_sc_angle < 2*BAC_MNTH || mn_sc_angle > 2*M_PIF - 2*BAC_MNTH;
    if (hr_moved || hrsc_hit || hrmn_hit) {
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_hrdx1, BAC_Y0-prev_hrdy1, 1, BAC_HRCOL);
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_hrdx2, BAC_Y0-prev_hrdy2, 1, BAC_HRCOL);
        tft.drawLine (BAC_X0+prev_hrdx1,BAC_Y0-prev_hrdy1,BAC_X0+prev_hrdx3,BAC_Y0-prev_hrdy3,1,BAC_HRCOL);
        tft.drawLine (BAC_X0+prev_hrdx2,BAC_Y0-prev_hrdy2,BAC_X0+prev_hrdx3,BAC_Y0-prev_hrdy3,1,BAC_HRCOL);
    }
    if (mn_moved || hrmn_hit || mnsc_hit) {
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_mndx1, BAC_Y0-prev_mndy1, 1, BAC_MNCOL);
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_mndx2, BAC_Y0-prev_mndy2, 1, BAC_MNCOL);
        tft.drawLine (BAC_X0+prev_mndx1,BAC_Y0-prev_mndy1,BAC_X0+prev_mndx3,BAC_Y0-prev_mndy3,1,BAC_MNCOL);
        tft.drawLine (BAC_X0+prev_mndx2,BAC_Y0-prev_mndy2,BAC_X0+prev_mndx3,BAC_Y0-prev_mndy3,1,BAC_MNCOL);
    }
    if (sc_moved || hrsc_hit || mnsc_hit)
        tft.drawLine (BAC_X0, BAC_Y0, BAC_X0+prev_scdx3, BAC_Y0-prev_scdy3, 1, BAC_SCCOL);

    // center dot
    tft.fillCircle (BAC_X0, BAC_Y0, BAC_DOTR, BAC_BEZCOL);

    // update awareness
    drawBCAwareness (all);

    // immediate
    tft.drawPR();

    // update weather if desired and all or new
    if (bcwx_on && (timesUp(&bc_prev_wx, bc_wxdt) || all))
        bc_wxdt = drawBCWx() ? BAC_WXGDT : BAC_WXFDT;

}


/* draw the appropriate Big Clock
 */
static void drawBigClock (bool all)
{
    if (sw_wantdbc)
        drawDigitalBigClock (all);
    else
        drawAnalogBigClock (all);
}


/* init the stopwatch page.
 * N.B. do not erase screen, leave that to caller
 */
static void initSWPage()
{
    // get last color, else set default
    if (!NVReadUInt8 (NV_SWHUE, &sw_hue)) {
        sw_hue = 85;    // green
        NVWriteUInt8 (NV_SWHUE, sw_hue);
    }
    setSWColor();

    // buttons
    selectFontStyle (BOLD_FONT, SMALL_FONT);
    drawStringInBox (exit_lbl, exit_b, false, sw_col);
    drawStringInBox (bigclock_lbl, bigclock_b, false, sw_col);

    // state
    sw_isup = true;
    sw_bcisup = false;

    // log with server
    logSWState();

    // init sw digits all illegal so they all get drawn first time
    memset (swdigits, 255, sizeof(swdigits));

    // draw punctuation
    tft.fillCircle (SW_X0 + 2*SW_W + SW_GAP + SW_GAP/2,   SW_Y0 + SW_H/3,   SW_PUNCR, sw_col);
    tft.fillCircle (SW_X0 + 2*SW_W + SW_GAP + SW_GAP/2,   SW_Y0 + 2*SW_H/3, SW_PUNCR, sw_col);
    tft.fillCircle (SW_X0 + 4*SW_W + 3*SW_GAP + SW_GAP/2, SW_Y0 + SW_H/3,   SW_PUNCR, sw_col);
    tft.fillCircle (SW_X0 + 4*SW_W + 3*SW_GAP + SW_GAP/2, SW_Y0 + 2*SW_H/3, SW_PUNCR, sw_col);
    tft.fillCircle (SW_X0 + 6*SW_W + 5*SW_GAP + SW_GAP/2, SW_Y0 + SW_H,     SW_PUNCR, sw_col);

    // draw buttons from state and color scale
    drawSWState();
    drawColorScale();
}

/* check our touch controls, update state
 */
static void checkSWPageTouch()
{
    // check for touch at all
    SCoord s;
    if (readCalTouchWS(s) == TT_NONE)
        return;

    // update idle timer, ignore if this tap is restoring full brightness
    if (brightnessOn())
        return;

    // check each box depending on which page is up

    if (sw_bcisup) {

        // bigclock boxes

        if (inBox (s, bcdate_b)) {
            bcdate_on = !bcdate_on;
            saveSWNV();
            drawBigClock (true);
        } else if (inBox (s, bcwx_b)) {
            bcwx_on = !bcwx_on;
            saveSWNV();
            drawBigClock (true);
        } else {
            // tap near center toggles big clock style
            SBox cb;
            cb.w = 800/4;
            cb.h = 480/4;
            cb.x = (800-cb.w)/2;
            cb.y = (480-cb.h)/2;
            if (inBox (s, cb)) {
                sw_wantdbc = !sw_wantdbc;
                saveSWNV();
                logSWState();
                drawBigClock(true);
            } else {
                Serial.println(F("SW: BigClock exit"));
                sw_bcisup = false;
                eraseScreen();
                initSWPage();
            }
        }

    } else {

        // main stopwatch boxes

        if (inBox (s, countdown_b)) {
            // start countdown timer regardless of current state
            setSWState (SWS_COUNTDOWN, countdown_period);
        
        } else if (inBox (s, A_b)) {
            // box action depends on current state
            SW_State new_sws;
            switch (sw_state) {
            case SWS_RESET:
                // clicked Run
                new_sws = SWS_RUN;
                break;
            case SWS_RUN:
                // clicked Stop
                new_sws = SWS_STOP;
                break;
            case SWS_STOP:
                // clicked Run
                new_sws = SWS_RUN;
                break;
            case SWS_LAP:
                // clicked Reset
                new_sws = SWS_RESET;
                break;
            case SWS_COUNTDOWN:
                // clicked Reset
                new_sws = SWS_RESET;
                break;
            default:
                new_sws = SWS_RESET;
                break;
            }

            // update state and GUI
            setSWState (new_sws, countdown_period);

        } else if (inBox (s, B_b)) {
            // box action depends on current state
            SW_State new_sws;
            switch (sw_state) {
            case SWS_RESET:
                // clicked Reset
                new_sws = SWS_RESET;
                break;
            case SWS_RUN:
                // clicked Lap
                new_sws = SWS_LAP;
                break;
            case SWS_STOP:
                // clicked Reset
                new_sws = SWS_RESET;
                break;
            case SWS_LAP:
                // clicked Resume
                new_sws = SWS_RUN;
                break;
            case SWS_COUNTDOWN:
                // clicked Reset
                new_sws = SWS_RESET;
                break;
            default:
                new_sws = SWS_RESET;
                break;
            }

            // update state and GUI
            setSWState (new_sws, countdown_period);

        } else if (inBox (s, exit_b)) {
            sw_isup = false;

        } else if (inBox (s, color_b)) {
            sw_hue = 255*(s.x - color_b.x)/color_b.w;
            NVWriteUInt8 (NV_SWHUE, sw_hue);
            initSWPage();

        } else if (inBox (s, bigclock_b)) {
            Serial.println(F("SW: BigClock enter"));
            sw_bcisup = true;
            getSWNV();
            logSWState();
            drawBigClock(true);
        }
    }
}

/* draw the main page stopwatch icon or count down time remaining in stopwatch_b depending on sw_state.
 */
void drawMainPageStopwatch (bool force)
{
    if (sw_state == SWS_COUNTDOWN) {

        // get time remaining
        uint32_t ms_left = getCountdownLeft();

        // check if same second
        static uint32_t prev_sec;
        uint32_t sec = ms_left/1000;
        bool same_sec = sec == prev_sec;
        prev_sec = sec;

        // skip if no change in colors and same second remaining
        uint16_t main_color;
        LEDPurpose led_purpose;
        bool button_state;
        if (!getVisuals (&main_color, &led_purpose, &button_state) && same_sec && !force)
            return;

        // update LED
        setLEDPurpose (led_purpose);

        // break into H:M:S
        ms_left += 500;         // round
        uint8_t hr = ms_left / 3600000;
        ms_left -= hr * 3600000;
        uint8_t mn = ms_left / 60000;
        ms_left -= mn * 60000;
        uint8_t sc = ms_left/1000;

        // format
        selectFontStyle (LIGHT_FONT, FAST_FONT);
        char buf[32];
        if (hr == 0)
            sprintf (buf, "%d:%02d", mn, sc);
        else
            sprintf (buf, "%dh%02d", hr, mn);
        uint16_t cdw = getTextWidth(buf);

        // erase and draw
        tft.fillRect (stopwatch_b.x, stopwatch_b.y, stopwatch_b.w, stopwatch_b.h, RA8875_BLACK);
        tft.setTextColor (main_color);
        tft.setCursor (stopwatch_b.x + (stopwatch_b.w-cdw)/2, stopwatch_b.y+stopwatch_b.h/4);
        tft.print (buf);

    } else if (force) {

        // draw icon

        // erase
        tft.fillRect (stopwatch_b.x, stopwatch_b.y, stopwatch_b.w, stopwatch_b.h, RA8875_BLACK);

        // radius and step
        uint16_t r = 3*stopwatch_b.h/8;
        uint16_t xc = stopwatch_b.x + stopwatch_b.w/2;
        uint16_t yc = stopwatch_b.y + stopwatch_b.h/2;
        uint16_t dx = r*cosf(deg2rad(45)) + 0.5F;

        // watch
        tft.fillCircle (xc, yc, r, GRAY);

        // top stem
        tft.fillRect (xc-1, yc-r-3, 3, 4, GRAY);

        // 2 side stems
        tft.fillCircle (xc-dx, yc-dx-1, 1, GRAY);
        tft.fillCircle (xc+dx, yc-dx-1, 1, GRAY);

        // face
        tft.drawCircle (xc, yc, 3*stopwatch_b.h/10, RA8875_BLACK);

        // hands
        tft.drawLine (xc, yc, xc, yc-3*stopwatch_b.h/11, RA8875_WHITE);
        tft.drawLine (xc, yc, xc+3*stopwatch_b.h/14, yc, RA8875_WHITE);

        // LED off
        setLEDPurpose (LED_OFF);
    }
}


/* stopwatch_b has been touched from Main page:
 * if tapped while counting down just reset and continue main HamClock page, else start new SW page.
 */
void checkStopwatchTouch(TouchType tt)
{
    // if tapped the stop watch while counting down, just restart
    if (sw_state == SWS_COUNTDOWN && tt == TT_TAP) {
        setSWState (SWS_COUNTDOWN, countdown_period);
        return;
    }

    Serial.println(F("SW: main enter"));

    // close down other systems
    closeDXCluster();       // prevent inbound msgs from clogging network
    closeGimbal();          // avoid dangling connection
    hideClocks();

    // fresh start
    eraseScreen();
    initSWPage();
}


/* call to keep some other systems running while stopwatch page is up.
 */
static void runBackground()
{
    // update brightness control
    followBrightness();

    // keep sensor active
    readBME280();
}

/* called by main loop to run another iteration of the stop watch.
 * we are either not running at all, running but our page is not visible, or we are fully visible.
 * get out fast if not running.
 * we also manage a few other subsystems when transitioning visibility.
 * return whether we are visible now.
 */
bool runStopwatch()
{
    // always check switch
    if (isCountdownButtonTrue())
        setSWState (SWS_COUNTDOWN, countdown_period);

    if (sw_isup) {

        // stopwatch page is up

        // keep other systems up to date
        runBackground();

        // check for our button taps, updates state so might close
        checkSWPageTouch();
        if (!sw_isup) {
            Serial.println(F("SW: main exit"));
            initScreen();
            return (false);
        }

        // update display if in a state where it is changing

        if (sw_bcisup) {

            drawBigClock (false);

        } else if (sw_state == SWS_RUN) {

            drawSWTime(millis() - start_t);

        } else if (sw_state == SWS_COUNTDOWN) {

            drawCountdownTime();

        }

    } else if (sw_state == SWS_COUNTDOWN) {

        // main page is up and count down is running

        drawMainPageStopwatch (false);

    }

    return (sw_isup);
}

/* change stopwatch state, set countdown to ms if SWS_COUNTDOWN.
 * return whether requested state is valid.
 */
bool setSWState (SW_State new_sws, uint32_t ms)
{
    // be sure countdown light is off if not counting down
    if (new_sws != SWS_COUNTDOWN)
        setLEDPurpose(LED_OFF);

    switch (new_sws) {
    case SWS_RESET:
        if (sw_state == SWS_RESET)
            return (true);                      // ignore if no change
        sw_state = SWS_RESET;
        break;
    case SWS_RUN:
        if (sw_state == SWS_RUN)
            return (true);                      // ignore if no change
        if (sw_state == SWS_COUNTDOWN)
            break;                              // just continue running countdown
        if (sw_state == SWS_STOP)
            start_t = millis() - stop_dt;       // resume after stop: reinstate delta
        else if (sw_state != SWS_LAP)           // resume after lap: just keep going
            start_t = millis();                 // start fresh
        sw_state = SWS_RUN;
        break;
    case SWS_STOP:
        if (sw_state == SWS_STOP)
            return (true);                      // ignore if no change
        if (sw_state == SWS_COUNTDOWN)
            return (false);                     // stop not implemented for countdown
        stop_dt = millis() - start_t;           // capture delta
        sw_state = SWS_STOP;
        break;
    case SWS_LAP:
        if (sw_state == SWS_LAP)
            return (true);                      // ignore if no change
        if (sw_state == SWS_COUNTDOWN || sw_state == SWS_STOP)
            return (false);                     // lap not implemented for countdown or stop
        stop_dt = millis() - start_t;           // capture delta
        sw_state = SWS_LAP;
        break;
    case SWS_COUNTDOWN:
        countdown_period = ms;
        start_t = millis();
        sw_state = SWS_COUNTDOWN;
        break;
    default:
        return (false);
    }

    // draw new state appearance
    drawSWState();

    return (true);
}

/* retrieve current state and associated ms timer value
 */
SW_State getSWState (uint32_t &sw_timer)
{
    switch (sw_state) {
    case SWS_RESET:
        sw_timer = 0;
        break;
    case SWS_RUN:
        sw_timer = millis() - start_t;
        break;
    case SWS_STOP:
        sw_timer = stop_dt;
        break;
    case SWS_LAP:
        sw_timer = stop_dt;
        break;
    case SWS_COUNTDOWN:
        sw_timer = getCountdownLeft();
        break;
    }

    return (sw_state);
}
