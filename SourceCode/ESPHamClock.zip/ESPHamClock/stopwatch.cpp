/* implement a simple stopwatch with lap timer and countdown timer.
 */


#include "HamClock.h"



// LED purpose
typedef enum {
    LED_OFF,
    LED_OK,
    LED_SOON,
    LED_EXPIRED
} LEDPurpose;


/* only RPi can control LEDs and start switch for countdown control
 */
#if defined (_IS_RPI)

#include "RPiGPIO.h"

// GPIO (not header pins), low-active
#define RED_GPIO        13
#define GRN_GPIO        19
#define RUN_GPIO        26


static void setLEDPurpose (LEDPurpose c_code)
{
    // ignore if not supposed to use GPIO
    if (!GPIOOk())
        return;

    // one-time log of first GPIO usage
    static bool logged;
    if (!logged) {
        Serial.println (F("SW: Prep countdown GPIO"));
        logged = true;
    }

    RPiGPIO& gpio = RPiGPIO::getRPiGPIO();

    gpio.setAsOutput (RED_GPIO);
    gpio.setAsOutput (GRN_GPIO);

    switch (c_code) {
    case LED_OFF:
        gpio.setHi (RED_GPIO);
        gpio.setHi (GRN_GPIO);
        break;
    case LED_OK:
        gpio.setHi (RED_GPIO);
        gpio.setLo (GRN_GPIO);
        break;
    case LED_SOON:
        gpio.setHi (RED_GPIO);
        gpio.setLo (GRN_GPIO);
        break;
    case LED_EXPIRED:
        gpio.setLo (RED_GPIO);
        gpio.setHi (GRN_GPIO);
        break;
    }
}

static bool isCountdownButtonTrue()
{
    // ignore if not supposed to use GPIO
    if (!GPIOOk())
        return (false);

    RPiGPIO& gpio = RPiGPIO::getRPiGPIO();
    gpio.setAsInput (RUN_GPIO);
    return (gpio.isReady() && !gpio.readPin(RUN_GPIO));
}

#else // !_IS_RPI

// dummies
static void setLEDPurpose (LEDPurpose c_code) { (void)c_code; }
static bool isCountdownButtonTrue() { return (false); }

#endif // _IS_RPI



// set from setup or setSWState(), ms
uint32_t countdown_period;

// current state
bool sw_isup, sw_bigclock;
static SW_State sw_state;


// stopwatch params
#define SW_NDIG         9               	// number of display digits
#define SW_BG           RA8875_BLACK    	// bg color
#define SW_X0           105             	// x coord of left-most digit
#define SW_GAP          30              	// gap between digits
#define SW_Y0           150             	// upper left Y of all digits
#define SW_W            40              	// digit width
#define SW_H            100             	// digit heigth
#define SW_DOTR         3               	// dot radius
#define SW_SLANT        8               	// pixel slant, bottom to top
#define SW_BAX          240             	// control button A x
#define SW_BBX          440             	// control button B x
#define SW_EXITX        670             	// exit button x
#define SW_EXITY        420             	// exit button y
#define SW_BCX          10              	// big-clock button x
#define SW_BCY          SW_EXITY             	// big-clock button y
#define SW_BY           350             	// control button y
#define SW_BW           120             	// button width
#define SW_BH           40              	// button height
#define SW_CX           SW_BAX          	// color scale x
#define SW_CY           SW_EXITY        	// color scale y
#define SW_CW           (SW_BBX+SW_BW-SW_CX)    // color scale width
#define SW_CH           SW_BH              	// color scale height
#define SW_HSV_S        200                     // color scale HSV saturation, 0..255
#define SW_HSV_V        255                     // color scale HSV value, 0..255
#define SW_CD_X         300                     // countdown button x
#define SW_CD_Y         75                      // countdown button y
#define SW_CD_W         200                     // countdown button width
#define CD_WARNING      60000                   // icon warning color time, ms

// bigclock params
#define BC_X0           400                     // x center
#define BC_Y0           240                     // y center
#define BC_MNR          210                     // minute hand radius
#define BC_SCR          180                     // second hand radius
#define BC_HRR          130                     // hour hand radius
#define BC_FR           232                     // face radius
#define BC_BEZR         238                     // bezel radius
#define BC_HTR          12                      // hour tick radius
#define BC_MTR          5                       // minute tick radius
#define BC_HRTH         deg2rad(10.0F)          // hour hand thickness half-angle, rads
#define BC_MNTH         (BC_HRTH*BC_HRR/BC_MNR) // minute hand thickness half-angle, rads
#define BC_HTTH         deg2rad(0.6F)           // hour tick half-angle as seen from center, rads
#define BC_FCOL         sw_col                  // face color
#define BC_HRCOL        sw_col                  // hour hand color
#define BC_MNCOL        sw_col                  // minute hand color
#define BC_SCCOL        GRAY                    // second hand color
#define BC_BKCOL        RA8875_BLUE             // Back button color
#define BC_BEZCOL       GRAY                    // bezel color
#define BC_BADX         10                      // x coord of bad time message
#define BC_BADY         10                      // y coord of bad time message

// button labels
static char cd_lbl[] = "Count down";
static char lap_lbl[] = "Lap";
static char reset_lbl[] = "Reset";
static char resume_lbl[] = "Resume";
static char run_lbl[] = "Run";
static char stop_lbl[] = "Stop";
static char exit_lbl[] = "Exit";
static char bigclock_lbl[] = "Big Clock";

/* define which segments are used for each of the 10 digits as bit map
 *      0
 *    1   2
 *      3
 *    4   5
 *      6
 */
static const uint8_t defns[10] = {
    0x77, 0x24, 0x5D, 0x6D, 0x2E, 0x6B, 0x7B, 0x25, 0x7F, 0x2F
};

// which segments are already on in each digit position (same bit layout as above)
static uint8_t segson[SW_NDIG];

// millis() at start or since stop, when counting down start_t is when begun
static uint32_t start_t, stop_dt;

// controls
static SBox countdown_b = {SW_CD_X, SW_CD_Y, SW_CD_W, SW_BH};
static SBox A_b = {SW_BAX, SW_BY, SW_BW, SW_BH};
static SBox B_b = {SW_BBX, SW_BY, SW_BW, SW_BH};
static SBox exit_b = {SW_EXITX, SW_EXITY, SW_BW, SW_BH};
static SBox bigclock_b = {SW_BCX, SW_BCY, SW_BW, SW_BH};
static SBox color_b = {SW_CX, SW_CY, SW_CW, SW_CH};
static uint8_t sw_hue;                          // hue 0..255
static uint16_t sw_col;                         // color pixel



/* log our state to main server, if ok with user
 */
static void logSWState()
{
    if (logUsageOk()) {
        char ver[50];
        (void) newVersionIsAvailable (ver, sizeof(ver));
    }
}


/* return ms countdown time remaining, if any
 */
static uint32_t getCountdownLeft()
{
    if (sw_state == SWS_COUNTDOWN) {
        uint32_t since_start = millis() - start_t;
        if (since_start < countdown_period)
            return (countdown_period - since_start);
    }
    return (0);
}

/* decide visuals depending on current state:
 *   main_color is the count down text on the Main page (only used if showing Main page and counting down)
 *   led_purpose is the LED state to display
 *   button_state is the Stopwatch Count down button normal or reverse (only used if showing SW page)
 * return whether any changed from previous call.
 */
static bool getVisuals (uint16_t *main_color, LEDPurpose *led_purpose, bool *button_state)
{   
    static uint16_t prev_mc;
    static LEDPurpose prev_lp;
    static bool prev_bs;
    
    // decide current state
    uint16_t mc;
    LEDPurpose lp;
    bool bs;
    if (sw_state == SWS_COUNTDOWN) {
        uint32_t ms_left = getCountdownLeft();
        if (ms_left >= CD_WARNING) {
            // plenty of time
            mc = RA8875_GREEN;
            lp = LED_OK;
            bs = true;
        } else { 
            bool flash_state = (millis()%500) < 250;            // flip at 2 Hz
            if (ms_left > 0) {
                // timeout soon
                mc = RGB565(255,212,112);                       // real YELLOW looks too pale
                lp = flash_state ? LED_SOON : LED_OFF;
                bs = flash_state;
            } else {
                // timed out
                mc = flash_state ? RA8875_RED : RA8875_BLACK;
                lp = flash_state ? LED_EXPIRED : LED_OFF;
                bs = flash_state;
            }
        }
    } else {
        // count down not running
        mc = RA8875_GREEN;
        lp = LED_OFF;
        bs = false;
    }

    // pass back
    *main_color = mc;
    *led_purpose = lp;
    *button_state = bs;
    
    // check if any changed 
    bool new_vis = mc != prev_mc || lp != prev_lp || bs != prev_bs; 

    // persist
    prev_mc = mc; 
    prev_lp = lp; 
    prev_bs = bs; 
    
    // whether any changed
    return (new_vis);
}



/* set sw_col from sw_hue
 */
static void setSWColor()
{
    uint8_t r, g, b;
    hsvtorgb (&r, &g, &b, sw_hue, SW_HSV_S, SW_HSV_V);
    sw_col = RGB565 (r, g, b);
}

/* draw the color control box
 */
static void drawColorScale()
{
    // erase to remove tick marks
    tft.fillRect (color_b.x, color_b.y, color_b.w, color_b.h, RA8875_BLACK);

    // rainbow
    for (uint16_t dx = 0; dx < color_b.w; dx++) {
        uint8_t r, g, b;
        uint8_t h = 255*dx/color_b.w;
        hsvtorgb (&r, &g, &b, h, SW_HSV_S, SW_HSV_V);
        uint16_t c = RGB565 (r, g, b);
        // tft.drawLine (color_b.x + dx, color_b.y, color_b.x + dx, color_b.y + color_b.h, c);
        tft.drawPixel (color_b.x + dx, color_b.y + color_b.h/2, c);
    }

    // mark it
    uint16_t hue_x = color_b.x + sw_hue*color_b.w/255;
    tft.drawLine (hue_x, color_b.y+3*color_b.h/8, hue_x, color_b.y+5*color_b.h/8, RA8875_WHITE);
}

/* draw changed segments of given digit 0-9 in the given position 0..SW_NDIG-1
 */
static void drawDigit (uint8_t position, uint8_t digit)
{
    // coord of upper left corner
    uint16_t x0 = SW_X0 + (SW_W+SW_GAP)*position;

    // get current and desired segment mask in this position then replace now
    uint8_t mask_now = segson[position];
    uint8_t mask_new = defns[digit];
    segson[position] = mask_new;

    // update each changed segment
    uint8_t mask_chg = mask_now ^ mask_new;

    // segment 0
    if (mask_chg & 0x01) {
        uint16_t c = (mask_new & 0x01) ? sw_col : SW_BG;
        tft.drawRect (x0, SW_Y0, SW_W, 2, c);
        // tft.drawLine (x0, SW_Y0, x0+SW_W, SW_Y0, c);
        // tft.drawLine (x0, SW_Y0+1, x0+SW_W, SW_Y0+1, c);
    }

    // segment 1
    if (mask_chg & 0x02) {
        uint16_t c = (mask_new & 0x02) ? sw_col : SW_BG;
        tft.drawLine (x0, SW_Y0, x0-SW_SLANT/2, SW_Y0+SW_H/2, c);
        tft.drawLine (x0+1, SW_Y0, x0-SW_SLANT/2+1, SW_Y0+SW_H/2, c);
    }

    // segment 2
    if (mask_chg & 0x04) {
        uint16_t c = (mask_new & 0x04) ? sw_col : SW_BG;
        tft.drawLine (x0+SW_W, SW_Y0, x0+SW_W-SW_SLANT/2, SW_Y0+SW_H/2, c);
        tft.drawLine (x0+SW_W+1, SW_Y0, x0+SW_W-SW_SLANT/2+1, SW_Y0+SW_H/2, c);
    }

    // segment 3
    if (mask_chg & 0x08) {
        uint16_t c = (mask_new & 0x08) ? sw_col : SW_BG;
        tft.drawRect (x0-SW_SLANT/2, SW_Y0+SW_H/2, SW_W, 2, c);
        // tft.drawLine (x0-SW_SLANT/2, SW_Y0+SW_H/2, x0+SW_W-SW_SLANT/2, SW_Y0+SW_H/2, c);
        // tft.drawLine (x0-SW_SLANT/2, SW_Y0+SW_H/2+1, x0+SW_W-SW_SLANT/2, SW_Y0+SW_H/2+1, c);
    }

    // segment 4
    if (mask_chg & 0x10) {
        uint16_t c = (mask_new & 0x10) ? sw_col : SW_BG;
        tft.drawLine (x0-SW_SLANT/2, SW_Y0+SW_H/2, x0-SW_SLANT, SW_Y0+SW_H, c);
        tft.drawLine (x0-SW_SLANT/2+1, SW_Y0+SW_H/2, x0-SW_SLANT+1, SW_Y0+SW_H, c);
    }

    // segment 5
    if (mask_chg & 0x20) {
        uint16_t c = (mask_new & 0x20) ? sw_col : SW_BG;
        tft.drawLine (x0+SW_W-SW_SLANT/2, SW_Y0+SW_H/2, x0+SW_W-SW_SLANT, SW_Y0+SW_H, c);
        tft.drawLine (x0+SW_W-SW_SLANT/2+1, SW_Y0+SW_H/2, x0+SW_W-SW_SLANT+1, SW_Y0+SW_H, c);
    }

    // segment 6
    if (mask_chg & 0x40) {
        uint16_t c = (mask_new & 0x40) ? sw_col : SW_BG;
        tft.drawRect (x0-SW_SLANT, SW_Y0+SW_H, SW_W, 2, c);
        // tft.drawLine (x0-SW_SLANT, SW_Y0+SW_H, x0+SW_W-SW_SLANT, SW_Y0+SW_H, c);
        // tft.drawLine (x0-SW_SLANT, SW_Y0+SW_H+1, x0+SW_W-SW_SLANT, SW_Y0+SW_H+1, c);
    }

}

/* display the given time value in millis()
 */
static void drawTime(uint32_t t)
{
    t %= (100UL*60UL*60UL*1000UL);                        // SW_NDIG digits

    uint8_t tenhr = t / (10UL*3600UL*1000UL);
    drawDigit (0, tenhr);
    t -= tenhr * (10UL*3600UL*1000UL);

    uint8_t onehr = t / (3600UL*1000UL);
    drawDigit (1, onehr);
    t -= onehr * (3600UL*1000UL);

    uint8_t tenmn = t / (600UL*1000UL);
    drawDigit (2, tenmn);
    t -= tenmn * (600UL*1000UL);

    uint8_t onemn = t / (60UL*1000UL);
    drawDigit (3, onemn);
    t -= onemn * (60UL*1000UL);

    uint8_t tensec = t / (10UL*1000UL);
    drawDigit (4, tensec);
    t -= tensec * (10UL*1000UL);

    uint8_t onesec = t / (1UL*1000UL);
    drawDigit (5, onesec);
    t -= onesec * (1UL*1000UL);

    uint8_t tenthsec = t / (100UL);
    drawDigit (6, tenthsec);
    t -= tenthsec * (100UL);

    uint8_t hundsec = t / (10UL);
    drawDigit (7, hundsec);
    t -= hundsec * (10UL);

    uint8_t thousec = t / (1UL);
    drawDigit (8, thousec);

    // immediate
    tft.drawPR();

}


/* draw remaining count down time and manage the state of the count down button and LED.
 * N.B. we assume sw_state == SWS_COUNTDOWN
 */
static void drawSWCountdownTime()
{
    // always draw remaining time left
    uint32_t ms_left = getCountdownLeft();
    drawTime(ms_left);

    // update state if any change
    uint16_t main_color;
    LEDPurpose led_purpose;
    bool button_state;
    if (getVisuals (&main_color, &led_purpose, &button_state)) {
        drawStringInBox (cd_lbl, countdown_b, button_state, sw_col);
        setLEDPurpose (led_purpose);
    }
}


/* draw time and buttons given current state, or main page icon if not showing sw page.
 */
static void drawSWState()
{
    if (sw_isup) {

        switch (sw_state) {
        case SWS_RESET:
            drawTime(0);
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (run_lbl, A_b, false, sw_col);
            drawStringInBox (reset_lbl, B_b, false, sw_col);
            break;
        case SWS_RUN:
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (stop_lbl, A_b, false, sw_col);
            drawStringInBox (lap_lbl, B_b, false, sw_col);
            break;
        case SWS_STOP:
            drawTime(stop_dt);        // show stopped time
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (run_lbl, A_b, false, sw_col);
            drawStringInBox (reset_lbl, B_b, false, sw_col);
            break;
        case SWS_LAP:
            drawTime(stop_dt);        // show lap hold time
            drawStringInBox (cd_lbl, countdown_b, false, sw_col);
            drawStringInBox (reset_lbl, A_b, false, sw_col);
            drawStringInBox (resume_lbl, B_b, false, sw_col);
            break;
        case SWS_COUNTDOWN:
            drawSWCountdownTime();
            drawStringInBox (cd_lbl, countdown_b, true, sw_col);
            drawStringInBox (reset_lbl, A_b, false, sw_col);
            drawStringInBox (reset_lbl, B_b, false, sw_col);
            break;
        }

    } else {

        drawMainPageStopwatch(true);
    }
}

static void drawBigClock(bool all)
{
    // points 1 and 2 are the fat positions part way out, point 3 is the far tip, "point" 0 is the center

    // persistent time measures
    static uint32_t prev_t;                             // set updates
    static time_t prev_t0;                              // detect change of secs
    static uint32_t millis_t0;                          // create fractional secs
    static bool time_was_ok;                            // whether time was ok last iteration

    // previous hand positions for motion detection and exact erasing
    static int16_t prev_hrdx1, prev_hrdx2, prev_hrdx3, prev_hrdy1, prev_hrdy2, prev_hrdy3;
    static int16_t prev_mndx1, prev_mndx2, prev_mndx3, prev_mndy1, prev_mndy2, prev_mndy3;
    static int16_t prev_scdx3, prev_scdy3;

    if (all) {

        // fresh face
        eraseScreen();

        // face perimeter
      #if defined (_IS_ESP8266)
        // avoids bright flash of circle filling but doesn't fill at higher display sizes
        for (uint16_t r = BC_FR+1; r <= BC_BEZR; r++)
            tft.drawCircle (BC_X0, BC_Y0, r, BC_BEZCOL);
      #else
        tft.fillCircle (BC_X0, BC_Y0, BC_BEZR, BC_BEZCOL);
        tft.fillCircle (BC_X0, BC_Y0, BC_FR, RA8875_BLACK);
      #endif
        tft.drawCircle (BC_X0, BC_Y0, BC_FR, BC_FCOL);

        // hour points
        for (int i = 0; i < 12; i++) {
            float a = deg2rad(360.0F*i/12);
            float x0 = BC_X0 + (BC_FR-BC_HTR) * cosf(a);
            float y0 = BC_Y0 + (BC_FR-BC_HTR) * sinf(a);
            float x1 = BC_X0 + BC_FR * cosf(a-BC_HTTH);
            float y1 = BC_Y0 + BC_FR * sinf(a-BC_HTTH);
            float x2 = BC_X0 + BC_FR * cosf(a+BC_HTTH);
            float y2 = BC_Y0 + BC_FR * sinf(a+BC_HTTH);
            tft.drawLine (x0, y0, x1, y1, 1, BC_FCOL);
            tft.drawLine (x0, y0, x2, y2, 1, BC_FCOL);
        }

        // minute ticks
        for (int i = 0; i < 60; i++) {
            if ((i % 5) == 0)
                continue;                               // don't overdraw hour marks
            float a = deg2rad(360.0F*i/60);
            float x0 = BC_X0 + BC_FR * cosf(a);
            float y0 = BC_Y0 + BC_FR * sinf(a);
            float x1 = BC_X0 + (BC_FR-BC_MTR) * cosf(a);
            float y1 = BC_Y0 + (BC_FR-BC_MTR) * sinf(a);
            tft.drawLine (x0, y0, x1, y1, 1, BC_FCOL);
        }

        // init time deltas, but won't know accurate millis_t0 until first real second change
        prev_t0 = nowWO() + de_tz.tz_secs;
        millis_t0 = millis();
        prev_t = 0;

        // init all locations bogus but inside face and not 0
        prev_hrdx1 = prev_hrdy1 = 10;
        prev_mndx1 = prev_mndy1 = 10;
        prev_hrdx2 = prev_hrdy2 = 20;
        prev_mndx2 = prev_mndy2 = 20;
        prev_hrdx3 = prev_hrdy3 = 30;
        prev_mndx3 = prev_mndy3 = 30;
        prev_scdx3 = prev_scdy3 = 30;

    }

    // just update often enough to avoid noticible jitter
    if (!timesUp (&prev_t, 50))         // time for sec tip to move 1 pixel ~ 60*atand(1/200)/360
        return;

    // get local time now, including any user offset
    time_t t0 = nowWO() + de_tz.tz_secs;

    // use elapsed millis() since last whole sec change to derive fractional seconds
    if (t0 > prev_t0) {
        millis_t0 = millis();
        prev_t0 = t0;
    }
    float sc_frac = (millis() - millis_t0) * 1e-3F;

    // crack 
    int hr = hour(t0);
    int mn = minute(t0);
    int sc = second(t0);

    // find central angle and far tip location of each hand
    float hr_angle = deg2rad(30*(3-(((hr+24)%12) + mn/60.0F)));
    float mn_angle = deg2rad(6*(15-(mn+sc/60.0F)));
    float sc_angle = deg2rad(6*(15-(sc+sc_frac)));
    int16_t hrdx3 = BC_HRR * cosf(hr_angle);
    int16_t hrdy3 = BC_HRR * sinf(hr_angle);
    int16_t mndx3 = BC_MNR * cosf(mn_angle);
    int16_t mndy3 = BC_MNR * sinf(mn_angle);
    int16_t scdx3 = BC_SCR * cosf(sc_angle);
    int16_t scdy3 = BC_SCR * sinf(sc_angle);

    // erase and update hand position if far tip moved
    bool hr_moved = hrdx3 != prev_hrdx3 || hrdy3 != prev_hrdy3;
    bool mn_moved = mndx3 != prev_mndx3 || mndy3 != prev_mndy3;
    bool sc_moved = scdx3 != prev_scdx3 || scdy3 != prev_scdy3;
    if (hr_moved) {
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_hrdx1, BC_Y0-prev_hrdy1, 1, RA8875_BLACK);
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_hrdx2, BC_Y0-prev_hrdy2, 1, RA8875_BLACK);
        tft.drawLine (BC_X0+prev_hrdx1, BC_Y0-prev_hrdy1, BC_X0+prev_hrdx3, BC_Y0-prev_hrdy3, 1,RA8875_BLACK);
        tft.drawLine (BC_X0+prev_hrdx2, BC_Y0-prev_hrdy2, BC_X0+prev_hrdx3, BC_Y0-prev_hrdy3, 1,RA8875_BLACK);
        prev_hrdx1 = BC_HRR/3 * cosf(hr_angle-BC_HRTH);
        prev_hrdy1 = BC_HRR/3 * sinf(hr_angle-BC_HRTH);
        prev_hrdx2 = BC_HRR/3 * cosf(hr_angle+BC_HRTH);
        prev_hrdy2 = BC_HRR/3 * sinf(hr_angle+BC_HRTH);
        prev_hrdx3 = hrdx3;
        prev_hrdy3 = hrdy3;
    }
    if (mn_moved) {
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_mndx1, BC_Y0-prev_mndy1, 1, RA8875_BLACK);
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_mndx2, BC_Y0-prev_mndy2, 1, RA8875_BLACK);
        tft.drawLine (BC_X0+prev_mndx1, BC_Y0-prev_mndy1, BC_X0+prev_mndx3, BC_Y0-prev_mndy3, 1,RA8875_BLACK);
        tft.drawLine (BC_X0+prev_mndx2, BC_Y0-prev_mndy2, BC_X0+prev_mndx3, BC_Y0-prev_mndy3, 1,RA8875_BLACK);
        prev_mndx1 = BC_MNR/3 * cosf(mn_angle-BC_MNTH);
        prev_mndy1 = BC_MNR/3 * sinf(mn_angle-BC_MNTH);
        prev_mndx2 = BC_MNR/3 * cosf(mn_angle+BC_MNTH);
        prev_mndy2 = BC_MNR/3 * sinf(mn_angle+BC_MNTH);
        prev_mndx3 = mndx3;
        prev_mndy3 = mndy3;
    }
    if (sc_moved) {
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_scdx3, BC_Y0-prev_scdy3, 1, RA8875_BLACK);
        prev_scdx3 = scdx3;
        prev_scdy3 = scdy3;
    }

    // draw hand if moved or likely clobbered by another hand erasure
    float hr_sc_angle = fabs(hr_angle - sc_angle);
    float hr_mn_angle = fabs(hr_angle - mn_angle);
    float mn_sc_angle = fabs(mn_angle - sc_angle);
    bool hrsc_hit = hr_sc_angle < 2*BC_HRTH || hr_sc_angle > 2*M_PIF - 2*BC_HRTH;         // fudge fat bottom
    bool hrmn_hit = hr_mn_angle < 2*BC_HRTH || hr_mn_angle > 2*M_PIF - 2*BC_HRTH;
    bool mnsc_hit = mn_sc_angle < 2*BC_MNTH || mn_sc_angle > 2*M_PIF - 2*BC_MNTH;
    if (hr_moved || hrsc_hit || hrmn_hit) {
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_hrdx1, BC_Y0-prev_hrdy1, 1, BC_HRCOL);
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_hrdx2, BC_Y0-prev_hrdy2, 1, BC_HRCOL);
        tft.drawLine (BC_X0+prev_hrdx1, BC_Y0-prev_hrdy1, BC_X0+prev_hrdx3, BC_Y0-prev_hrdy3, 1,BC_HRCOL);
        tft.drawLine (BC_X0+prev_hrdx2, BC_Y0-prev_hrdy2, BC_X0+prev_hrdx3, BC_Y0-prev_hrdy3, 1,BC_HRCOL);
    }
    if (mn_moved || hrmn_hit || mnsc_hit) {
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_mndx1, BC_Y0-prev_mndy1, 1, BC_MNCOL);
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_mndx2, BC_Y0-prev_mndy2, 1, BC_MNCOL);
        tft.drawLine (BC_X0+prev_mndx1, BC_Y0-prev_mndy1, BC_X0+prev_mndx3, BC_Y0-prev_mndy3, 1,BC_MNCOL);
        tft.drawLine (BC_X0+prev_mndx2, BC_Y0-prev_mndy2, BC_X0+prev_mndx3, BC_Y0-prev_mndy3, 1,BC_MNCOL);
    }
    if (sc_moved || hrsc_hit || mnsc_hit)
        tft.drawLine (BC_X0, BC_Y0, BC_X0+prev_scdx3, BC_Y0-prev_scdy3, 1, BC_SCCOL);

    // update awareness messages if changed
    bool clock_ok = clockTimeOk();
    bool ut_zero = utcOffset() == 0;
    bool time_ok_now = clock_ok && ut_zero;
    if (!time_ok_now || time_ok_now != time_was_ok) {
        if (time_ok_now) {
            // erase
            tft.fillRect (BC_BADX, BC_BADY, 240, 40, RA8875_BLACK);
        } else {
            // tft.drawRect (BC_BADX, BC_BADY, 240, 40, RA8875_WHITE);
            selectFontStyle (BOLD_FONT, SMALL_FONT);
            tft.setCursor (BC_BADX, BC_BADY+27);
            if (!clock_ok) {
                tft.setTextColor (RA8875_RED);
                tft.print ("Unknown accuracy");
            } else {
                tft.setTextColor (RA8875_YELLOW);
                tft.print ("Time is offset");
            }
        }

        // persist
        time_was_ok = time_ok_now;
    }

    // immediate
    tft.drawPR();

}

/* init the stopwatch page.
 * N.B. do not erase screen, leave that to caller
 */
static void initSWPage()
{
    // get last color, else set default
    if (!NVReadUInt8 (NV_SWHUE, &sw_hue)) {
        sw_hue = 85;    // green
        NVWriteUInt8 (NV_SWHUE, sw_hue);
    }
    setSWColor();

    // buttons
    selectFontStyle (BOLD_FONT, SMALL_FONT);
    drawStringInBox (exit_lbl, exit_b, false, sw_col);
    drawStringInBox (bigclock_lbl, bigclock_b, false, sw_col);

    // state
    sw_isup = true;
    sw_bigclock = false;

    // log with server
    logSWState();

    // init segments all off
    memset (segson, 0, sizeof(segson));

    // draw punctuation
    tft.fillCircle (SW_X0 + 2*SW_W + SW_GAP + SW_GAP/2 - SW_SLANT/3, SW_Y0 + SW_H/3, SW_DOTR, sw_col);
    tft.fillCircle (SW_X0 + 2*SW_W + SW_GAP + SW_GAP/2 - 2*SW_SLANT/3, SW_Y0 + 2*SW_H/3, SW_DOTR, sw_col);
    tft.fillCircle (SW_X0 + 4*SW_W + 3*SW_GAP + SW_GAP/2 - SW_SLANT/3, SW_Y0 + SW_H/3, SW_DOTR, sw_col);
    tft.fillCircle (SW_X0 + 4*SW_W + 3*SW_GAP + SW_GAP/2 - 2*SW_SLANT/3, SW_Y0 + 2*SW_H/3, SW_DOTR, sw_col);
    tft.fillCircle (SW_X0 + 6*SW_W + 5*SW_GAP + SW_GAP/2 - SW_SLANT, SW_Y0 + SW_H, SW_DOTR, sw_col);

    // draw buttons from state and color scale
    drawSWState();
    drawColorScale();
}

/* check our touch controls, update state
 */
static void checkSWPageTouch()
{
    // check for touch
    SCoord s;
    if (readCalTouchWS(s) == TT_NONE)
        return;

    // update idle timer, ignore if this tap is restoring full brightness
    if (brightnessOn())
        return;

    // any tap retreats from big clock
    if (sw_bigclock) {
        Serial.println(F("SW: BigClock exit"));
        sw_bigclock = false;
        eraseScreen();
        initSWPage();
        return;
    }

    // check each box
    if (inBox (s, countdown_b)) {
        // start countdown timer regardless of current state
        setSWState (SWS_COUNTDOWN, countdown_period);
    
    } else if (inBox (s, A_b)) {
        // box action depends on current state
        SW_State new_sws;
        switch (sw_state) {
        case SWS_RESET:
            // clicked Run
            new_sws = SWS_RUN;
            break;
        case SWS_RUN:
            // clicked Stop
            new_sws = SWS_STOP;
            break;
        case SWS_STOP:
            // clicked Run
            new_sws = SWS_RUN;
            break;
        case SWS_LAP:
            // clicked Reset
            new_sws = SWS_RESET;
            break;
        case SWS_COUNTDOWN:
            // clicked Reset
            new_sws = SWS_RESET;
            break;
        default:
            new_sws = SWS_RESET;
            break;
        }

        // update state and GUI
        setSWState (new_sws, countdown_period);

    } else if (inBox (s, B_b)) {
        // box action depends on current state
        SW_State new_sws;
        switch (sw_state) {
        case SWS_RESET:
            // clicked Reset
            new_sws = SWS_RESET;
            break;
        case SWS_RUN:
            // clicked Lap
            new_sws = SWS_LAP;
            break;
        case SWS_STOP:
            // clicked Reset
            new_sws = SWS_RESET;
            break;
        case SWS_LAP:
            // clicked Resume
            new_sws = SWS_RUN;
            break;
        case SWS_COUNTDOWN:
            // clicked Reset
            new_sws = SWS_RESET;
            break;
        default:
            new_sws = SWS_RESET;
            break;
        }

        // update state and GUI
        setSWState (new_sws, countdown_period);

    } else if (inBox (s, exit_b)) {
        sw_isup = false;

    } else if (inBox (s, color_b)) {
        sw_hue = 255*(s.x - color_b.x)/color_b.w;
        NVWriteUInt8 (NV_SWHUE, sw_hue);
        initSWPage();

    } else if (inBox (s, bigclock_b)) {
        Serial.println(F("SW: BigClock enter"));
        sw_bigclock = true;
        logSWState();
        drawBigClock(true);

    }
}

/* draw the main page stopwatch icon or count down time remaining in stopwatch_b depending on sw_state.
 */
void drawMainPageStopwatch (bool force)
{
    if (sw_state == SWS_COUNTDOWN) {

        // get time remaining
        uint32_t ms_left = getCountdownLeft();

        // check if same second
        static uint32_t prev_sec;
        uint32_t sec = ms_left/1000;
        bool same_sec = sec == prev_sec;
        prev_sec = sec;

        // skip if no change in colors and same second remaining
        uint16_t main_color;
        LEDPurpose led_purpose;
        bool button_state;
        if (!getVisuals (&main_color, &led_purpose, &button_state) && same_sec && !force)
            return;

        // update LED
        setLEDPurpose (led_purpose);

        // break into H:M:S
        ms_left += 500;         // round
        uint8_t hr = ms_left / 3600000;
        ms_left -= hr * 3600000;
        uint8_t mn = ms_left / 60000;
        ms_left -= mn * 60000;
        uint8_t sc = ms_left/1000;

        // format
        selectFontStyle (LIGHT_FONT, FAST_FONT);
        char buf[32];
        if (hr == 0)
            sprintf (buf, "%d:%02d", mn, sc);
        else
            sprintf (buf, "%dh%02d", hr, mn);
        uint16_t cdw = getTextWidth(buf);

        // erase and draw
        tft.fillRect (stopwatch_b.x, stopwatch_b.y, stopwatch_b.w, stopwatch_b.h, RA8875_BLACK);
        tft.setTextColor (main_color);
        tft.setCursor (stopwatch_b.x + (stopwatch_b.w-cdw)/2, stopwatch_b.y+stopwatch_b.h/4);
        tft.print (buf);

    } else if (force) {

        // draw icon

        // erase
        tft.fillRect (stopwatch_b.x, stopwatch_b.y, stopwatch_b.w, stopwatch_b.h, RA8875_BLACK);

        // radius and step
        uint16_t r = 3*stopwatch_b.h/8;
        uint16_t xc = stopwatch_b.x + stopwatch_b.w/2;
        uint16_t yc = stopwatch_b.y + stopwatch_b.h/2;
        uint16_t dx = r*cosf(deg2rad(45)) + 0.5F;

        // watch
        tft.fillCircle (xc, yc, r, GRAY);

        // top stem
        tft.fillRect (xc-1, yc-r-3, 3, 4, GRAY);

        // 2 side stems
        tft.fillCircle (xc-dx, yc-dx-1, 1, GRAY);
        tft.fillCircle (xc+dx, yc-dx-1, 1, GRAY);

        // face
        tft.drawCircle (xc, yc, 3*stopwatch_b.h/10, RA8875_BLACK);

        // hands
        tft.drawLine (xc, yc, xc, yc-3*stopwatch_b.h/11, RA8875_WHITE);
        tft.drawLine (xc, yc, xc+3*stopwatch_b.h/14, yc, RA8875_WHITE);

        // LED off
        setLEDPurpose (LED_OFF);
    }
}


/* stopwatch_b has been touched from Main page:
 * if tapped while counting down just reset and continue main HamClock page, else start new SW page.
 */
void checkStopwatchTouch(TouchType tt)
{
    // if tapped the stop watch while counting down, just restart
    if (sw_state == SWS_COUNTDOWN && tt == TT_TAP) {
        setSWState (SWS_COUNTDOWN, countdown_period);
        return;
    }

    Serial.println(F("SW: main enter"));

    // close down other systems
    closeDXCluster();       // prevent inbound msgs from clogging network
    closeGimbal();          // avoid dangling connection
    hideClocks();

    // fresh start
    eraseScreen();
    initSWPage();
}


/* call to keep some other systems running while stopwatch page is up.
 */
static void runBackground()
{
    // set brightness unless showing bigclock -- seems reasonable plus avoids showing NCDXF box when
    // idle or on/off timers fire
    if (!sw_bigclock)
        followBrightness();

    // keep sensor active
    readBME280();
}

/* run another iteration of the stop watch.
 * we are either not running at all, running but our page is not visible, or we are fully visible.
 * get out fast if not running.
 * we also manage a few other subsystems when transitioning visibility.
 * return whether we are visible now.
 */
bool runStopwatch()
{
    // always check switch
    if (isCountdownButtonTrue())
        setSWState (SWS_COUNTDOWN, countdown_period);

    if (sw_isup) {

        // stopwatch page is up

        // keep other systems up to date
        runBackground();

        // check for our button taps, updates state so might close
        checkSWPageTouch();
        if (!sw_isup) {
            Serial.println(F("SW: main exit"));
            initScreen();
            return (false);
        }

        // update display if in a state where it is changing

        if (sw_bigclock) {

            drawBigClock (false);

        } else if (sw_state == SWS_RUN) {

            drawTime(millis() - start_t);

        } else if (sw_state == SWS_COUNTDOWN) {

            drawSWCountdownTime();

        }

    } else if (sw_state == SWS_COUNTDOWN) {

        // main page is up and count down is running

        drawMainPageStopwatch (false);

    }

    return (sw_isup);
}

/* change stopwatch state, set countdown to ms if SWS_COUNTDOWN.
 * return whether requested state is valid.
 */
bool setSWState (SW_State new_sws, uint32_t ms)
{
    // be sure countdown light is off if not counting down
    if (new_sws != SWS_COUNTDOWN)
        setLEDPurpose(LED_OFF);

    switch (new_sws) {
    case SWS_RESET:
        if (sw_state == SWS_RESET)
            return (true);                      // ignore if no change
        sw_state = SWS_RESET;
        break;
    case SWS_RUN:
        if (sw_state == SWS_RUN)
            return (true);                      // ignore if no change
        if (sw_state == SWS_COUNTDOWN)
            break;                              // just continue running countdown
        if (sw_state == SWS_STOP)
            start_t = millis() - stop_dt;       // resume after stop: reinstate delta
        else if (sw_state != SWS_LAP)           // resume after lap: just keep going
            start_t = millis();                 // start fresh
        sw_state = SWS_RUN;
        break;
    case SWS_STOP:
        if (sw_state == SWS_STOP)
            return (true);                      // ignore if no change
        if (sw_state == SWS_COUNTDOWN)
            return (false);                     // stop not implemented for countdown
        stop_dt = millis() - start_t;           // capture delta
        sw_state = SWS_STOP;
        break;
    case SWS_LAP:
        if (sw_state == SWS_LAP)
            return (true);                      // ignore if no change
        if (sw_state == SWS_COUNTDOWN || sw_state == SWS_STOP)
            return (false);                     // lap not implemented for countdown or stop
        stop_dt = millis() - start_t;           // capture delta
        sw_state = SWS_LAP;
        break;
    case SWS_COUNTDOWN:
        countdown_period = ms;
        start_t = millis();
        sw_state = SWS_COUNTDOWN;
        break;
    default:
        return (false);
    }

    // draw new state appearance
    drawSWState();

    return (true);
}

/* retrieve current state and associated ms timer value
 */
SW_State getSWState (uint32_t &sw_timer)
{
    switch (sw_state) {
    case SWS_RESET:
        sw_timer = 0;
        break;
    case SWS_RUN:
        sw_timer = millis() - start_t;
        break;
    case SWS_STOP:
        sw_timer = stop_dt;
        break;
    case SWS_LAP:
        sw_timer = stop_dt;
        break;
    case SWS_COUNTDOWN:
        sw_timer = getCountdownLeft();
        break;
    }

    return (sw_state);
}
