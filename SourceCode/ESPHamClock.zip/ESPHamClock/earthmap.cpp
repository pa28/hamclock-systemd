/* code to manage the earth map
 */

/* main map drawing routines.
 */


#include "HamClock.h"


// DX location and path to DE
SCircle dx_c = {{0,0},DX_R};                    // screen coords of DX symbol
LatLong dx_ll;                                  // geo coords of dx spot

// DE and AntiPodal location
SCircle de_c = {{0,0},DE_R};                    // screen coords of DE symbol
LatLong de_ll;                                  // geo coords of DE
float sdelat, cdelat;                           // handy tri
SCircle deap_c = {{0,0},DEAP_R};                // screen coords of DE antipode symbol
LatLong deap_ll;                                // geo coords of DE antipode

// sun
AstroCir solar_cir;
SCircle sun_c = {{0,0},SUN_R};                  // screen coords of sun symbol
LatLong sun_ss_ll;                              // subsolar location
float csslat, ssslat;                           // handy trig

// moon
AstroCir lunar_cir;
SCircle moon_c = {{0,0},MOON_R};                // screen coords of moon symbol
LatLong moon_ss_ll;                             // sublunar location

// dx options
uint8_t show_km;                                // show great circle dist in km, else miles
uint8_t show_lp;                                // display long path, else short part heading

#define GRAYLINE_COS    (-0.208F)               // cos(90 + grayline angle), we use 12 degs
#define GRAYLINE_POW    (0.75F)                 // cos power exponent, sqrt is too severe, 1 is too gradual
static SCoord moremap_s;                        // drawMoreEarth() scanning location 

// grid colors
#define GRIDC   RGB565(60,60,60)                // main grid
#define GRIDC00 RGB565(120,120,120)             // highlights


/* erase the DE symbol by restoring map contents.
 * N.B. we assume coords insure marker will be wholy within map boundaries.
 */
void eraseDEMarker()
{
    eraseSCircle (de_c);
}

/* draw DE marker.
 * N.B. we assume coords insure marker will be wholy within map boundaries.
 */
void drawDEMarker(bool force)
{
    // test for over visible map unless force, eg might be under RSS now
    if (!force && !overMap(de_c.s))
        return;

    tft.fillCircle (de_c.s.x, de_c.s.y, DE_R, RA8875_BLACK);
    tft.drawCircle (de_c.s.x, de_c.s.y, DE_R, DE_COLOR);
    tft.fillCircle (de_c.s.x, de_c.s.y, DE_R/2, DE_COLOR);
}

/* erase the antipode symbol by restoring map contents.
 * N.B. we assume coords insure marker will be wholy within map boundaries.
 */
void eraseDEAPMarker()
{
    eraseSCircle (deap_c);
}

/* draw antipodal marker.
 * N.B. we assume coords insure marker will be wholy within map boundaries.
 */
void drawDEAPMarker()
{
    tft.fillCircle (deap_c.s.x, deap_c.s.y, DEAP_R, DE_COLOR);
    tft.drawCircle (deap_c.s.x, deap_c.s.y, DEAP_R, RA8875_BLACK);
    tft.fillCircle (deap_c.s.x, deap_c.s.y, DEAP_R/2, RA8875_BLACK);
}

/* draw de_info_b according to de_time_fmt
 */
void drawDEInfo()
{
    // init info block
    tft.fillRect (de_info_b.x, de_info_b.y, de_info_b.w, de_info_b.h, RA8875_BLACK);

    // draw desired contents
    if (de_time_fmt == DETIME_INFO) {

        uint16_t vspace = de_info_b.h/DE_INFO_ROWS;
        selectFontStyle (LIGHT_FONT, SMALL_FONT);
        tft.setTextColor (DE_COLOR);

        // time
        drawDETime(false);

        // lat and lon
        char buf[30];
        sprintf (buf, "%.0f%c  %.0f%c",
                    roundf(fabsf(de_ll.lat_d)), de_ll.lat_d < 0 ? 'S' : 'N',
                    roundf(fabsf(de_ll.lng_d)), de_ll.lng_d < 0 ? 'W' : 'E');
        tft.setCursor (de_info_b.x, de_info_b.y+2*vspace-6);
        tft.print(buf);

        // maidenhead
        drawMaidenhead(NV_DE_GRID, de_maid_b, DE_COLOR);

        // sun rise/set info
        drawDESunRiseSetInfo();

    } else if (de_time_fmt == DETIME_ANALOG || de_time_fmt == DETIME_ANALOG_DTTM) {

        drawTZ (de_tz);
        updateClocks(true);

    } else if (de_time_fmt == DETIME_CAL) {

        drawDETime(true);
        drawCalendar(true);

    }
}

void drawDETime(bool center)
{
    drawTZ (de_tz);

    // get time
    time_t utc = nowWO();
    time_t local = utc + de_tz.tz_secs;
    int hr = hour (local);
    int mn = minute (local);
    int dy = day(local);
    int mo = month(local);

    // generate text
    char buf[32];
    sprintf (buf, "%02d:%02d %s %d", hr, mn, monthShortStr(mo), dy);

    // set position
    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    uint16_t vspace = de_info_b.h/DE_INFO_ROWS;
    uint16_t x0 = de_info_b.x;
    if (center) {
        uint16_t bw = getTextWidth (buf);
        x0 += (de_info_b.w - bw)/2;
    }

    // draw
    tft.fillRect (de_info_b.x, de_info_b.y, de_info_b.w, vspace, RA8875_BLACK);
    tft.setTextColor (DE_COLOR);
    tft.setCursor (x0, de_info_b.y+vspace-6);
    tft.print(buf);
}

/* draw some fake stars for the azimuthal projection
 */
void drawAzmStars()
{
    #define N_AZMSTARS 200
    uint8_t n_stars = 0;
    while (n_stars < N_AZMSTARS) {
        int32_t x = random (map_b.w);
        int32_t y = random (map_b.h);
        int32_t dx = (x > map_b.w/2) ? (x - 3*map_b.w/4) : (x - map_b.w/4);
        int32_t dy = y - map_b.h/2;
        if (dx*dx + dy*dy > map_b.w*map_b.w/16) {
            uint16_t c = random(256);
            c = RGB565(c,c,c);
            tft.drawPixel (map_b.x+x, map_b.y+y, c);
            n_stars++;
        }
    }
}

/* draw the Maidenhead grid key round the map.
 */
static void drawMaidGridKey()
{
    resetWatchdog();

    // keep right stripe above RSS if on
    uint16_t right_h = rss_on ? rss_bnr_b.y - map_b.y : map_b.h;
    uint8_t right_l = rss_on ? 4 : 0;

    // prep background stripes
    tft.fillRect (map_b.x, map_b.y, map_b.w, MH_TR_H, RA8875_BLACK);                            // top
    tft.fillRect (map_b.x+map_b.w-MH_RC_W, map_b.y, MH_RC_W, right_h, RA8875_BLACK);            // right
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    tft.setTextColor (RA8875_WHITE);

    // print top labels
    uint16_t ry = map_b.y + MH_TR_DY;
    uint16_t cx = map_b.x + map_b.w - MH_RC_W + MH_RC_DX;
    for (uint8_t i = 0; i < 18; i++) {
        tft.setCursor (map_b.x + i*map_b.w/18 + map_b.w/36 - MH_TR_DX, ry);
        tft.print ((char)('A' + i));
    }

    // print right labels
    for (uint8_t i = right_l; i < 18; i++) {
        tft.setCursor (cx, map_b.y + map_b.h - (i+1)*map_b.h/18 + MH_RC_DY);
        tft.print ((char)('A' + i));
    }

}

#if !defined(_IS_ESP8266)

static void drawLLGrid (int lat_step, int lng_step)
{
    int fine_step = 1;

    if (azm_on) {

        // lines of latitude, exclude the poles
        for (float lat = -90+lat_step; lat < 90; lat += lat_step) {
            SCoord s0, s1;
            ll2s (deg2rad(lat), deg2rad(-180), s0, 0);
            bool s0_left = s0.x < map_b.x+map_b.w/2;
            for (float lng = -180+lng_step; lng <= 180; lng += lng_step) {
                ll2s (deg2rad(lat), deg2rad(lng), s1, 0);
                bool s1_left = s1.x < map_b.x+map_b.w/2;
                if (s0_left == s1_left && !overRSS(s0) && !overRSS(s1)) {
                    // full deg spacing on same hemisphere
                    tft.drawLine (s0.x, s0.y, s1.x, s1.y, lat == 0 ? GRIDC00 : GRIDC);
                } else {
                    // backfill with finer fine_steps
                    for (float lg = lng-lng_step+fine_step; lg <= lng; lg += fine_step) {
                        ll2s (deg2rad(lat), deg2rad(lg), s1, 0);
                        s1_left = s1.x < map_b.x+map_b.w/2;
                        if (s0_left == s1_left && !overRSS(s0) && !overRSS(s1))
                            tft.drawLine (s0.x, s0.y, s1.x, s1.y, lat == 0 ? GRIDC00 : GRIDC);
                        s0 = s1;
                        s0_left = s1_left;
                    }
                }
                s0 = s1;
                s0_left = s1_left;
            }
        }

        // lines of longitude -- pole to pole
        for (float lng = -180; lng < 180; lng += lng_step) {
            SCoord s0, s1;
            ll2s (deg2rad(-90), deg2rad(lng), s0, 0);
            bool s0_left = s0.x < map_b.x+map_b.w/2;
            for (float lat = -90+lat_step; lat <= 90; lat += lat_step) {
                ll2s (deg2rad(lat), deg2rad(lng), s1, 0);
                bool s1_left = s1.x < map_b.x+map_b.w/2;
                if (s0_left == s1_left && !overRSS(s0) && !overRSS(s1)) {
                    // full deg spacing on same hemisphere
                    tft.drawLine (s0.x, s0.y, s1.x, s1.y, lng == 0 ? GRIDC00 : GRIDC);
                } else {
                    // backfill with finer fine_steps
                    for (float lt = lat-lat_step+fine_step; lt <= lat; lt += fine_step) {
                        ll2s (deg2rad(lt), deg2rad(lng), s1, 0);
                        s1_left = s1.x < map_b.x+map_b.w/2;
                        if (s0_left == s1_left && !overRSS(s0) && !overRSS(s1))
                            tft.drawLine (s0.x, s0.y, s1.x, s1.y, lng == 0 ? GRIDC00 : GRIDC);
                        s0 = s1;
                        s0_left = s1_left;
                    }
                }
                s0 = s1;
                s0_left = s1_left;
            }
        }

    } else {

        // easy! just straight lines

        int n_lngstep = 360/lng_step;
        int n_latstep = 180/lat_step;

        // vertical
        for (int i = 1; i < n_lngstep; i++) {
            uint16_t x = map_b.x + i*map_b.w/n_lngstep;
            uint16_t top_y = x < view_btn_b.x + view_btn_b.w ? view_btn_b.y + view_btn_b.h : map_b.y;
            uint16_t bot_y;
            if (rss_on)
                bot_y = rss_bnr_b.y - 1;
            else if (core_map == CM_DRAP)
                bot_y = map_b.y + 5*map_b.h/6;      // skip last 30 degs
            else
                bot_y = map_b.y+map_b.h-1;
            tft.drawLine (x, top_y, x, bot_y, i == n_lngstep/2 ? GRIDC00 : GRIDC);
        }

        // horizontal -- skip last 30 degs if DRAP
        for (int i = 1; i < n_latstep; i++) {
            uint16_t y = map_b.y + i*map_b.h/n_latstep;
            if ((!rss_on || y < rss_bnr_b.y) && (core_map != CM_DRAP || i <= 150/lat_step))
                tft.drawLine (map_b.x, y, map_b.x+map_b.w-1, y, i == n_latstep/2 ? GRIDC00 : GRIDC);
        }

    }
}

/* draw the complete proper map grid, ESP draws incrementally as map is drawn.
 */
static void drawMapGrid()
{
    resetWatchdog();

    switch (llg_on) {
    case LLG_GRID:

        // key only for mercator
        if (!azm_on)
            drawMaidGridKey();
        drawLLGrid (10, 20);
        break;

    case LLG_ALL:

        drawLLGrid (15, 15);
        break;

    case LLG_TROPICS:

        if (azm_on) {

            // just 2 lines at lat +- 23.5
            SCoord s00, s01, s10, s11;
            ll2s (deg2rad(-23.5F), deg2rad(-180), s00, 0);
            ll2s (deg2rad(23.5F), deg2rad(-180), s10, 0);
            for (float lng = -180; lng <= 180; lng += 1) {
                ll2s (deg2rad(-23.5), deg2rad(lng), s01, 0);
                ll2s (deg2rad(23.5), deg2rad(lng), s11, 0);
                if (segmentSpanOk(s00,s01))
                    tft.drawLine (s00.x, s00.y, s01.x, s01.y, GRIDC00);
                s00 = s01;
                if (segmentSpanOk(s10,s11))
                    tft.drawLine (s10.x, s10.y, s11.x, s11.y, GRIDC00);
                s10 = s11;
            }

        } else {

            // easy! just 2 straight lines
            uint16_t y = map_b.y + map_b.h/2 - 23.5F*map_b.h/180;
            tft.drawLine (map_b.x, y, map_b.x+map_b.w-1, y, GRIDC00);
            y = map_b.y + map_b.h/2 + 23.5F*map_b.h/180;
            tft.drawLine (map_b.x, y, map_b.x+map_b.w-1, y, GRIDC00);

        }

        break;

    case LLG_OFF:           // fallthru
    default:

        // none
        break;

    }
}

/* draw local information about the current cursor position over the world map.
 * does not work for ESP because there is no way to follow touch without making a tap.
 */
static void drawMouseLoc()
{
    resetWatchdog();

    // draw just below map View button
    uint16_t tx = view_btn_b.x;
    uint16_t ty = view_btn_b.y + view_btn_b.h + 1;

    // get current mouse location
    uint16_t mx, my;
    (void) tft.getMouse(&mx, &my);

    // get corresponding map location, if any
    LatLong ll;
    bool overmap = s2ll (mx, my, ll);

    // always erase if azm or overmap
    if (azm_on || overmap)
        tft.fillRect (tx, ty, VIEWBTN_W, MOUSELOC_H, RA8875_BLACK);

    // but abandon if not over map
    if (!overmap)
        return;

    // prep for text
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    tft.setTextColor (RA8875_WHITE);

    // show lat/long
    tft.setCursor (tx+1, ty+1);
    tft.printf ("%5.1f%c", fabsf(ll.lat_d), ll.lat_d < 0 ? 'S' : 'N');
    tft.setCursor (tx+1, ty+=10);
    tft.printf ("%5.1f%c", fabsf(ll.lng_d), ll.lng_d < 0 ? 'W' : 'E');

    // show maid
    char maid[2][5];
    ll2maidenhead (maid, ll);
    tft.setCursor (tx+13, ty+=10);
    tft.printf ("%s", maid[0]);

    // show local time
    time_t lt = nowWO() + getTZ(ll);
    tft.setCursor (tx+7, ty+=10);
    tft.printf ("%02d:%02d", hour(lt), minute(lt));
}

#endif // !_IS_ESP8266

static void updateCircumstances()
{
    time_t utc = nowWO();

    getSolarCir (utc, de_ll, solar_cir);
    sun_ss_ll.lat_d = rad2deg(solar_cir.dec);
    sun_ss_ll.lng_d = -rad2deg(solar_cir.gha);
    normalizeLL (sun_ss_ll);
    csslat = cosf(sun_ss_ll.lat);
    ssslat = sinf(sun_ss_ll.lat);
    ll2s (sun_ss_ll, sun_c.s, SUN_R+1);

    getLunarCir (utc, de_ll, lunar_cir);
    moon_ss_ll.lat_d = rad2deg(lunar_cir.dec);
    moon_ss_ll.lng_d = -rad2deg(lunar_cir.gha);
    normalizeLL (moon_ss_ll);
    ll2s (moon_ss_ll, moon_c.s, MOON_R+1);

    updateSatPath();
}

/* draw the map view menu button.
 * adjust position depending on whether we are drawing the maidenhead grids.
 * adjust view_pick_b to match.
 */
static void drawMapMenuButton()
{
    resetWatchdog();

    if (llg_on == LLG_GRID && !azm_on)
        view_pick_b.y = view_btn_b.y = map_b.y + MH_TR_H;
    else
        view_pick_b.y = view_btn_b.y = map_b.y;

    // 1 pixel inside so onMap() gives 2-pixel thick sat footprints some room
    tft.fillRect (view_btn_b.x, view_btn_b.y, view_btn_b.w-1, view_btn_b.h-1, RA8875_BLACK);
    tft.drawRect (view_btn_b.x, view_btn_b.y, view_btn_b.w-1, view_btn_b.h-1, RA8875_WHITE);

    const char *str = "View";
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    uint16_t str_w = getTextWidth(str);
    tft.setCursor (view_btn_b.x+(view_btn_b.w-str_w)/2, view_btn_b.y+2);
    tft.setTextColor (RA8875_WHITE);
    tft.print (str);
}

/* erase the RSS box
 */
void eraseRSSBox ()
{
    // erase entire banner if azm mode because redrawing the map will miss the corners
    if (azm_on)
        tft.fillRect (rss_bnr_b.x, rss_bnr_b.y, rss_bnr_b.w, rss_bnr_b.h, RA8875_BLACK);

    // restore map and sat path
    for (uint16_t y = rss_bnr_b.y; y < rss_bnr_b.y+rss_bnr_b.h; y++) {
        updateClocks(false);
        for (uint16_t x = rss_bnr_b.x; x < rss_bnr_b.x+rss_bnr_b.w; x += 1)
            drawMapCoord (x, y);
        drawSatPointsOnRow (y);
    }

    // draw symbols in case these were in the banner box
    drawSatPathAndFoot();
    drawSatNameOnRow (0);
    drawAllSymbols(false);
    if (waiting4DXPath())
        drawDXPath();
}

/* draw, perform and engage results of the map View menu
 */
void drawMapMenu()
{
    // menu definition
    typedef enum {
        MIT_TITLE,                              // inactive string
        MIT_1OFN,                               // exactly 1 on within contiguous group at a time
        MIT_TOGGLE                              // single item on or off
    } MIType;                                   // how this item behaves
    enum MIName {                               // menu items -- N.B. must be in same order as menu[]
        MI_STY_TTL, MI_STY_CTY, MI_STY_TER, MI_STY_DRA,
        MI_GRD_TTL, MI_GRD_NON, MI_GRD_TRO, MI_GRD_LLG, MI_GRD_MAI,
        MI_PRJ_TTL, MI_PRJ_AZM, MI_PRJ_MER,
        MI_RSS_YES,
        MI_NON_YES,
        MI_N
    };
    typedef struct {
        const char *str;                        // prompt
        MIType type;                            // functional type
        bool selected;                          // whether currently selected
    } MenuItem;
    MenuItem menu[MI_N] = {
        {"Style:", MIT_TITLE, 0},
            {map_styles[CM_COUNTRIES], MIT_1OFN, 0},
            {map_styles[CM_TERRAIN], MIT_1OFN, 0}, 
            {map_styles[CM_DRAP], MIT_1OFN, 0},
        {"Grid:", MIT_TITLE, 0},
            {"None", MIT_1OFN, 0},
            {"Tropics", MIT_1OFN, 0},
            {"Lat/Long", MIT_1OFN, 0},
            {"Maidenhead", MIT_1OFN, 0},
        {"Projection:", MIT_TITLE, 0},
            {"Azimuthal", MIT_1OFN, 0},
            {"Mercator", MIT_1OFN, 0},
        {"Show RSS", MIT_TOGGLE, 0},
        {"Show night", MIT_TOGGLE, 0},
    };

    // menu layout constants

    #define     MLO_LS  14                      // vertical line spacing
    #define     MLO_VB  2                       // vertical border
    #define     MLO_TI  3                       // title or toggle indent
    #define     MLO_1I  8                       // 1-of-N indent
    #define     MLO_IS  9                       // spacing between indicator left and text
    #define     MLO_YO  3                       // indicator y offset
    #define     MLO_IR  2                       // indicator radius

    // handy
    #define DrawMI(x,y,s)   tft.fillCircle ((x)+MLO_IR, (y)+MLO_YO, MLO_IR, (s)?RA8875_WHITE:RA8875_BLACK), \
			    tft.drawCircle ((x)+MLO_IR, (y)+MLO_YO, MLO_IR, RA8875_WHITE)
    #define MI2Y(i)         (menu_b.y + MLO_VB + (i)*MLO_LS)

    static const char ok_prompt[] = "Ok";
    static const char cancel_prompt[] = "Cancel";

    // overall menu box

    SBox menu_b;
    menu_b.x = view_btn_b.x;                    // left edge matches view button
    menu_b.y = view_btn_b.y+view_btn_b.h;       // top just below view button
    menu_b.w = VIEWMENU_W;                      // enough for widest string
    menu_b.h = 2*MLO_VB+MLO_LS*(MI_N+1);        // +1 for ok/cancel

    // init selections with current states

    menu[MI_STY_CTY].selected = core_map == CM_COUNTRIES;
    menu[MI_STY_TER].selected = core_map == CM_TERRAIN;
    menu[MI_STY_DRA].selected = core_map == CM_DRAP;

    menu[MI_GRD_NON].selected = llg_on == LLG_OFF;
    menu[MI_GRD_TRO].selected = llg_on == LLG_TROPICS;
    menu[MI_GRD_LLG].selected = llg_on == LLG_ALL;
    menu[MI_GRD_MAI].selected = llg_on == LLG_GRID;

    menu[MI_PRJ_AZM].selected = azm_on;
    menu[MI_PRJ_MER].selected = !azm_on;

    menu[MI_RSS_YES].selected = rss_on;

    menu[MI_NON_YES].selected = night_on;

    // draw initial menu

    tft.fillRect (menu_b.x, menu_b.y, menu_b.w, menu_b.h, RA8875_BLACK);
    tft.drawRect (menu_b.x, menu_b.y, menu_b.w, menu_b.h, RA8875_WHITE);

    tft.setTextColor (RA8875_WHITE);
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    for (int i = 0; i < MI_N; i++) {

        // draw indicator, if any, and position for text
        uint16_t x = menu_b.x;
        uint16_t y = MI2Y(i);
        switch (menu[i].type) {
        case MIT_TITLE:
            x += MLO_TI;
            break;
        case MIT_1OFN:
            x += MLO_1I;
            DrawMI(x,y, menu[i].selected);
            x += MLO_IS;
            break;
        case MIT_TOGGLE:
            x += MLO_TI;
            DrawMI(x,y, menu[i].selected);
            x += MLO_IS;
            break;
        }

        // draw text
        tft.setCursor (x, y);
        tft.print (menu[i].str);
    }

    // add ok and cancel buttons at the bottom

    SBox ok_b;
    ok_b.x = menu_b.x+MLO_TI;
    ok_b.y = MI2Y(MI_N);
    ok_b.w = getTextWidth (ok_prompt) + 4;
    ok_b.h = MLO_LS-2;
    tft.drawRect (ok_b.x, ok_b.y, ok_b.w, ok_b.h, RA8875_WHITE);
    tft.setCursor (ok_b.x+2, ok_b.y+2);
    tft.print (ok_prompt);

    SBox cancel_b;
    cancel_b.x = menu_b.x+menu_b.w-getTextWidth(cancel_prompt)-MLO_TI-4;
    cancel_b.y = ok_b.y;
    cancel_b.w = getTextWidth(cancel_prompt) + 4;
    cancel_b.h = ok_b.h;
    tft.drawRect (cancel_b.x, cancel_b.y, cancel_b.w, cancel_b.h, RA8875_WHITE);
    tft.setCursor (cancel_b.x+2, cancel_b.y+2);
    tft.print (cancel_prompt);

    // show now
    tft.drawPR();

    // follow all user interaction with timeout

    uint32_t t0 = millis();
    bool cancelled = false;
    drainTouch();
    for (;;) {
        resetWatchdog();

        // cancel if time out
        if (millis() - t0 > MENU_TO) {
            cancelled = true;
            break;
        }

        SCoord s;
        if (readCalTouch(s) != TT_NONE) {

            // cancel if tap cancel or outside menu
            if (inBox(s, cancel_b) || !inBox (s, menu_b)) {
                cancelled = true;
                break;
            }

            // done if tap ok
            if (inBox (s, ok_b))
                break;

            // handle tap
            int i = (s.y-menu_b.y-MLO_VB)/MLO_LS;
            if (i < MI_N) {
                switch (menu[i].type) {
                case MIT_TITLE:
                    // titles are mute
                    break;
                case MIT_1OFN:
                    // if not already on turn this item on, others in group off
                    if (!menu[i].selected) {
                        for (int j = i-1; j >= 0 && menu[j].type == MIT_1OFN; --j) {
                            DrawMI (menu_b.x+MLO_1I, MI2Y(j), false);
                            menu[j].selected = false;
                        }
                        for (int j = i+1; j < MI_N && menu[j].type == MIT_1OFN; j++) {
                            DrawMI (menu_b.x+MLO_1I, MI2Y(j), false);
                            menu[j].selected = false;
                        }
                        menu[i].selected = true;
                        DrawMI (menu_b.x+MLO_1I, MI2Y(i), true);
                    }
                    break;
                case MIT_TOGGLE:
                    // toggle
                    menu[i].selected = !menu[i].selected;
		    DrawMI (menu_b.x+MLO_TI, MI2Y(i), menu[i].selected);
                    break;
                }

                // menu is within the protected region so trigger an immediate visual update
                tft.drawPR();
            }

            // refresh timeout
            t0 = millis();


        } else {
            // slowish poll
            wdDelay (100);
        }

        updateClocks(false);

    }

    // persist and engage any/all changes unless cancelled

    bool full_redraw = false;
    if (!cancelled) {

        // show Ok yellow for busy
        selectFontStyle (LIGHT_FONT, FAST_FONT);
        tft.setTextColor (RA8875_BLACK);
        tft.fillRect (ok_b.x, ok_b.y, ok_b.w, ok_b.h, RA8875_YELLOW);
        tft.setCursor (ok_b.x+2, ok_b.y+2);
        tft.print (ok_prompt);
        tft.drawPR();

        // update bg iff style changed
        // N.B. this allows voacap to remain engaged if changing only the other view options
        CoreMaps new_cm = CM_NONE;
        if (menu[MI_STY_CTY].selected && core_map != CM_COUNTRIES)
            new_cm = CM_COUNTRIES;
        else if (menu[MI_STY_TER].selected && core_map != CM_TERRAIN)
            new_cm = CM_TERRAIN;
        else if (menu[MI_STY_DRA].selected && core_map != CM_DRAP)
            new_cm = CM_DRAP;
        if (new_cm != CM_NONE) {
            if (installNewMapStyle (new_cm)) {
                full_redraw = true;
            } else {
                // show red ok button
                tft.setTextColor (RA8875_WHITE);
                tft.fillRect (ok_b.x, ok_b.y, ok_b.w, ok_b.h, RA8875_RED);
                tft.setCursor (ok_b.x+2, ok_b.y+2);
                tft.print (ok_prompt);
                tft.drawPR();
            }
        }

        // check for new grid
        if (menu[MI_GRD_NON].selected && llg_on != LLG_OFF) {
            llg_on = LLG_OFF;
            NVWriteUInt8 (NV_LLGRID, llg_on);
            full_redraw = true;
        } else if (menu[MI_GRD_TRO].selected && llg_on != LLG_TROPICS) {
            llg_on = LLG_TROPICS;
            NVWriteUInt8 (NV_LLGRID, llg_on);
            full_redraw = true;
        } else if (menu[MI_GRD_LLG].selected && llg_on != LLG_ALL) {
            llg_on = LLG_ALL;
            NVWriteUInt8 (NV_LLGRID, llg_on);
            full_redraw = true;
        } else if (menu[MI_GRD_MAI].selected && llg_on != LLG_GRID) {
            llg_on = LLG_GRID;
            NVWriteUInt8 (NV_LLGRID, llg_on);
            full_redraw = true;
        }

        // check for different azm/merc
        if (menu[MI_PRJ_AZM].selected != azm_on) {
            azm_on = menu[MI_PRJ_AZM].selected;
            NVWriteUInt8 (NV_AZIMUTHAL_ON, azm_on);
            full_redraw = true;
        }

        // check for change night option
        if (menu[MI_NON_YES].selected != night_on) {
            night_on = menu[MI_NON_YES].selected;
            NVWriteUInt8 (NV_NIGHT_ON, night_on);
            full_redraw = true;
        }

        // check for changed RSS -- N.B. do this last to utilize full_redraw
        if (menu[MI_RSS_YES].selected != rss_on) {
            rss_on = menu[MI_RSS_YES].selected;
            NVWriteUInt8 (NV_RSS_ON, rss_on);
            if (!full_redraw) {
                if (rss_on)
                    scheduleRSSNow();
                else
                    eraseRSSBox();
            }
        }

        // restart map if it has changed
        if (full_redraw)
            initEarthMap();

        // update state
        logState();
    }

    if (cancelled || !full_redraw) {
        // just erase menu
        // TODO: black rectangle is for azm mode, better to restore stars
        resetWatchdog();
        tft.fillRect (menu_b.x, menu_b.y, menu_b.w, menu_b.h, RA8875_BLACK);
        for (uint16_t dy = 0; dy < menu_b.h; dy++)
            for (uint16_t dx = 0; dx < menu_b.w; dx++)
                drawMapCoord (menu_b.x+dx, menu_b.y+dy);
        drawSatPathAndFoot();
        drawSatNameOnRow (0);
        drawAllSymbols(false);
        if (waiting4DXPath())
            drawDXPath();
    }

    tft.drawPR();

    // discard an extra taps
    drainTouch();

    printFreeHeap (F("drawMapMenu"));

}

/* restart map given de_ll and dx_ll
 */
void initEarthMap()
{
    resetWatchdog();

    // completely erase map
    tft.fillRect (map_b.x, map_b.y, map_b.w, map_b.h, RA8875_BLACK);

    // add funky star field if azm
    if (azm_on)
        drawAzmStars();

    // freshen RSS and clocks
    scheduleRSSNow();
    updateClocks(true);

    // draw map view button over map
    drawMapMenuButton();

    // reset any pending great circle path
    setDXPathInvalid();

    // update astro info
    updateCircumstances();

    // update DE and DX info
    sdelat = sinf(de_ll.lat);
    cdelat = cosf(de_ll.lat);
    ll2s (de_ll, de_c.s, DE_R);
    antipode (deap_ll, de_ll);
    ll2s (deap_ll, deap_c.s, DEAP_R);
    ll2s (dx_ll, dx_c.s, DX_R);

    // show updated info
    drawDEInfo();
    drawDXInfo();

    // insure NCDXF and DX spots screen coords match current map type
    updateBeaconScreenLocations();
    updateDXSpotScreenLocations();

    // init scan line in map_b
    moremap_s.x = 0;                    // avoid updateCircumstances() first call to drawMoreEarth()
    moremap_s.y = map_b.y;

    // now main loop can resume with drawMoreEarth()
}

/* display another earth map row at mmoremap_s.
 * ESP draws map one line at a time, others draw all the map then all the symbols to overlay.
 */
void drawMoreEarth()
{
    resetWatchdog();

    // handy health indicator and update timer
    digitalWrite(LIFE_LED, !digitalRead(LIFE_LED));

    // refresh circumstances at start of each map scan but not very first call after initEarthMap()
    if (moremap_s.y == map_b.y && moremap_s.x != 0)
        updateCircumstances();
    
    uint16_t last_x = map_b.x + EARTH_W - 1;

#if defined(_IS_ESP8266)

    // freeze if showing a temporary DX-DE path
    if (waiting4DXPath())
        return;

    // grid key if first row
    if (moremap_s.y == map_b.y && llg_on == LLG_GRID && !azm_on)
        drawMaidGridKey();

    // avoid symbols as the map is drawn

    // whether found any symbols on this row or col
    uint8_t n_symbols_this_row = 0;

    // preserve whether any symbols were found on this row for next time
    static uint8_t n_symbols_prev_row;

    // draw next row
    resetWatchdog();
    for (moremap_s.x = map_b.x; moremap_s.x <= last_x; moremap_s.x += 1) {

        // test whether now over a symbol
        bool over_symbol = overAnySymbol (moremap_s);
        n_symbols_this_row += over_symbol;

        // draw map if not
        if (!over_symbol)
            drawMapCoord (moremap_s);
    }

    // draw all symbols if hit one on line above but none on this row
    if (n_symbols_this_row == 0 && n_symbols_prev_row > 0)
        drawAllSymbols(false);

    // draw more sat path or foot on this row
    drawSatPointsOnRow (moremap_s.y);

    // draw name if clobbered
    drawSatNameOnRow (moremap_s.y);

    // save whether hit any symbols on this row
    n_symbols_prev_row = n_symbols_this_row;


#else   // !defined(_IS_ESP8266)

    // draw next row
    for (moremap_s.x = map_b.x; moremap_s.x <= last_x; moremap_s.x++) {

        drawMapCoord (moremap_s);

    }

#endif  // defined(_IS_ESP8266)

    // advance row, accounting for any row replication, and wrap at the end
    if ((moremap_s.y += 1) >= map_b.y + EARTH_H) {
        moremap_s.y = map_b.y;

#if !defined(_IS_ESP8266)

        // all but ESP draw the entire map then all the symbols as a sort of overlay

        drawMapGrid();
        drawSatPathAndFoot();
        drawSatNameOnRow (0);
        drawAllSymbols(false);
        if (waiting4DXPath())
            drawDXPath();
        drawMouseLoc();

        // draw now
        tft.drawPR();
#endif // !_IS_ESP8266

    }
}

/* convert lat and long in radians to screen coords.
 * keep result no closer than the given edge distance.
 * N.B. we assume lat/lng are in range [-90,90] [-180,180)
 */
void ll2s (float lat, float lng, SCoord &s, uint8_t edge)
{
    LatLong ll;
    ll.lat = lat;
    ll.lat_d = rad2deg(ll.lat);
    ll.lng = lng;
    ll.lng_d = rad2deg(ll.lng);
    ll2s (ll, s, edge);
}
void ll2s (const LatLong &ll, SCoord &s, uint8_t edge)
{
    resetWatchdog();

    if (azm_on) {

        // azimuthal projection

        // sph tri between de, dx and N pole
        float ca, B;
        solveSphere (ll.lng - de_ll.lng, M_PI_2F-ll.lat, sdelat, cdelat, &ca, &B);

        if (ca > 0) {
            // front (left) side, centered at DE
            float a = acosf (ca);
            float R = fminf (a*map_b.w/(2*M_PIF), map_b.w/4 - edge - 1);        // well clear
            float dx = R*sinf(B);
            float dy = R*cosf(B);
            s.x = map_b.x + map_b.w/4 + dx;
            s.y = map_b.y + map_b.h/2 - dy;
        } else {
            // back (right) side, centered at DE antipode
            float a = M_PIF - acosf (ca);
            float R = fminf (a*map_b.w/(2*M_PIF), map_b.w/4 - edge - 1);        // well clear
            float dx = -R*sinf(B);
            float dy = R*cosf(B);
            s.x = map_b.x + 3*map_b.w/4 + dx;
            s.y = map_b.y + map_b.h/2 - dy;
        }

    } else {

        // straight rectangular Mercator projection
        s.x = map_b.x + map_b.w*(ll.lng_d+180)/360;
        s.y = map_b.y + map_b.h*(90-ll.lat_d)/180;

        // guard edge
        uint16_t e;
        e = map_b.x + edge;
        if (s.x < e)
            s.x = e;
        e = map_b.x + map_b.w - edge - 1;
        if (s.x > e)
            s.x = e;
        e = map_b.y + edge;
        if (s.y < e)
            s.y = e;
        e = map_b.y + map_b.h - edge - 1;
        if (s.y > e)
            s.y = e;
    }

}

/* convert a screen coord to lat and long.
 * return whether location is really over valid map.
 */
bool s2ll (uint16_t x, uint16_t y, LatLong &ll)
{
    SCoord s;
    s.x = x;
    s.y = y;
    return (s2ll (s, ll));
}
bool s2ll (const SCoord &s, LatLong &ll)
{
    if (!overMap(s))
        return (false);

    if (azm_on) {

        // radius from center of point's hemisphere
        bool on_right = s.x > map_b.x + map_b.w/2;
        int32_t dx = on_right ? s.x - (map_b.x + 3*map_b.w/4) : s.x - (map_b.x + map_b.w/4);
        int32_t dy = (map_b.y + map_b.h/2) - s.y;
        int32_t r2 = dx*dx + dy*dy;

        // see if really on surface
        int32_t w2 = map_b.w*map_b.w/16;
        if (r2 > w2)
            return(false);

        // use screen triangle to find globe
        float b = sqrtf((float)r2/w2)*(M_PI_2F);
        float A = (M_PI_2F) - atan2f (dy, dx);
        float ca, B;
        solveSphere (A, b, (on_right ? -1 : 1) * sdelat, cdelat, &ca, &B);
        float lt = M_PI_2F - acosf(ca);
        ll.lat_d = rad2deg(lt);
        float lg = fmodf (de_ll.lng + B + (on_right?6:5)*M_PIF, 2*M_PIF) - M_PIF;
        ll.lng_d = rad2deg(lg);

    } else {

        // straight rectangular mercator projection

        ll.lat_d = 90 - 180.0F*(s.y - map_b.y)/(EARTH_H);
        ll.lng_d = 360.0F*(s.x - map_b.x)/(EARTH_W) - 180;

    }

    normalizeLL(ll);

    return (true);
}

#if defined(_IS_ESP8266)

/* given lat/lng and cos of angle from terminator, return earth map pixel.
 * only used by ESP, all others draw at higher resolution.
 */
static uint16_t getEarthMapPix (LatLong ll, float cos_t)
{
    // indices into pixel array at this location
    uint16_t ex = (uint16_t)((EARTH_W*(ll.lng_d+180)/360)+0.5F) % EARTH_W;
    uint16_t ey = (uint16_t)((EARTH_H*(90-ll.lat_d)/180)+0.5F) % EARTH_H;

    // final color
    uint16_t pix_c;

    // decide color
    if (!night_on || cos_t > 0) {
        // < 90 deg: full sunlit
        getMapDayPixel (ey, ex, &pix_c);
    } else if (cos_t > GRAYLINE_COS) {
        // blend from day to night
        uint16_t day_c, night_c;
        getMapDayPixel (ey, ex, &day_c);
        getMapNightPixel (ey, ex, &night_c);
        uint8_t day_r = RGB565_R(day_c);
        uint8_t day_g = RGB565_G(day_c);
        uint8_t day_b = RGB565_B(day_c);
        uint8_t night_r = RGB565_R(night_c);
        uint8_t night_g = RGB565_G(night_c);
        uint8_t night_b = RGB565_B(night_c);
        float fract_night = powf(cos_t/GRAYLINE_COS, GRAYLINE_POW);
        float fract_day = 1 - fract_night;
        uint8_t twi_r = (fract_day*day_r + fract_night*night_r);
        uint8_t twi_g = (fract_day*day_g + fract_night*night_g);
        uint8_t twi_b = (fract_day*day_b + fract_night*night_b);
        pix_c = RGB565 (twi_r, twi_g, twi_b);
    } else {
        // full night side
        getMapNightPixel (ey, ex, &pix_c);
    }

    return (pix_c);
}

#endif

/* draw at the given screen location, if it's over the map.
 */
void drawMapCoord (uint16_t x, uint16_t y)
{

    SCoord s;
    s.x = x;
    s.y = y;
    drawMapCoord (s);
}
void drawMapCoord (const SCoord &s)
{

    #if defined(_IS_ESP8266)

        // draw one pixel, which might be an annotation line, if over map

        // a latitude cache really helps Mercator time; anything help Azimuthal??
        static float slat_c, clat_c;
        static SCoord s_c;

        // find lat/lng at this screen location, done if not over map
        LatLong lls;
        if (!s2ll(s, lls))
            return;

        // update handy Mercator cache, but always required for Azm.
        if (azm_on || s.y != s_c.y) {
            s_c = s;
            slat_c = sinf(lls.lat);
            clat_c = cosf(lls.lat);
        }

        // draw lat/long grid if enabled
        #define DLAT        0.6F
        #define DLNG        (0.5F/clat_c)

        switch (llg_on) {
        case LLG_ALL:

            if (azm_on) {

                if (fmodf(lls.lat_d+90, 15) < DLAT || fmodf (lls.lng_d+180, 15) < DLNG) {
                    uint32_t grid_c = (fabsf (lls.lat_d) < DLAT || fabs (lls.lng_d) < DLNG) ? GRIDC00 : GRIDC;
                    tft.drawPixel (s.x, s.y, grid_c);
                    return;                                         // done
                }

            } else {

                // extra gymnastics are because the pixels-per-divisions are not integral
                #define ALL_PPLG (EARTH_W/(360/15))
                #define ALL_PPLT (EARTH_H/(180/15))
                if ((core_map != CM_DRAP || s.y <= map_b.y + 5*map_b.h/6) &&     // skip last 2 rows
                          ((((s.x - map_b.x) - (s.x - map_b.x)/(2*ALL_PPLG)) % ALL_PPLG) == 0
                                    || (((s.y - map_b.y) - (s.y - map_b.y)/(2*ALL_PPLT)) % ALL_PPLT) == 0)) {
                    uint32_t grid_c = (fabsf (lls.lat_d) < DLAT || fabs (lls.lng_d) < DLNG) ? GRIDC00 : GRIDC;
                    tft.drawPixel (s.x, s.y, grid_c);
                    return;                                         // done
                }
            }

            break;

        case LLG_TROPICS:

            if (azm_on) {

                if (fabsf (fabsf (lls.lat_d) - 23.5F) < 0.3F) {
                    tft.drawPixel (s.x, s.y, GRIDC00);
                    return;                                         // done
                }

            } else {

                // we already know exactly where the grid lines go.
                if (abs(s.y - (map_b.y+EARTH_H/2)) == (uint16_t)((23.5F/180)*(EARTH_H))) {
                    tft.drawPixel (s.x, s.y, GRIDC00);
                    return;                                         // done
                }
            }
            break;

        case LLG_GRID:

            if (azm_on) {

                if (fmodf(lls.lat_d+90, 10) < DLAT || fmodf (lls.lng_d+180, 20) < DLNG) {
                    uint32_t grid_c = (fabsf (lls.lat_d) < DLAT || fabs (lls.lng_d) < DLNG) ? GRIDC00 : GRIDC;
                    tft.drawPixel (s.x, s.y, grid_c);
                    return;                                         // done
                }

            } else {

                // extra gymnastics are because the pixels-per-divisions are not integral
                #define MAI_PPLG (EARTH_W/(360/20))
                #define MAI_PPLT (EARTH_H/(180/10))
                if ((core_map != CM_DRAP || s.y <= map_b.y + 5*map_b.h/6) &&     // skip last 30 degs
                            ((((s.x - map_b.x) - 2*(s.x - map_b.x)/(3*MAI_PPLG)) % MAI_PPLG) == 0
                                    || (((s.y - map_b.y) - (s.y - map_b.y)/(3*MAI_PPLT)) % MAI_PPLT) == 0)) {
                    tft.drawPixel (s.x, s.y, GRIDC);
                    return;                                         // done
                }
            }

            break;

        default:

            // none
            break;

        }

        // if get here we did not draw a lat/long grid point

        // find angle between subsolar point and this location
        float cos_t = ssslat*slat_c + csslat*clat_c*cosf(sun_ss_ll.lng-lls.lng);

        uint16_t pix_c = getEarthMapPix (lls, cos_t);
        tft.drawPixel (s.x, s.y, pix_c);

        // preserve for next call
        s_c = s;


    #else // !defined(_IS_ESP8266)


        // draw one map pixel at full screen resolution. requires lat/lng gradients.

        // find lat/lng at this screen location, bale if not over map
        LatLong lls;
        if (!s2ll(s,lls))
            return; 

        /* even though we only draw one application point, s, plotEarth needs points r and d to
         * interpolate to full map resolution.
         *   s - - - r
         *   |
         *   d
         */
        SCoord sr, sd;
        LatLong llr, lld;
        sr.x = s.x + 1;
        sr.y = s.y;
        if (!s2ll(sr,llr))
            llr = lls;
        sd.x = s.x;
        sd.y = s.y + 1;
        if (!s2ll(sd,lld))
            lld = lls;

        // find angle between subsolar point and any visible near this location
        // TODO: actually different at each point, this causes striping
        float clat = cosf(lls.lat);
        float slat = sinf(lls.lat);
        float cos_t = ssslat*slat + csslat*clat*cosf(sun_ss_ll.lng-lls.lng);

        // decide day, night or twilight
        float fract_day;
        if (!night_on || cos_t > 0) {
            // < 90 deg: sunlit
            fract_day = 1;
        } else if (cos_t > GRAYLINE_COS) {
            // blend from day to night
            fract_day = 1 - powf(cos_t/GRAYLINE_COS, GRAYLINE_POW);
        } else {
            // night side
            fract_day = 0;
        }

        // draw the full res map point
        tft.plotEarth (s.x, s.y, lls.lat_d, lls.lng_d, llr.lat_d - lls.lat_d, llr.lng_d - lls.lng_d,
                    lld.lat_d - lls.lat_d, lld.lng_d - lls.lng_d, fract_day);

    #endif  // !_IS_ESP8266

}

/* draw sun symbol.
 * N.B. we assume sun_c coords insure marker will be wholy within map boundaries.
 */
void drawSun ()
{
    resetWatchdog();

#   define      N_SUN_RAYS      12
    uint16_t body_r = 5*SUN_R/9;
    tft.fillCircle (sun_c.s.x, sun_c.s.y, SUN_R, RA8875_BLACK);
    tft.fillCircle (sun_c.s.x, sun_c.s.y, body_r, RA8875_YELLOW);
    for (uint8_t i = 0; i < N_SUN_RAYS; i++) {
        float a = i*2*M_PIF/N_SUN_RAYS;
        float sa = sinf(a);
        float ca = cosf(a);
        uint16_t x0 = sun_c.s.x + (body_r+2)*ca + 0.5F;
        uint16_t y0 = sun_c.s.y + (body_r+2)*sa + 0.5F;
        uint16_t x1 = sun_c.s.x + (SUN_R)*ca + 0.5F;
        uint16_t y1 = sun_c.s.y + (SUN_R)*sa + 0.5F;
        tft.drawLine (x0, y0, x1, y1, RA8875_YELLOW);
    }
#   undef N_SUN_RAYS
}

/* draw moon symbol.
 * N.B. we assume moon_c coords insure marker will be wholy within map boundaries.
 */
void drawMoon ()
{
    resetWatchdog();

    float phase = lunar_cir.phase;
    
    const uint16_t mr = MOON_R*tft.SCALESZ;             // moon radius on output device
    for (int16_t dy = -mr; dy <= mr; dy++) {            // scan top to bottom
        float Ry = sqrtf(mr*mr-dy*dy);                  // half-width at y
        int16_t Ryi = floorf(Ry+0.5F);                  // " as int
        for (int16_t dx = -Ryi; dx <= Ryi; dx++) {      // scan left to right at y
            float a = acosf((float)dx/Ryi);             // looking down from NP CW from right limb
            tft.drawSubPixel (tft.SCALESZ*moon_c.s.x+dx, tft.SCALESZ*moon_c.s.y+dy,
                    (isnan(a) || (phase > 0 && a > phase) || (phase < 0 && a < phase+M_PIF))
                        ? RA8875_BLACK : RA8875_WHITE);
        }
    }
}

/* display some info about DX location in dx_info_b
 */
void drawDXInfo ()
{
    resetWatchdog();

    // skip if dx_info_b being used for sat info
    if (dx_info_for_sat)
        return;

    // divide into 5 rows
    uint16_t vspace = dx_info_b.h/DX_INFO_ROWS;

    // time
    drawDXTime();

    // erase and init
    tft.graphicsMode();
    tft.fillRect (dx_info_b.x, dx_info_b.y+2*vspace, dx_info_b.w, dx_info_b.h-2*vspace+1, RA8875_BLACK);
    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    tft.setTextColor (DX_COLOR);

    // lat and long
    char buf[30];
    sprintf (buf, "%.0f%c  %.0f%c",
                roundf(fabsf(dx_ll.lat_d)), dx_ll.lat_d < 0 ? 'S' : 'N',
                roundf(fabsf(dx_ll.lng_d)), dx_ll.lng_d < 0 ? 'W' : 'E');
    tft.setCursor (dx_info_b.x, dx_info_b.y+3*vspace-8);
    tft.print(buf);
    uint16_t bw, bh;
    getTextBounds (buf, &bw, &bh);

    // maidenhead
    drawMaidenhead(NV_DX_GRID, dx_maid_b, DX_COLOR);

    // compute dist and bearing
    float dist, bearing;
    propDEDXPath (show_lp, &dist, &bearing);
    dist *= ERAD_M;                             // angle to miles
    bearing *= 180/M_PIF;                       // rad -> degrees

    // desired units
    if (show_km)
        dist *= 1.609344F;                      // mi - > km

    // print, capturing where units and deg/path can go
    tft.setCursor (dx_info_b.x, dx_info_b.y+5*vspace-4);
    tft.printf ("%.0f", dist);
    uint16_t units_x = tft.getCursorX()+2;
    tft.setCursor (units_x + 6, tft.getCursorY());
    tft.printf ("@%.0f", bearing);
    uint16_t deg_x = tft.getCursorX() + 3;
    uint16_t deg_y = tft.getCursorY();

    // home-made degree symbol
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    tft.setCursor (deg_x, deg_y-bh-bh/5);
    tft.print ('o');

    // path direction
    tft.setCursor (deg_x, deg_y-bh/2-bh/5);
    tft.print (show_lp ? 'L' : 'S');
    tft.setCursor (deg_x, deg_y-bh/3);
    tft.print ('P');

    // distance units
    if (show_km) {
        tft.setCursor (units_x, deg_y-bh/2-bh/5);
        tft.print('k');
        tft.setCursor (units_x, deg_y-bh/3);
        tft.print('m');
    } else {
        tft.setCursor (units_x, deg_y-bh/2-bh/5);
        tft.print('m');
        tft.setCursor (units_x, deg_y-bh/3);
        tft.print('i');
    }

    // sun rise/set or prefix
    if (dxsrss == DXSRSS_PREFIX) {
        char prefix[MAX_PREF_LEN+1];
        tft.fillRect (dxsrss_b.x, dxsrss_b.y, dxsrss_b.w, dxsrss_b.h, RA8875_BLACK);
        if (getDXPrefix (prefix)) {
            tft.setTextColor(DX_COLOR);
            selectFontStyle (LIGHT_FONT, SMALL_FONT);
            bw = getTextWidth (prefix);
            tft.setCursor (dxsrss_b.x+(dxsrss_b.w-bw)/2, dxsrss_b.y + 28);
            tft.print (prefix);
        }
    } else {
        drawDXSunRiseSetInfo();
    }
}

/* return whether s is over DX distance portion of dx_info_b
 */
bool checkDistTouch (const SCoord &s)
{
    uint16_t vspace = dx_info_b.h/DX_INFO_ROWS;

    SBox b;
    b.x = dx_info_b.x;
    b.w = dx_info_b.w/2;
    b.y = dx_info_b.y + 4*vspace;
    b.h = vspace;

    return (inBox (s, b));
}

/* return whether s is over DX path direction portion of dx_info_b
 */
bool checkPathDirTouch (const SCoord &s)
{
    uint16_t vspace = dx_info_b.h/DX_INFO_ROWS;

    SBox b;
    b.x = dx_info_b.x + dx_info_b.w/2;
    b.w = dx_info_b.w/2;
    b.y = dx_info_b.y + 4*vspace;
    b.h = vspace;

    return (inBox (s, b));
}

/* if touch position s is over the latitude portion of Info box b:
 *   adjust ll lat depending on whether the top or bottom half of lat number was touched
 * else if over the longitude portion:
 *   adjust ll lng depending on whether the left or right half of the lng number was touched
 * return true if ll was changed, else false
 * nvert is the number of vertical rows into which b is divided; row is the 0-based row number.
 */
static bool checkLLTouch (const SCoord &s, const SBox &b, uint8_t nvert, uint8_t row, LatLong &ll)
{
    uint16_t vspace = b.h/nvert;                        // height of one row
    uint16_t llb = b.x + b.w/3;                         // lat - lng boundary
    uint16_t lrb = b.x + 2*b.w/3;                       // lng left-right boundary
    uint16_t upd = b.y + row*vspace + vspace/2;         // lat up/down boundary

    if (s.y > upd-vspace/2 && s.y < upd+vspace/2 && s.x >= b.x && s.x < b.x+b.w) {
        if (s.x <= llb) {
            // touched lat
            if (s.y < upd) {
                if (ll.lat_d < 89)
                    ll.lat_d += 1;                      // 1 deg up = northward, no pole
            } else {
                if (ll.lat_d > -89)
                    ll.lat_d -= 1;                      // 1 deg down = southward, no pole
            }
            ll.lat = deg2rad (ll.lat_d);
        } else {
            // touched lng
            if (s.x < lrb) {
                if ((ll.lng_d -= 1) < -180)             // 1 deg left = westward, with wrap
                    ll.lng_d += 360;
            } else {
                if ((ll.lng_d += 1) >= 180)             // 1 deg right = eastward, with wrap
                    ll.lng_d -= 360;
            }
            ll.lng = deg2rad (ll.lng_d);
        }
        return (true);
    }
    return (false);
}

/* return whether s touched within DE lat or lng.
 * if so, update ll in place
 */
bool checkDELLTouch (const SCoord &s, LatLong &ll)
{
    return (checkLLTouch (s, de_info_b, 3, 1, ll));
}

/* return whether s touched within DX lat or lng.
 * if so, update ll in place
 */
bool checkDXLLTouch (const SCoord &s, LatLong &ll)
{
    return (checkLLTouch (s, dx_info_b, 5, 2, ll));
}


/* draw DX time unless in sat mode
 */
void drawDXTime()
{
    // skip if dx_info_b being used for sat info
    if (dx_info_for_sat)
        return;

    drawTZ (dx_tz);

    uint16_t vspace = dx_info_b.h/DX_INFO_ROWS;

    time_t utc = nowWO();
    time_t local = utc + dx_tz.tz_secs;
    int hr = hour (local);
    int mn = minute (local);
    int dy = day(local);
    int mo = month(local);

    tft.graphicsMode();
    tft.fillRect (dx_info_b.x, dx_info_b.y+vspace, dx_info_b.w, vspace, RA8875_BLACK);
    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    tft.setTextColor (DX_COLOR);
    tft.setCursor (dx_info_b.x, dx_info_b.y+2*vspace-8);

    char buf[32];
    sprintf (buf, "%02d:%02d %s %d", hr, mn, monthShortStr(mo), dy);
    tft.print(buf);
}

/* set `to' to the antipodal location of coords in `from'.
 */
void antipode (LatLong &to, const LatLong &from)
{
    to.lat_d = -from.lat_d;
    to.lng_d = from.lng_d+180;
    normalizeLL(to);
}

/* return whether the given line segment spans a reasonable portion of the map.
 * beware map edge, wrap and crossing center of azm map
 */
bool segmentSpanOk (SCoord &s0, SCoord &s1)
{
    return (s0.x - s1.x < tft.width()/2 && s1.x - s0.x < tft.width()/2
                && (!azm_on || ((s0.x < map_b.x+map_b.w/2) == (s1.x < map_b.x+map_b.w/2)))
                && overMap(s0) && overMap(s1));
}
