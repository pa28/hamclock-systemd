#include "Arduino.h"
#include "ESP.h"
#include "ESP8266httpUpdate.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

// one global instance
class ESPhttpUpdate ESPhttpUpdate;


// approximate number of lines generated when running unzip and make, used for progress meter.
#define N_UNZIP_LINES   100
#define N_MAKE_LINES    60


/* fork/exec sh to run cmd, call progressCB if set, return true if program exits 0,
 *   else fill err_msg and return false.
 * p0 and p1 are the start and ending percentage progress range as we read approx pn lines; set pn to
 *   0 if don't want callback.
 * if safe then command is run with our real uid, if !safe it is run with our euid.
 */
bool ESPhttpUpdate::runCommand (bool safe, int p0, int p1, int pn, const char *fmt, ...)
{
        // expand full command
        char cmd[1000];
        va_list ap;
        va_start (ap, fmt);
        vsnprintf (cmd, sizeof(cmd), fmt, ap);
        va_end (ap);

        printf ("OTA: Running: %s\n", cmd);

        // create pipe for parent to read from child
        int pipe_fd[2];
        if (pipe (pipe_fd) < 0) {
	    snprintf (err_msg, sizeof(err_msg), "pipe(2) failed: %s", strerror(errno));
            return (false);
        }

        // start new process as clone of us
        int pid = fork();
        if (pid < 0) {
	    snprintf (err_msg, sizeof(err_msg), "fork(2) failed: %s", strerror(errno));
            return (false);
        }

        // now two processes running concurrently

        if (pid == 0) {
            // child

            // engage full perm unless want safe
            if (!safe)
                setuid (geteuid());

            // arrange stdout/err to write into pipe_fd[1] to parent
            dup2 (pipe_fd[1], 1);
            dup2 (pipe_fd[1], 2);

            // don't need read end of pipe
            close (pipe_fd[0]);

            // go
            execl ("/bin/sh", "sh", "-c", cmd, NULL);

            printf ("OTA: Can not exec %s: %s\n", cmd, strerror(errno));
            _exit(1);
        }

        // decide whether we want to invoke progress callback
        bool want_cb = progressCB && pn > 0;

        // start with p0
        if (want_cb)
            (*progressCB) (p0, 100);

        // parent arranges to read from pipe_fd[0] from child until EOF
        FILE *rsp_fp = fdopen (pipe_fd[0], "r");
        close (pipe_fd[1]);

        // read and log output, report progress if desired
	char rsp[1000];
        rsp[0] = 0;
        for (int nlines = 0; ; nlines++) {

            if (want_cb) {
                int percent = p0 + nlines*(p1 - p0)/pn;
                if (percent > p1)         // N.B. maxlines is just an estimate
                    percent = p1;
                (*progressCB) (percent, 100);
            }

            if (!fgets (rsp, sizeof(rsp), rsp_fp))
                break;
            rsp[strlen(rsp) - 1] = '\0';        // no nl
	    printf ("    %s\n", rsp);
        }

        // end with final p1
        if (want_cb)
            (*progressCB) (p1, 100);

        // finished with pipe
        fclose (rsp_fp);        // also closes(pipe_fd[0])

        // parent waits for child
        int wstatus;
        if (waitpid (pid, &wstatus, 0) < 0) {
	    snprintf (err_msg, sizeof(err_msg), "waitpid(2) failed: %s", strerror(errno));
            return (false);
        }

        // finished, report any error status
	if (!WIFEXITED(wstatus) || WEXITSTATUS(wstatus) != 0) {
	    snprintf (err_msg, sizeof(err_msg), "OTA cmd FAIL: %s", rsp);
	    return (false);
	}

        printf ("OTA: cmd ok\n");
	return (true);
}

/* given argv[0] find our full real path and whether it can be removed (containing dir is writable).
 * if ok return true else false and set err_msg to reason.
 * N.B. beware symlinks, we want the read deal.
 */
bool ESPhttpUpdate::findFullPath (const char *argv0, char full_path[], size_t fplen)
{
        // get current dir
        char cwd[1000];
        if (!getcwd (cwd, sizeof(cwd))) {
            snprintf (err_msg, sizeof(err_msg), "Could not get CWD: %s", strerror(errno));
            return (false);
        }

        // look in several places to find full path of argv0, confirm with successful fopen
        FILE *fp = NULL;
        if (argv0[0] == '/') {
            // full path already!
            snprintf (full_path, fplen, "%s", argv0);
            fp = fopen (full_path, "r");
        }
        if (!fp) {
            // try relative to cwd
            snprintf (full_path, fplen, "%s/%s", cwd, argv0);
            fp = fopen (full_path, "r");
        }
        if (!fp) {
            // look in each PATH entry, beware "."
            char *onepath, *path = strdup (getenv ("PATH")), *tofree = path;   // don't clobber the real PATH
            while ((onepath = strsep(&path, ":")) != NULL) {
                if (strcmp (onepath, ".") == 0)
                    snprintf (full_path, fplen, "%s/%s", cwd, argv0);
                else
                    snprintf (full_path, fplen, "%s/%s", onepath, argv0);
                fp = fopen (full_path, "r");
                if (fp)
                    break;
            }
            free(tofree);
        }

        // trouble if still can't open or still not a full path
        if (!fp) {
            snprintf (err_msg, sizeof(err_msg), "can not open %s: %s", full_path, strerror(errno));
            return (false);
        }
        fclose (fp);
        if (full_path[0] != '/') {
            snprintf (err_msg, sizeof(err_msg), "not a full path: %s", full_path);
            return (false);
        }

        // follow through any symlinks in place
        char link[1000];
        int ln;
        while ((ln = readlink (full_path, link, sizeof(link))) > 0) {
            if (link[0] == '/') {
                // replace entire path
                snprintf (full_path, fplen, "%.*s", ln, link);
            } else {
                // replace last component
                char *right_slash = strrchr (full_path, '/');
                snprintf (right_slash+1, fplen-(right_slash-full_path+1), "%.*s", ln, link);
            }
        }
        if (ln < 0 && errno != EINVAL) {
            // EINVAL just means path was not a symlink
            snprintf (err_msg, sizeof(err_msg), "%s error: %s", full_path, strerror(errno));
            return (false);
        }

        // now confirm the file can be removed by checking whether we can write the containing dir
        char *right_slash = strrchr (full_path, '/');
        if (full_path[0] != '/' || !right_slash) {
            snprintf (err_msg, sizeof(err_msg), "%s not a full path", full_path);
            return (false);
        }
        *right_slash = '\0';                    // temporarily remove file to get its containing directory
        if (faccessat (0, full_path, W_OK, AT_EACCESS) < 0) {
            snprintf (err_msg, sizeof(err_msg), "Can not edit %s: %s", full_path, strerror(errno));
            return (false);
        }
        *right_slash = '/';                     // restore

        // ok!
        return (true);
}

/* rm tmp and everything it contains.
 * too late to worry any errors.
 */
void ESPhttpUpdate::cleanupDir (const char *tmp)
{
        (void) runCommand (true, 0, 0, 0, "rm -fr %s", tmp);
}

/* url is curl path to new zip file.
 * call *progressCB as make progress.
 */
t_httpUpdate_return ESPhttpUpdate::update(WiFiClient &client, const char *url)
{
        (void) client;

        printf ("OTA: Update with url: %s\n", url);

	// find full path to current program and insure we have permission to remove it
	char our_path[1000];
        if (!findFullPath (our_argv0, our_path, sizeof(our_path)))
	    return (HTTP_UPDATE_FAILED);                // already set err_msg
        printf ("OTA: our full real path: %s\n", our_path);

	// find zip file name portion of url
	const char *zip_file = strrchr (url, '/');
	if (!zip_file || !strstr (url, ".zip")) {
	    snprintf (err_msg, sizeof(err_msg), "BUG! url %s has no zip file??", url);
	    return (HTTP_UPDATE_FAILED);
	}
	zip_file += 1;		// skip /
        printf ("OTA: zip name: %s\n", zip_file);

        // homebrew a temp working dir, seems there are issues with all the usual methods
        // N.B. after this always call cleanupDir before returning
        char tmp_dir[50];
        srand (time(NULL));
        snprintf (tmp_dir, sizeof(tmp_dir), "/tmp/HamClock-tmp-%010d.d", rand());
        printf ("OTA: creating %s\n", tmp_dir);
	if (!runCommand (true, 1, 5, 1, "mkdir %s", tmp_dir)) {
	    snprintf (err_msg, sizeof(err_msg), "Can not create %s: %s", tmp_dir, strerror(errno));
	    return (HTTP_UPDATE_FAILED);
	}

	// download url into tmp_dir naming it zip_file
	if (!runCommand (true, 5, 10, 1, "curl --silent --show-error --output '%s/%s' '%s'",
                                tmp_dir, zip_file, url)) {
            cleanupDir (tmp_dir);
	    return (HTTP_UPDATE_FAILED);
        }

	// find new dir unzip will make by assuming it matches base name of zip file.
        // N.B. beware of rc files which have "-V[\d]+\.[\d]+rc[\d]+" after base name.
	const char *zip_ext = strchr (zip_file, '-');          // ESPHamClock-Vxxx.zip
        if (!zip_ext)
            zip_ext = strchr (zip_file, '.');                  // ESPHamClock.zip
	if (!zip_ext) {
	    snprintf (err_msg, sizeof(err_msg), "zip file %s has no extension?", zip_file);
            cleanupDir (tmp_dir);
	    return (HTTP_UPDATE_FAILED);
	}
        int base_len = zip_ext - zip_file;
	char make_dir[64];
	snprintf (make_dir, sizeof(make_dir), "%.*s", base_len, zip_file);
        printf ("OTA: zip will create dir %s\n", make_dir);

	// explode
	if (!runCommand (true, 10, 15, N_UNZIP_LINES, "cd %s && unzip %s", tmp_dir, zip_file)) {
            cleanupDir (tmp_dir);
	    return (HTTP_UPDATE_FAILED);
        }

	// within the new source tree, make the same target we were made with
        printf ("OTA: making %s\n", our_make);
    #ifdef __FreeBSD__
	if (!runCommand (true, 15, 95, N_MAKE_LINES, "cd %s/%s && gmake -j 3 %s",tmp_dir,make_dir,our_make)) {
    #else
	if (!runCommand (true, 15, 95, N_MAKE_LINES, "cd %s/%s && make -j 3 %s",tmp_dir,make_dir,our_make)) {
    #endif
            cleanupDir (tmp_dir);
	    return (HTTP_UPDATE_FAILED);
        }

        // get the mode of the currently running file before we remove it
        struct stat sbuf;
        if (stat (our_path, &sbuf) < 0) {
	    snprintf (err_msg, sizeof(err_msg), "Can not get our mode %s: %s", our_path, strerror(errno));
	    return (HTTP_UPDATE_FAILED);
	}

        // replace current program file with new one, we already think we can remove it
	if (!runCommand (false, 95, 98, 1, "rm -f %s && mv %s/%s/%s %s", our_path,
                                                tmp_dir, make_dir, our_make, our_path)) {
            cleanupDir (tmp_dir);
	    return (HTTP_UPDATE_FAILED);
        }

        // set new version of our file to same ownership and mode
        if (chown (our_path, sbuf.st_uid, sbuf.st_gid) < 0) {
	    snprintf (err_msg, sizeof(err_msg), "Can not change our ownership %s: %s", our_path, strerror(errno));
	    return (HTTP_UPDATE_FAILED);
	}
        if (chmod (our_path, sbuf.st_mode) < 0) {
	    snprintf (err_msg, sizeof(err_msg), "Can not change our mode %s: %s", our_path, strerror(errno));
	    return (HTTP_UPDATE_FAILED);
	}

	// clean up
        cleanupDir (tmp_dir);

	// close all connections and execute over ourselves -- never returns if works
        printf ("OTA: restarting new version\n");
        ESP.restart();

	// darn! will never get here if successful
        printf ("OTA: restart failed\n");
	strcpy (err_msg, "Failed to start new version");
	return (HTTP_UPDATE_FAILED);
}

void ESPhttpUpdate::onProgress (void (*my_progressCB)(int current, int total))
{
        progressCB = my_progressCB;
}


int ESPhttpUpdate::getLastError(void)
{
	return (1);
}

String ESPhttpUpdate::getLastErrorString(void)
{
        printf ("OTA: Update error: %s\n", err_msg);
	return (String(err_msg));
}
