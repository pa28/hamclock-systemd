/* Arduino SPI.cpp implemented over raspberry pi.
 * TODO
 */

#include "SPI.h"

SPIClass SPI;
