#include "Serial.h"

class Serial Serial;
