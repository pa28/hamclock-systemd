#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/resource.h>

#include "Arduino.h"

char **our_argv;                // our argv for restarting
std::string our_dir;            // our storage directory, including trailing /


// how we were made
#if defined(_USE_FB0)
  #if defined(_CLOCK_1600x960)
      char our_make[] = "hamclock-fb0-1600x960";
  #elif defined(_CLOCK_2400x1440)
      char our_make[] = "hamclock-fb0-2400x1440";
  #elif defined(_CLOCK_3200x1920)
      char our_make[] = "hamclock-fb0-3200x1920";
  #else
      char our_make[] = "hamclock-fb0-800x480";
  #endif
#elif defined(_USE_X11)
  #if defined(_CLOCK_1600x960)
      char our_make[] = "hamclock-1600x960";
  #elif defined(_CLOCK_2400x1440)
      char our_make[] = "hamclock-2400x1440";
  #elif defined(_CLOCK_3200x1920)
      char our_make[] = "hamclock-3200x1920";
  #else
      char our_make[] = "hamclock-800x480";
  #endif
#else
  #error Unknown build configuration
#endif
 

/* return milliseconds since first call
 */
uint32_t millis(void)
{
	static struct timespec t0;

	struct timespec t;
	clock_gettime (CLOCK_MONOTONIC, &t);

	if (t0.tv_sec == 0 && t0.tv_nsec == 0)
	    t0 = t;

	int32_t dt_ms = (t.tv_sec - t0.tv_sec)*1000 + (t.tv_nsec - t0.tv_nsec)/1000000;
	// printf ("millis %u: %ld.%09ld - %ld.%09ld\n", dt_ms, t.tv_sec, t.tv_nsec, t0.tv_sec, t0.tv_nsec);
	return (dt_ms);
}

void delay (uint32_t ms)
{
	usleep (ms*1000);
}

int random(int max)
{
	return ((int)((max-1.0F)*::random()/RAND_MAX));
}

uint16_t analogRead(int pin)
{
	return (0);		// not supported on Pi, consider https://www.adafruit.com/product/1083
}

static void mvLog (const char *from, const char *to)
{
        std::string from_path = our_dir + from;
        std::string to_path = our_dir + to;
        const char *from_fn = from_path.c_str();
        const char *to_fn = to_path.c_str();
        if (rename (from_fn, to_fn) < 0 && errno != ENOENT) {
            // fails for a reason other than from does not exist
            fprintf (stderr, "rename(%s,%s): %s\n", from_fn, to_fn, strerror(errno));
            exit(1);
        }
}


/* roll log files and change stdout to fresh file in our_dir
 */
static void stdout2File()
{
        // save previous few
        mvLog ("diagnostic-log-1.txt", "diagnostic-log-2.txt"); 
        mvLog ("diagnostic-log-0.txt", "diagnostic-log-1.txt"); 
        mvLog ("diagnostic-log.txt",   "diagnostic-log-0.txt"); 

        // reopen stdout as new log
        std::string new_log = our_dir + "diagnostic-log.txt";
        const char *new_log_fn = new_log.c_str();
        int logfd = open (new_log_fn, O_WRONLY|O_CREAT, 0664);
        close (1);      // insure disconnect from previous log file
        if (logfd < 0 || ::dup2(logfd, 1) < 0) {
            fprintf (stderr, "%s: %s\n", new_log_fn, strerror(errno));
            exit(1);
        }
        fchown (logfd, getuid(), getgid());

        // just need fd 1
        close (logfd);

        // note
        printf ("log file is %s\n", new_log_fn);
}

/* return default working directory
 */
static std::string defaultAppDir()
{
        std::string home = getenv ("HOME");
        return (home + "/.hamclock/");
}

/* insure our application work directory exists and named in our_dir.
 * use default unless user_dir.
 * exit if trouble.
 */
static void mkAppDir(const char *user_dir)
{
        // use user_dir else default
        if (user_dir) {
            our_dir = user_dir;
            // insure ends with /
            if (our_dir.compare (our_dir.length()-1, 1, "/")) {
                std::string slash = "/";
                our_dir = our_dir + slash;
            }
        } else {
            // use default
            our_dir = defaultAppDir();
        }

        // insure exists, fine if already created
        const char *path = our_dir.c_str();
        mode_t old_um = umask(0);
        if (mkdir (path, 0775) < 0 && errno != EEXIST) {
            // EEXIST just means it already exists
            fprintf (stderr, "%s: %s\n", path, strerror(errno));
            exit(1);
        }
        chown (path, getuid(), getgid());
        umask(old_um);
}

/* show usage and exit(1)
 */
static void usage (void)
{
        char *slash = strrchr (our_argv[0], '/');
        char *me = slash ? slash+1 : our_argv[0];

        fprintf (stderr, "Purpose: display real-time info useful to amateur radio operators\n");
        fprintf (stderr, "Usage: %s [options]\n", me);
        fprintf (stderr, "Options:\n");
        fprintf (stderr, " --backend=host      : set backend host instead of %s\n", svr_host);
        fprintf (stderr, " --diag-to-stdout    : write diagnostic log to stdout instead of in working dir\n");
        fprintf (stderr, " --fullscreen=on/off : initial setting for whether to display full screen\n");
        fprintf (stderr, " --workdir=dir       : set working dir instead of %s\n", defaultAppDir().c_str());

        exit(1);
}

/* process main's argc/argv -- never returns if any issues
 */
static void crackArgs (int ac, char *av[])
{
        bool diag_to_file = true;
        bool full_screen = false;
        bool fs_set = false;
        const char *new_appdir = NULL;

        while (--ac > 0) {
            char *arg = *++av;
            char *equals = strchr (arg, '=');

            if (strcmp (arg, "--diag-to-stdout") == 0) {
                diag_to_file = false;

            } else if (strncmp (arg, "--fullscreen=", 13) == 0) {
                if (!equals)
                    usage();
                if (strcmp (equals+1, "on") == 0) {
                    full_screen = true;
                    fs_set = true;
                } else if (strcmp (equals+1, "off") == 0) {
                    full_screen = false;
                    fs_set = true;
                } else
                    usage();

            } else if (strncmp (arg, "--backend=", 10) == 0) {
                if (!equals)
                    usage();
                svr_host = equals+1;

            } else if (strncmp (arg, "--workdir=", 10) == 0) {
                if (!equals)
                    usage();
                new_appdir = equals+1;

            } else {
                usage();
            }
        }
        if (ac > 0)
            usage();

        // prepare our working directory in our_dir
        mkAppDir (new_appdir);

        // redirect stdout to diag file unless requested not to
        if (diag_to_file)
            stdout2File();

        // set desired screen option if set
        if (fs_set)
            setX11FullScreen (full_screen);
}

/* Every normal C program requires a main().
 * This is provided as magic in the Arduino IDE so here we must do it ourselves.
 */
int main (int ac, char *av[])
{
	// save our args for identical restart or remote update
	our_argv = av;

        // always want stdout synchronous 
        setbuf (stdout, NULL);

        // check args
        crackArgs (ac, av);

        // log args after cracking so they go to proper diag file
        printf ("\nNew program args:\n");
        for (int i = 0; i < ac; i++)
            printf ("  argv[%d] = %s\n", i, av[i]);

        // log our working dir
        printf ("working directory is %s\n", our_dir.c_str());

	// call Arduino setup one time
        printf ("Calling Arduino setup()\n");
	setup();

        // usage stats
        struct rusage ru0;
        struct timeval tv0;
        memset (&ru0, 0, sizeof(ru0));
        memset (&tv0, 0, sizeof(tv0));
        bool usage_init = false;

	// call Arduino loop forever
        printf ("Starting Arduino loop()\n");
	for (;;) {
	    loop();

            // this loop by itself would run 100% CPU so try to be a better citizen and throttle back

            // measure elapsed time during previous loop
            struct timeval tv1;
            gettimeofday (&tv1, NULL);
            int et_us = (tv1.tv_sec - tv0.tv_sec)*1000000 + (tv1.tv_usec - tv0.tv_usec);
            tv0 = tv1;

            // measure cpu time used during previous loop
            struct rusage ru1;
            getrusage (RUSAGE_SELF, &ru1);
            struct timeval *ut0 = &ru0.ru_utime;
            struct timeval *ut1 = &ru1.ru_utime;
            struct timeval *st0 = &ru0.ru_stime;
            struct timeval *st1 = &ru1.ru_stime;
            int ut_us = (ut1->tv_sec - ut0->tv_sec)*1000000 + (ut1->tv_usec - ut0->tv_usec);
            int st_us = (st1->tv_sec - st0->tv_sec)*1000000 + (st1->tv_usec - st0->tv_usec);
            int cpu_us = ut_us + st_us;
            ru0 = ru1;
            // printf ("ut %d st %d et %d\n", ut_us, st_us, et_us);

            // cap cpu usage a little below max
            #define MAX_CPU_USAGE 0.9F
            int s_us = cpu_us/MAX_CPU_USAGE - et_us;
            if (usage_init && s_us > 0)
                usleep (s_us);
            usage_init = true;

	}
}
