#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/resource.h>

#include "Arduino.h"


char **our_argv;                // our argv for restarting
std::string our_dir;            // our storage directory, including trailing /


// how we were made
#if defined(_USE_FB0)
  #if defined(_CLOCK_1600x960)
      char our_make[] = "hamclock-fb0-1600x960";
  #elif defined(_CLOCK_2400x1440)
      char our_make[] = "hamclock-fb0-2400x1440";
  #elif defined(_CLOCK_3200x1920)
      char our_make[] = "hamclock-fb0-3200x1920";
  #else
      char our_make[] = "hamclock-fb0-800x480";
  #endif
#elif defined(_USE_X11)
  #if defined(_CLOCK_1600x960)
      char our_make[] = "hamclock-1600x960";
  #elif defined(_CLOCK_2400x1440)
      char our_make[] = "hamclock-2400x1440";
  #elif defined(_CLOCK_3200x1920)
      char our_make[] = "hamclock-3200x1920";
  #else
      char our_make[] = "hamclock-800x480";
  #endif
#else
  #error Unknown build configuration
#endif
 

/* return milliseconds since first call
 */
uint32_t millis(void)
{
	static struct timespec t0;

	struct timespec t;
	clock_gettime (CLOCK_MONOTONIC, &t);

	if (t0.tv_sec == 0 && t0.tv_nsec == 0)
	    t0 = t;

	int32_t dt_ms = (t.tv_sec - t0.tv_sec)*1000 + (t.tv_nsec - t0.tv_nsec)/1000000;
	// printf ("millis %u: %ld.%09ld - %ld.%09ld\n", dt_ms, t.tv_sec, t.tv_nsec, t0.tv_sec, t0.tv_nsec);
	return (dt_ms);
}

void delay (uint32_t ms)
{
	usleep (ms*1000);
}

int random(int max)
{
	return ((int)((max-1.0F)*::random()/RAND_MAX));
}

uint16_t analogRead(int pin)
{
	return (0);		// not supported on Pi, consider https://www.adafruit.com/product/1083
}




/* change stdout to diag file
 */
static void stdout2Diag()
{
        // new log file name sans ext
        std::string logbase = our_dir + "diagnostic-log";
        const char *lb = logbase.c_str();

        // save previous few
        const int MAXLOGN = 2;
        char from_log[2048], to_log[2048];
        for (int i = MAXLOGN; i >= 0; --i) {
            if (i == 0)
                snprintf (from_log, sizeof(from_log), "%s.txt", lb);
            else
                snprintf (from_log, sizeof(from_log), "%s-%d.txt", lb, i-1);
            int fromfd = open (from_log, O_RDONLY);
            if (fromfd >= 0) {
                close (fromfd);
                snprintf (to_log, sizeof(to_log), "%s-%d.txt", lb, i);
                unlink (to_log);
                rename (from_log, to_log);
                // printf ("from %s to %s\n", from_log, to_log);
            }
        }

        // reopen stdout as from_log. prefer dup2 over freopen because if latter fails stdout is gone
        int logfd = open (from_log, O_WRONLY|O_CREAT, 0664);
        close (1);      // insure disconnect from previous log file
        if (logfd < 0 || ::dup2(logfd, 1) < 0) {
            fprintf (stderr, "%s: %s\n", from_log, strerror(errno));
            exit(1);
        }
        fchown (logfd, getuid(), getgid());

        // just need 1
        close (logfd);
}

/* insure our application work directory exists and named in our_dir.
 * use default unless user_dir
 */
static void mkAppDir(const char *user_dir)
{
        // use user_dir else default
        if (user_dir) {
            // insure ends with /
            std::string slash = "/";
            our_dir = user_dir + slash;
        } else {
            std::string home = getenv ("HOME");
            our_dir = home + "/.hamclock/";
        }

        // insure exists, fine if already created
        const char *path = our_dir.c_str();
        mode_t old_um = umask(0);
        if (mkdir (path, 0775) < 0 && errno != EEXIST) {
            // EEXIST just means it already exists
            fprintf (stderr, "%s: %s\n", path, strerror(errno));
            exit(1);
        }
        chown (path, getuid(), getgid());
        umask(old_um);
}

/* show usage and exit(1)
 */
static void usage (void)
{
        char *slash = strrchr (our_argv[0], '/');
        char *me = slash ? slash+1 : our_argv[0];

        fprintf (stderr, "Purpose: display real-time info useful to amateur radio operators\n");
        fprintf (stderr, "Usage: %s [options]\n", me);
        fprintf (stderr, "Options:\n");
        fprintf (stderr, " --diag_to_stdout    : write diags to stdout instead of in working dir\n");
        fprintf (stderr, " --fullscreen on/off : initial setting for whether to display full screen\n");
        fprintf (stderr, " --work_dir d        : use d as working directory -- must be a full path\n");

        exit(1);
}

/* process main's argc/argv -- never returns if any issues
 */
static void crackArgs (int ac, char *av[])
{
        bool diag_to_file = true;
        bool full_screen = false;
        bool fs_set = false;
        const char *new_appdir = NULL;

        while (--ac > 0) {
            char *arg = *++av;

            if (strcmp (arg, "--diag_to_stdout") == 0) {
                diag_to_file = false;

            } else if (strcmp (arg, "--fullscreen") == 0) {
                if (--ac < 1)
                    usage();
                arg = *++av;
                if (strcmp (arg, "on") == 0) {
                    full_screen = true;
                    fs_set = true;
                } else if (strcmp (arg, "off") == 0) {
                    full_screen = false;
                    fs_set = true;
                } else
                    usage();

            } else if (strcmp (arg, "--work_dir") == 0) {
                if (--ac < 1)
                    usage();
                new_appdir = *++av;
                if (new_appdir[0] != '/')
                    usage();

            } else {
                usage();
            }
        }
        if (ac > 0)
            usage();

        // prepare our working directory in our_dir
        mkAppDir (new_appdir);

        // redirect stdout to diag file unless requested not to
        if (diag_to_file)
            stdout2Diag();

        // set desired screen option if set
        if (fs_set)
            setX11FullScreen (full_screen);
}

/* Every normal C program requires a main().
 * This is provided as magic in the Arduino IDE so here we must do it ourselves.
 */
int main (int ac, char *av[])
{
	// save our args for identical restart or remote update
	our_argv = av;

        // always want stdout synchronous 
        setbuf (stdout, NULL);

        // check args
        crackArgs (ac, av);

        // log args after cracking so they go to proper diag file
        for (int i = 0; i < ac; i++)
            printf ("argv[%d] = %s\n", i, av[i]);

	// call Arduino setup one time
	setup();

	// call Arduino loop forever
	for (;;) {
	    loop();

            // this loop by itself would run 100% CPU so try to be a better citizen and throttle back

            // measure cpu time used during previous loop
            static struct rusage ru0;
            struct rusage ru1;
            getrusage (RUSAGE_SELF, &ru1);
            if (ru0.ru_utime.tv_sec == 0 && ru0.ru_utime.tv_usec == 0)
                ru0 = ru1;
            struct timeval *ut0 = &ru0.ru_utime;
            struct timeval *ut1 = &ru1.ru_utime;
            struct timeval *st0 = &ru0.ru_stime;
            struct timeval *st1 = &ru1.ru_stime;
            int ut_us = (ut1->tv_sec - ut0->tv_sec)*1000000 + (ut1->tv_usec - ut0->tv_usec);
            int st_us = (st1->tv_sec - st0->tv_sec)*1000000 + (st1->tv_usec - st0->tv_usec);
            int cpu_us = ut_us + st_us;
            ru0 = ru1;
            // printf ("ut %d st %d\n", ut_us, st_us);

            // sleep for 20% longer to keep CPU < 80% but beware occasional very lengthy loops
            if (cpu_us < 10000)
                usleep (cpu_us/5);

	}
}
