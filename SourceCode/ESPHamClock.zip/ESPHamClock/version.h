#define	HC_VERSION	"2.60"
